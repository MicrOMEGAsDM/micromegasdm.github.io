#include"../sources/micromegas.h"

int main(void)
{ double dNdE[200]; 
  double Mwimp, csSIp,csSIn,csSDp,csSDn,Leff;

/* Model input */
/*  Mwimp=60; csSIp=6.6E-8;  csSIn=6.6E-8;  csSDp=0;  csSDn=0; */
/*    Mwimp=1983.03213; csSIp= 5.17447771E-11;  csSIn= 5.11302519E-11;   csSDp=0;  csSDn=0; */


Mwimp=28.6456013; csSIp= 0; csSIn=0; csSDp=-0.00137159355; csSDn=0.000910850585;

/*
Mwimp=28.6456013; csSIp=  9.60115379E-07; csSIn=9.84521467E-07; csSDp=0; csSDn=0; 
*/
printf("Model parameters:\n Mwimp=%.2E csSIp=%.2E, csSIn=%.2E,csSDp=%.2E,csSDn=%.2E\n",
                          Mwimp, csSIp, csSIn,csSDp,csSDn);
 SetfMaxwell(220.454077,225.536871,600);
  { double NevSD,NevSI, Nev;
    printf("CDMS I signal:\n");
    
    nucleusRecoilAux(0.3,fDvMaxwell,127,Z_I,J_I127,S00I127,S01I127,S11I127,
    Mwimp, csSIp,csSIn,csSDp, csSDn, dNdE);
    printf("dNdE[10]=%E\n",dNdE[10]);
    
  }
}     

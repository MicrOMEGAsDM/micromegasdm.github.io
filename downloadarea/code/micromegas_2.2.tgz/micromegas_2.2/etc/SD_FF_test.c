#include"../sources/micromegas.h"

int main(int narg, char** args)
{
  double xiP=1,xiN=0; /* WIMP-proton and WIMP-neutron SpinDependent couplings */   
  
  Plot3SS(xiP,xiN,S00Si29,S01Si29,S11Si29,29,0.5, "Si29", 500);    

  Plot3SS0(xiP,xiN,Sp_Si29,Sn_Si29,29,0.5, "Si29-Fermi", 500);

}

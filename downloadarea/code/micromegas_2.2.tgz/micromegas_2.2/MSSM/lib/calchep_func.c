#include "pmodel.h"
#include "../../sources/micromegas.h"
#include "../../sources/micromegas_aux.h"

/* ============================================================
   The function presented in this file are used only in calchep 
   interactive session. Thus the prototipes are never  checked.
   So we present them below only to avoid warnings at compilaton
   ============================================================= */
                                                                                                 
extern forCalchep1 dMb,deltarho,gmuon,bsgnlo,bsmumu,masslimits,slha;

extern double saveSM(double MbMb,double Mtp,double SW,double alfSMZ,
       double alfEMZ,double MZ,double Ml);
       
extern double  Omega(double qcdOk);

/* =====  end of header part ========= */

double saveSM(double MbMb,double Mtp,double SW,double alfSMZ,double alfEMZ,double MZ,double Ml)
{
  double Qmin;
  assignValW("MbMb",  MbMb); 
  assignValW("Mtp",   Mtp);
  assignValW("SW",    SW);
  assignValW("alfSMZ",alfSMZ);
  assignValW("alfEMZ",alfEMZ);
  assignValW("MZ",    MZ);
  assignValW("Ml",    Ml);
  Qmin=initQCD(alfSMZ,1.4,MbMb,Mtp);
  if(Qmin<0 || Qmin>MbMb) return 0; else return 1;
}

double  dMb(double ok)     {return deltaMb();    }
double  deltarho(double ok){ return  deltarho_();} 
double  gmuon(double ok)   { return  gmuon_();   }
double  bsgnlo(double ok)  { return  bsgnlo_();  }
double  bsmumu(double ok)  { return  bsmumu_();  }
double  masslimits(double ok) {return masslimits_();}

double  Omega(double qcdOk)
{ double omega;

  sortOddParticles(NULL);
  omega=darkOmega(NULL,1,1.E-6);

  return omega;
}


extern int nSess;
double slha(double mssmOK)
{ char fname[20];
  sprintf(fname,"slha_%d.txt",nSess);
  slhaWrite(fname);
  return 1.;
}

extern double  saveSLHA(double x);
double  saveSLHA(double x){ if(x) delFiles(0); else delFiles(1); return 1;}

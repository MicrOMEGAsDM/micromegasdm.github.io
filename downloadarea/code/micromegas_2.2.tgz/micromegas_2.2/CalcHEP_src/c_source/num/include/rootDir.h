char * rootDir=" ";

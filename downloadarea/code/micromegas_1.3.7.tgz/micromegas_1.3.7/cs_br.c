/*=== default RGE is SuSpect === 
   To use another package  uncomment one of lines below and modify
   micro_make  to link  the corresponding package
================================*/ 
/*#define suspectSUGRA  isajetSUGRA   */  /*=====for ISAJET   ======*/
/*#define suspectSUGRA  softSusySUGRA */  /*=====for SOFTSUSY ======*/
/*#define suspectSUGRA  sphenoSUGRA   */  /*=====for SPHENO   ======*/

static void process22Info(double Pcm, char* process, char * libname);
static void decayInfo(char * particle);

#include"sources/micromegas.h"

int main(int argc,char** argv)
{
  double m0,mhf,a0,tb,sgn, /* mSUGRA input parameters */Pcm;
  int dMbOn=1,err; 

/*   INPUT   */
  printf("Enter m0 mhf a0 tb \n");
  err=scanf("%lf %lf %lf %lf",  &m0, &mhf, &a0, &tb);
  if(err!=4) { printf("Wrong input\n"); exit(1);} 
/* correct if need */
  assignValW("Mtp",175.);
  assignValW("MbMb",4.23);
  assignValW("alfSMZ",.1172);              
  sgn=1;                      
                                                            
/* SUGRA spectrum */  
  { /* Universal SUGRA parameters   */
     double  gMG1=mhf, gMG2=mhf, gMG3=mhf, gAl=a0,  gAt=a0,  gAb=a0,
             gMHu=m0,  gMHd=m0,  gMl2=m0, gMl3=m0, gMr2=m0, gMr3=m0,
             gMq2=m0, gMq3=m0, gMu2=m0, gMd2=m0, gMu3=m0, gMd3=m0;

/*==== To save  RGE input/output files, uncomment the line  below =====*/
/*   delFiles(0);   */
     err=suspectSUGRA(tb,  
        gMG1, gMG2, gMG3, gAl,  gAt,  gAb,  sgn,  gMHu, gMHd, 
        gMl2, gMl3, gMr2, gMr3, gMq2, gMq3, gMu2, gMd2, gMu3, gMd3);
     if(err<0){ printf(" No RGE solution \n");  return err;} 
     if(err>0){ printf(" non fatal problems in RGE\n");} 
     calcDep(dMbOn);  
   }
/*
  printVar(stdout,150);
*/


  printf("\nExamples  of calculations of widths and branchings.\n");
  
  decayInfo("Z");
  decayInfo("h");   
  decayInfo("~2+");
    
  printf("\nExamples of calculations of cross sections\n\n");

  Pcm=500;
  process22Info(Pcm,"e,E->~1+,~1-","eE1P1M");
  printf("\n");
  process22Info(Pcm,"e,E->~o1,~o2","eEo1o2"); 
  printf("\n");
  Pcm=findValW("MNE1")/5;
  printf("Neutralino annihilation at freez-out\n");
  process22Info(Pcm,"","omglib_o1_o1"); 

  return 0;
}

static void decayInfo(char * particle)
{ int k;
  double s;
  printf("\n %s partial widths\n",particle);
  for(k=1,s=0;;k++)
  { char n1[6],n2[6];
    double w=decay2(particle,k,n1,n2);
    if(n1[0]==0) break;    
    s+=w;
    if(w>0) printf("%3s %3s - %.3E GeV\n",n1,n2,w);
  } 
  printf("Total %.3E GeV\n",s);
}

static void process22Info(double Pcm, char* process, char * libname)
{ void*libPtr=newProcess(process,libname);
  int k;
  if(!libPtr) printf("Wrong process specification\n"); else
  for(k=1; ;k++) 
  { char n1[8],n2[8],n3[8],n4[8];
    double m1,m2,m3,m4;
    int err=infor22(libPtr,k,n1,n2,n3,n4,&m1,&m2,&m3,&m4);
    if(err==0)
    { char str[100];
      double cs;
      sprintf(str,"%s %s -> %s,%s",n1,n2, n3,n4);
      cs= cs22(libPtr,k,Pcm,-1.,1.,&err);
      if(err==0&&cs>0) printf("%-20.20s P=%.1f Gev   %.3E pb\n",str,Pcm,cs);
    }
    else break;
  }
}


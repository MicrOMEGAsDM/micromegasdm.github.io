#include"sources/micromegas.h"

/*=== default RGE is SuSpect === */

/*#define suspectSUGRA isajetSUGRA   */   /*=====for ISAJET   ======*/
/*#define suspectSUGRA softSusySUGRA */   /*=====for SOFTSUSY ======*/
/*#define suspectSUGRA sphenoSUGRA   */   /*=====for SPHENO   ======*/

int main(void)
{
  int fast=1, dMbOn=1;  
  double Omega,Xf;
  double Beps=1.E-6;

  int err,i;  
  double m0,mhf,a0,tb;

  double   gMG1, gMG2, gMG3,
           gAl,  gAt,  gAb,  sgn,  gMHu,  gMHd,
           gMl2, gMl3, gMr2, gMr3,
           gMq2, gMq3, gMu2, gMd2, gMu3, gMd3;
                     
  struct msugraData
  { char label;
    double m0;
    double mhf;
    double a0;
    double tb;
    double sgn;
    double mtop; } testData[10]=
    { { 'A',  107,   600, 0,  5,  1, 174.3 },
      { 'B',   57,   250, 0, 10,  1, 174.3 },
      { 'C',   80,   400, 0, 10,  1, 174.3 },
      { 'D',  101,   525, 0, 10, -1, 174.3 },
      { 'G',  113,   375, 0, 20,  1, 174.3 },
      { 'H',  244,   935, 0, 20,  1, 174.3 },
      { 'I',  181,   350, 0, 35,  1, 174.3 },
      { 'J',  299,   750, 0, 35,  1, 174.3 },
      { 'K', 1001,  1300, 0, 46, -1, 174.3 },
      { 'L',  303,   450, 0, 47,  1, 174.3 }
  };
  
  for(i=0;i<10;i++)
  {      
    m0= testData[i].m0;
    mhf=testData[i].mhf;
    a0= testData[i].a0;
    tb= testData[i].tb;
    sgn=testData[i].sgn;
    assignVal("Mtp",testData[i].mtop);

    printf("point '%c' :",testData[i].label);      

    gMG1=mhf, gMG2=mhf,gMG3=mhf; gAl=a0,  gAt=a0,  gAb=a0;
    gMHu=m0,  gMHd=m0, gMl2=m0,  gMl3=m0, gMr2=m0, gMr3=m0,
    gMq2=m0,  gMq3=m0, gMu2=m0,  gMd2=m0, gMu3=m0, gMd3=m0;

    err=suspectSUGRA(tb,  
      gMG1, gMG2, gMG3, gAl, gAt, gAb, sgn, gMHu, gMHd,
      gMl2, gMl3, gMr2, gMr3, gMq2, gMq3, gMu2, gMd2, gMu3, gMd3);

    if(err<0){ printf(" No RGE solution \n"); continue; } 
    if(err>0){ printf(" non fatal problems in RGE\n");} 

    calcDep(dMbOn);
    if(strcmp(lsp(),"~o1")) { printf(" ~o1 is not LSP\n"); continue;}
    Omega=darkOmega(&Xf,fast,Beps);
    printf("Omega=%.2E\n", Omega);
  }
  return 0;
}

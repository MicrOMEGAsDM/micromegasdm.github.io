#include"micromegas.h"
#include"micromegas_aux.h"

extern int suspectsugra_(double*,double*,double*,double*,double*,double*,
         double*,double*,double*,double*,double*,double*,double*,double*,
         double*,double*,double*,double*,double*,double*);

int  suspectSUGRA(double tb, double gMG1,double gMG2,double gMG3,
             double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
             double gMl2,double gMl3,double gMr2,double gMr3,
             double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3)
{ return 
   suspectsugra_(&tb, &gMG1,&gMG2,&gMG3,        
             &gAl, &gAt, &gAb, &sgn, &gMHu, &gMHd,
             &gMl2,&gMl3,&gMr2,&gMr3,
             &gMq2,&gMq3,&gMu2,&gMu3,&gMd2,&gMd3);
}

#define xxxSUGRAc suspectSUGRAc
#define xxxSUGRA  suspectSUGRA
#include "sugrac.inc"


extern int suspectamsb_(double*,double*,double*,double*);

int suspectAMSB(double am0,double m32,double stgbeta,double ssgnmu0)
{
 return  suspectamsb_(&am0,&m32,&stgbeta,&ssgnmu0);

}

extern int  mssmspect_(int*);
int MSSMspect(int LC){return mssmspect_(&LC);}


int suspectEwsbMSSM(int LCOn)
{
   if(tree2LesH())     { FError=1; return -1;}
   if(MSSMspect(LCOn)) { FError=1; return -1;}
   return 0;
}

double ewsbMSSMc(double smOk, 
double tb, double MG1, double MG2, double MG3, double Am, double Al, double At, double Ab, 
double MH3, double mu, double Ml1, double Ml3, double Mr1, double Mr3, 
double Mq1, double Mq3, double Mu1, double Mu3, double Md1, double Md3, double LC)
{
   int lcOn= LC>0? 1:0;
   int err;
   
   assignValW("MH3",MH3);
   assignValW("tb",tb);
   assignValW("mu",mu);
   assignValW("Am",Am);
   assignValW("Al",Al);
   assignValW("Ab",Ab);
   assignValW("At",At);
   assignValW("MG1",MG1);
   assignValW("MG2",MG2);
   assignValW("MG3",MG3);
   assignValW("Ml1",Ml1);
   assignValW("Ml2",Ml1);
   assignValW("Ml3",Ml3);
   assignValW("Mr1",Mr1);
   assignValW("Mr2",Mr1);
   assignValW("Mr3",Mr3);
   assignValW("Mq1",Mq1);
   assignValW("Mq2",Mq1);
   assignValW("Mq3",Mq3);
   assignValW("Mu1",Mu1);
   assignValW("Mu2",Mu1);
   assignValW("Mu3",Mu3);
   assignValW("Md1",Md1);
   assignValW("Md2",Md1);
   assignValW("Md3",Md3);
   
   err=suspectEwsbMSSM(lcOn);
   if(err<0){ FError=1; return -1;} else return 1;
}

int ewsbInitFile(char * filename, int LCon)
{ int err=readEwsb(filename); 
  if(err) return err; else return suspectEwsbMSSM(LCon);
}


int  ewsbinitfile_(char *f_name,int * LCon, int len)
{
   char *name=malloc(len+10);
   int err;
   fName2c(f_name,name,len);
   err= ewsbInitFile(name,*LCon);
   free(name);
   return err;
}

int suspectewsbmssm_(int *LCOn) { return suspectEwsbMSSM(*LCOn);}

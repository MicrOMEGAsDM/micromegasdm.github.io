      SUBROUTINE  suspectMSSMvar 
      implicit NONE

      real*8             mhu2,mhd2,ma,mu
      COMMON/SU_MSSMHPAR/mhu2,mhd2,ma,mu
      real*8             m1,m2,m3
      COMMON/SU_MSSMGPAR/m1,m2,m3
      real*8             msl,mtaur,mel,mer
      COMMON/SU_MSSMSLEP/msl,mtaur,mel,mer
      real*8             msq,mtr,mbr,muq,mur,mdr
      COMMON/SU_MSSMSQUA/msq,mtr,mbr,muq,mur,mdr
      real*8             atau,at,ab
      COMMON/SU_ATRI3/   atau,at,ab
      real*8             al,au,ad
      COMMON/SU_ATRI12/  al,au,ad
      real*8        nf,cpi,zm,wm,tbeta
      COMMON/SU_cte/nf,cpi,zm,wm,tbeta
      real*8             dma,dml,dmh,dmch,dmarun
      COMMON/SU_hmass/   dma,dml,dmh,dmch,dmarun 
      real*8             mc1,mc2,mn1,mn2,mn3,mn4,gluino
      COMMON/SU_OUTGINOS/mc1,mc2,mn1,mn2,mn3,mn4,gluino

      call assignValW('mu' ,mu)   
      call assignValW('MG1',m1)   
      call assignValW('MG2',m2)   
      call assignValW('MG3',m3)   
      call assignValW('Ml1',mel)  
      call assignValW('Ml2',mel)  
      call assignValW('Ml3',msl)  
      call assignValW('Mr1',mer)  
      call assignValW('Mr2',mer)  
      call assignValW('Mr3',mtaur)
      call assignValW('Mq1',muq)  
      call assignValW('Mq2',muq)  
      call assignValW('Mq3',msq)  
      call assignValW('Mu1',mur)  
      call assignValW('Mu2',mur)  
      call assignValW('Mu3',mtr)  
      call assignValW('Md1',mdr)  
      call assignValW('Md2',mdr)  
      call assignValW('Md3',mbr)  
      call assignValW('At' ,at)   
      call assignValW('Ab' ,ab)   
      call assignValW('Al' ,atau) 
      call assignValW('Am' ,al)   
      call assignValW('tb_Q' ,tbeta)
      call assignValW('MH3',ma)   

      END

      SUBROUTINE suspectCouplings
      implicit NONE
      real*8 madr2,vev2
      common/su_runmavev/madr2,vev2
      real*8             mhu2,mhd2,ma,mu
      COMMON/SU_MSSMHPAR/mhu2,mhd2,ma,mu
      real*8 ytauewsb,ybewsb,ytewsb,alsewsb,g2ewsb,g1ewsb
      COMMON/SU_yukaewsb/ytauewsb,ybewsb,ytewsb,alsewsb,g2ewsb,g1ewsb
      real*8 scale
      COMMON/SU_renscale/scale 
      real*8 vuewsb,vdewsb
      COMMON/SU_tbewsb/vuewsb,vdewsb
      real*8 marunp,mlrunp,mhrunp,mchrunp,alfarunp
      COMMON/SU_runhiggsewsb/marunp,mlrunp,mhrunp,mchrunp,alfarunp
      call assignValW('gY',g1ewsb)
      call assignValW('g2',g2ewsb)
      call assignValW('g3',dsqrt(16*datan(1.d0)*alsewsb))
      call assignValW('Yl',ytauewsb) 
      call assignValW('Yt',ytewsb)
      call assignValW('Yb',ybewsb)
      call assignValW('QSUSY',scale)
c      call assignValW('vev',dsqrt(2*(vuewsb**2+vdewsb**2)))
c      call assignValW('mA_2',marunp**2)
c     2 expressions above are more right than below ones. 
c     But according to suspect
      call assignValW('vev',dsqrt(vev2))
      call assignValW('mA_2',madr2)
      call assignValW('mH1_2',mhd2)
      call assignValW('mH2_2',mhu2)

      END

      SUBROUTINE suspectMixing
      implicit NONE 
      real*8 u(2,2),v(2,2),z(4,4),dxmn(4)
      COMMON/SU_matino/u,v,z,dxmn
      real*8           thet,theb,thel
      COMMON/SU_outmix/thet,theb,thel
      integer i,j
      character*10 name

      real*8 val
  
      real*8            sgnmu0,tgbeta
      COMMON/SU_RADEWSB/sgnmu0,tgbeta
      real*8             msl,mtaur,mel,mer
      COMMON/SU_MSSMSLEP/msl,mtaur,mel,mer
      real*8             msq,mtr,mbr,muq,mur,mdr
      COMMON/SU_MSSMSQUA/msq,mtr,mbr,muq,mur,mdr
    

      do 1  i=1,4
      do 1  j=1,4
        write(name,FMT='(A2,I1,I1)') 'Zn',i,j
        call assignValW(name,Z(i,j))
1     continue
      


      call assignValW('Zl11',dcos(thel))
      call assignValW('Zl21',-dsin(thel))
      call assignValW('Zl12',dsin(thel)) 
      call assignValW('Zl22',dcos(thel))

      call assignValW('Zt11',dcos(thet))
      call assignValW('Zt21',-dsin(thet))
      call assignValW('Zt12',dsin(thet)) 
      call assignValW('Zt22',dcos(thet))

      call assignValW('Zb11',dcos(theb))
      call assignValW('Zb21',-dsin(theb))
      call assignValW('Zb12',dsin(theb)) 
      call assignValW('Zb22',dcos(theb))


c      call assignValW('MSlth',thel)   
c      call assignValW('MSbth',theb)   
c      call assignValW('MStth',thet)   

      call assignValW('Zu11',u(1,1))
      call assignValW('Zu21',u(2,1))
      call assignValW('Zu12',u(1,2)) 
      call assignValW('Zu22',u(2,2)) 
      call assignValW('Zv11',v(1,1))
      call assignValW('Zv21',v(2,1))
      call assignValW('Zv12',v(1,2))  
      call assignValW('Zv22',v(2,2))  

      END

      SUBROUTINE suspectHiggs
      implicit NONE

      real*8             dma,dml,dmh,dmch,dmarun
      COMMON/SU_hmass/   dma,dml,dmh,dmch,dmarun
      real*8             ml,mh,mch,alfa
      COMMON/SU_OUTHIGGS/ml,mh,mch,alfa

	call assignValW('Mh',dml)
	call assignValW('MHH',dmh)
	call assignValW('MHc',dmch)
        call assignValW('alpha',alfa)
      END

      SUBROUTINE suspectMass
      implicit NONE
      
      real*8 findValW
      real*8 ml,mr,MSeLL,MSeRR

      real*8             mc1,mc2,mn1,mn2,mn3,mn4,gluino
      COMMON/SU_OUTGINOS/mc1,mc2,mn1,mn2,mn3,mn4,gluino
      real*8             msl1,msl2,mse1,mse2,msn1,msntau
      COMMON/SU_OUTSLEP/ msl1,msl2,mse1,mse2,msn1,msntau
      real*8             mst1,mst2,msu1,msu2
      COMMON/SU_OUTSQU/  mst1,mst2,msu1,msu2
      real*8             msb1,msb2,msd1,msd2
      COMMON/SU_OUTSQD/  msb1,msb2,msd1,msd2
      real*8     	 msq,mtr,mbr,muq,mur,mdr
      COMMON/SU_MSSMSQUA/msq,mtr,mbr,muq,mur,mdr

      real*8            sgnmu0,tgbeta
      COMMON/SU_RADEWSB/sgnmu0,tgbeta

      real*8             msl,mtaur,mel,mer
      COMMON/SU_MSSMSLEP/msl,mtaur,mel,mer

      call assignValW('MC1'  ,mc1)
      call assignValW('MC2'  ,mc2)
      call assignValW('MNE1' ,mn1)
      call assignValW('MNE2' ,mn2)
      call assignValW('MNE3' ,mn3)
      call assignValW('MNE4' ,mn4)
      call assignValW('MSG'  ,gluino)

      call assignValW('MSl1' ,msl1)
      call assignValW('MSl2' ,msl2)

      call assignValW('MSt1' ,mst1)
      call assignValW('MSt2' ,mst2)

      call assignValW('MSb1' ,msb1)
      call assignValW('MSb2' ,msb2)

      call assignValW('MSne' ,msn1)
      call assignValW('MSnm' ,msn1)

      call assignValW('MSnl' ,msntau)
 
      call assignValW('MSeL',mse1)
      call assignValW('MSeR',mse2)
      call assignValW('MSmL',mse1)
      call assignValW('MSmR',mse2)

      call assignValW('MSuL' ,msu1)
      call assignValW('MSuR' ,msu2)
      call assignValW('MScL' ,msu1)
      call assignValW('MScR' ,msu2)

      call assignValW('MSdL' ,msd1)
      call assignValW('MSdR' ,msd2)

      call assignValW('MSsL' ,msd1)
      call assignValW('MSsR' ,msd2)

      END 

      integer FUNCTION suspect_err(errmess)
      implicit NONE
      real*8 errmess(10)
      suspect_err=0
      if( errmess(3).lt.0 .or. errmess(5).lt.0 .or.errmess(6).lt.0
     > .or. errmess(8).lt.0)then
        suspect_err=1
      endif
                                                                                
      if( errmess(1).lt.0 .or. errmess(2).lt.0 .or.errmess(4).lt.0
     >.or.errmess(7).lt.0 .or. errmess(9).lt.0 .or.errmess(10).lt.0)
     >then
        suspect_err=-1
      endif
                                                                                
      END

c++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

      integer FUNCTION suspectSUGRA(tb,gMG1,gMG2,gMG3,gAl,gAt,gAb,
     >sgn,gMHu,gMHd,gMl2,gMl3,gMr2,gMr3,gMq2,gMq3,gMu2,gMu3,gMd2,gMd3)

      implicit NONE

      real*8 tb,gMG1,gMG2,gMG3,gAl,gAt,gAb,
     >sgn,gMHu,gMHd,gMl2,gMl3,gMr2,gMr3,gMq2,gMq3,gMu2,gMd2,gMu3,gMd3

    
      real*8 errmess(10),findValW,mbmb
      integer suspect_err
      real*8            alfinv,sw2,alphas,mt,mb,mc,mtau
      COMMON/SU_SMPAR/  alfinv,sw2,alphas,mt,mb,mc,mtau
      real*8            qewsb,ehigh,elow
      COMMON/SU_RGSCAL/ qewsb,ehigh,elow
      real*8            m0,mhalf,a0
      COMMON/SU_MSUGRA/ m0,mhalf,a0
      real*8            sgnmu0,tgbeta
      COMMON/SU_RADEWSB/sgnmu0,tgbeta

      integer  ichoice(11)
C                   1  2  3  4  5  6  7  8  9  10 11
      DATA ichoice/ 1,21, 1, 1, 1, 1, 2, 1, 2, 2,  0/


      real*8             mhu2,mhd2,ma,mu
      COMMON/SU_MSSMHPAR/mhu2,mhd2,ma,mu
      real*8             m1,m2,m3
      COMMON/SU_MSSMGPAR/m1,m2,m3
      real*8             msl,mtaur,mel,mer
      COMMON/SU_MSSMSLEP/msl,mtaur,mel,mer
      real*8             msq,mtr,mbr,muq,mur,mdr
      COMMON/SU_MSSMSQUA/msq,mtr,mbr,muq,mur,mdr
      real*8             atau,at,ab
      COMMON/SU_ATRI3/   atau,at,ab
      real*8             al,au,ad
      COMMON/SU_ATRI12/  al,au,ad
      integer  INPUT, getDelFilesStat 
      external getDelFilesStat

      IF(getDelFilesStat().eq.0) then 
         INPUT=1
      ELSE 
         INPUT=11
      ENDIF

      m1=gMG1
      m2=gMG2
      m3=gMG3

      atau=gAl
      ab=  gAb
      at=  gAt

      al= gAl
      au= gAt
      ad= gAb

      mhu2=gMHu*ABS(gMHu)
      mhd2=gMHd*ABS(gMHd)

      mel=gMl2
      msl=gMl3
      mer=gMr2
      mtaur=gMr3       

      muq=gMq2
      msq=gMq3
      mur=gMu2
      mdr=gMd2
      mtr=gMu3 
      mbr=gMd3


      mhalf=gMG2      
      m0=gMHu 
      A0=gAl       

C      call null_suspect

      alfinv= 1.D0/findValW('alfEMZ')
c      sw2 =  findValW('SW')**2
c      sw2=0.23117d0
      sw2=0.23113
      alphas =findValW('alfSMZ')
      mt = findValW('Mtp')
      mc =1.4

      mb=findValW('MbMb')
C +0.0125
      mtau =findValW('Ml')
c      mtau = 1.7771d0

      ehigh = 1.9d16
      elow =91.19d0
      qewsb = 200d0
      sgnmu0=sgn
      tgbeta=tb
        
      CALL suspect2(1,INPUT,ICHOICE,ERRMESS)

      suspectSUGRA=suspect_err(ERRMESS)
      call suspectMSSMvar
      call suspectHiggs
      call suspectMass
      call suspectMixing 
      call suspectCouplings
      call assignValW('tb',tb)
      END




c      integer FUNCTION suspectAMSB(am0_,m32_, stgbeta,ssgnmu0,cq_,cu_,
c     *cd_,cl_,ce_,chu_,chd_)  
c     minimal model below !
      integer FUNCTION suspectAMSB(am0_,m32_, stgbeta,ssgnmu0)
      implicit NONE
      real*8 m32_,am0_,cq_,cu_,cd_,cl_,ce_,chu_,chd_
      real*8 m32,am0,cq,cu,cd,cl,ce,chu,chd
      COMMON/SU_AMSB/m32,am0,cq,cu,cd,cl,ce,chu,chd

       

      real*8 sm0,smhalf,sA0,stgbeta,ssgnmu0, findValW,mbmb 
      real*8 errmess(10)
      integer suspect_err,err
      real*8            alfinv,sw2,alphas,mt,mb,mc,mtau
      COMMON/SU_SMPAR/  alfinv,sw2,alphas,mt,mb,mc,mtau
      real*8            qewsb,ehigh,elow
      COMMON/SU_RGSCAL/ qewsb,ehigh,elow
      real*8            m0,mhalf,a0
      COMMON/SU_MSUGRA/ m0,mhalf,a0
      real*8            sgnmu0,tgbeta
      COMMON/SU_RADEWSB/sgnmu0,tgbeta

      integer  ichoice(11)
C                   1  2  3  4  5  6  7  8  9  10 11
      DATA ichoice/12,21, 1, 1, 1, 1, 2, 1, 2, 2, 0/
      DATA cq_/1/,cu_/1/,cd_/1/,cl_/1/,ce_/1/,chu_/1/,chd_/1/
      
      integer  INPUT, getDelFilesStat 
      external getDelFilesStat
      IF(getDelFilesStat().eq.0) then 
         INPUT=1
      ELSE 
         INPUT=11
      ENDIF


C      call null_suspect

      alfinv= 1.D0/findValW('alfEMZ')
c      sw2 = findValW('SW')**2
      sw2=0.23113
      alphas =findValW('alfSMZ')
      mt = findValW('Mtp')
      mb=findValW('MbMb')
C+0.0125
      mc =1.4
      mtau =findValW('Ml')

      ehigh = 1.9d16
      elow =91.19d0
      qewsb = 200d0
        
C      m0=sm0
C      mhalf=smhalf
C      A0=sA0
      sgnmu0=ssgnmu0

      tgbeta=stgbeta


      m32= m32_
      am0= am0_
      cq = cq_
      cu = cu_
      cd = cd_
      cl = cl_
      ce = ce_
      chu= chu_
      chd= chd_

      CALL suspect2(1,INPUT,ICHOICE,ERRMESS)

      suspectAMSB=suspect_err(ERRMESS)     
      call suspectMSSMvar
      call suspectHiggs
      call suspectMass
      call suspectMixing
      call suspectCouplings
      call assignValW('tb',stgbeta) 
      END


CC      integer FUNCTION suspectGMSB(am0_,m32_, stgbeta,ssgnmu0,cq_,cu_,
CC     *cd_,cl_,ce_,chu_,chd_)  
CC
CC      implicit NONE
CC      real*8 m32_,am0_,cq_,cu_,cd_,cl_,ce_,chu_,chd_
CC      real*8 m32,am0,cq,cu,cd,cl,ce,chu,chd
CC      COMMON/SU_AMSB/m32,am0,cq,cu,cd,cl,ce,chu,chd
CC
CC       
CC
CC      real*8 sm0,smhalf,sA0,stgbeta,ssgnmu0, findValW,mbmb 
CC      real*8 errmess(10)
CC      integer suspect_err
CC      real*8            alfinv,sw2,alphas,mt,mb,mc,mtau
CC      COMMON/SU_SMPAR/  alfinv,sw2,alphas,mt,mb,mc,mtau
CC      real*8            qewsb,ehigh,elow
CC      COMMON/SU_RGSCAL/ qewsb,ehigh,elow
CC      real*8            m0,mhalf,a0
CC      COMMON/SU_MSUGRA/ m0,mhalf,a0
CC      real*8            sgnmu0,tgbeta
CC      COMMON/SU_RADEWSB/sgnmu0,tgbeta
CC      real*8         mgmmess,mgmsusy
CC      integer                        nl,nq 
CC      COMMON/SU_gmsb/mgmmess,mgmsusy,nl,nq
CC      integer  ichoice(10)
CCC                   1  2  3  4  5  6  7  8  9  10 
CC      DATA ichoice/11,21, 1, 1, 1, 1, 2, 1, 2, 3/
CC            
CC
CCC      call null_suspect
CC
CC      alfinv= 127.938d0
CC      sw2 = .23117d0
CC      alphas =findValW('alfSMZ')
CC      mt = findValW('Mtp')
CC      mb=findValW('MbMb')+0.0125
CC      mc =1.4
CC      mtau =1.7771d0
CC
CC      ehigh = 1.9d16
CC      elow =91.19d0
CC      qewsb = 200d0
CC        
CCC      m0=sm0
CCC      mhalf=smhalf
CCC      A0=sA0
CC      sgnmu0=ssgnmu0
CC
CC      tgbeta=stgbeta
CC
CC
CC      m32= m32_
CC      am0= am0_
CC      cq = cq_
CC      cu = cu_
CC      cd = cd_
CC      cl = cl_
CC      ce = ce_
CC      chu= chu_
CC      chd= chd_
CC
CC
CC      CALL suspect2(1,1,ICHOICE,ERRMESS)
CC
CC      suspectAMSB=suspect_err(ERRMESS)     
CC      call suspectMSSMvar
CC      call suspectHiggs
CC      call suspectMass
CC      call suspectMixing
CC      call assignValW('tb',stgbeta)   
CC      END



      integer FUNCTION MSSMspect(LCon)

      implicit none
      integer suspect_err,err,LCon
      integer ichoice(11)
      real*8  errmess(10),findValW,mbmb
      
      real*8             alfinv,sw2,alphas,mt,mb,mc,mtau
      COMMON/SU_SMPAR/   alfinv,sw2,alphas,mt,mb,mc,mtau

      real*8             mhu2,mhd2,ma,mu
      COMMON/SU_MSSMHPAR/mhu2,mhd2,ma,mu
      real*8             m1,m2,m3
      COMMON/SU_MSSMGPAR/m1,m2,m3
      real*8             msl,mtaur,mel,mer
      COMMON/SU_MSSMSLEP/msl,mtaur,mel,mer
      real*8             msq,mtr,mbr,muq,mur,mdr
      COMMON/SU_MSSMSQUA/msq,mtr,mbr,muq,mur,mdr
      real*8             atau,at,ab
      COMMON/SU_ATRI3/   atau,at,ab
      real*8             al,au,ad
      COMMON/SU_ATRI12/  al,au,ad
C Input is tgbeta, but it is tan(b) at mSUSY scale
      real*8             sgnmu0,tgbeta
      COMMON/SU_RADEWSB/ sgnmu0,tgbeta
      real*8             mc1,mc2,mn1,mn2,mn3,mn4,gluino
      COMMON/SU_OUTGINOS/mc1,mc2,mn1,mn2,mn3,mn4,gluino
C tbeta in output.  
C      real*8        nf,cpi,zm,wm,tbeta
C      COMMON/SU_cte/nf,cpi,zm,wm,tbeta

      real*8 msu1,msu2,msd1,msd2,mse1,mse2,msn1,msntau,
     .      msta1,msta2,msb1,msb2,mst1,mst2,thet,theb,thel 
      COMMON/SU_bpew/msu1,msu2,msd1,msd2,mse1,mse2,msn1,msntau,
     .      msta1,msta2,msb1,msb2,mst1,mst2,thet,theb,thel


c                   1  2  3  4  5  6  7  8  9 10 11 
      DATA ichoice/0, 21, 1, 1, 1, 0, 2, 1, 2, 2, 0/   

      integer  INPUT, getDelFilesStat 
      external getDelFilesStat

      IF(getDelFilesStat().eq.0) then 
         INPUT=1
      ELSE 
         INPUT=11
      ENDIF



c  "SM-like" input:
C      call null_suspect
      alfinv= 1.d0/findValW('alfEMZ')
      
      sw2=0.23113
      alphas =findValW('alfSMZ')
      mt =findValW('Mtp')
      mb=findValW('MbMb')
C+0.0125
      mtau =findValW('Ml')   
  
      mu    =findValW('mu') 
      sgnmu0=ABS(mu)/mu  
      m1    =findValW('MG1')
      m2    =findValW('MG2')
      m3    =findValW('MG3')
      mel   =findValW('Ml2') 
      msl   =findValW('Ml3')   
      mer   =findValW('Mr2')  
      mtaur =findValW('Mr3')
      muq   =findValW('Mq2')
      msq   =findValW('Mq3')  
      mur   =findValW('Mu2') 
      mtr   =findValW('Mu3')
      mdr   =findValW('Md2')
      mbr   =findValW('Md3')
      at    =findValW('At')
      ab    =findValW('Ab')
      atau  =findValW('Al')
      al    =findValW('Am')
      tgbeta=findValW('tb')
      ma    =findValW('MH3')  
      ad=0
      au=0
c      mst1 =  findValW('MSt1')
c      mst2 =  findValW('MSt2')
c      msb1 =  findValW('MSb1')
c      msb2 =  findValW('MSb2')
c      thet =  atan2( findValW('Zt12'),findValW('Zt11'))
c      theb =  atan2( findValW('Zb12'),findValW('Zb11'))

      if(LCon.ne.0) then
        ichoice(7)=2
      else 
        ichoice(7)=0 
      endif
      CALL suspect2(1,INPUT, ICHOICE,ERRMESS)
      MSSMspect=suspect_err(ERRMESS)
       
      call suspectHiggs

      if(LCon.ne.0) then 
        call suspectMass
        call suspectMixing
      endif
       call suspectCouplings
      END

#include"ssusy_path.h"

/*===================================*/
#include"micromegas.h"
#include"micromegas_aux.h"

#include<sys/wait.h>

int  softSusySUGRA(double tb, double gMG1,double gMG2,double gMG3,
             double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
             double gMl2,double gMl3,double gMr2,double gMr3,
             double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3)
{ 
   char  fin[]="LesHin";
   char  fout[]="LesHout";
   char buff[500];
   int del=getdelfilesstat_(); 
   int err=sugraLesH(fin, tb, gMG1,gMG2,gMG3,
             gAl, gAt, gAb, sgn, gMHu, gMHd,
             gMl2,gMl3,gMr2,gMr3,
             gMq2,gMq3,gMu2,gMu3,gMd2,gMd3);

   { FILE *f=fopen(fin,"a");
     fprintf(f,"%s\n%s\n","Block SOFTSUSY               # SOFTSUSY specific inputs",
"         2   0                    # quark mixing option");
     fclose(f);
   }  
  
   if(err) {printf("can not write down LesHin  file\n"); exit(10);}  
   un_link(fout);
   sprintf(buff,"pwd=`pwd`; cd %s ;   ./softpoint.x leshouches < $pwd/%s > $pwd/%s",SOFTSUSY,fin,fout);
   err=system(buff);
   if(del) un_link(fin);
   if(err<0 || WIFSIGNALED(err)>0 ){if(del) un_link(fout);  exit(err);}
   if( WEXITSTATUS(err) >0) { if(del) un_link(fout); return -1;}

   err=readLesH(fout,0);
   if(del) un_link(fout);
   return err;
}

#define xxxSUGRAc softSusySUGRAc
#define xxxSUGRA  softSusySUGRA
#include "sugrac.inc"


int  softSusyAMSB(double m0,double m32, double tb, double sgn)
{ 
   char  fin[]="LesHin";
   char  fout[]="lesHout";
   char buff[500];
   int err=amsbLesH(fin, m0,m32, tb, (int)sgn);
   int del= getdelfilesstat_(); 
   if(err) return -1;

   { FILE *f=fopen(fin,"a");
     fprintf(f,"%s\n%s\n","Block SOFTSUSY               # SOFTSUSY specific inputs",
"         2   0                    # quark mixing option");
     fclose(f);
   }  

   un_link(fout);
   sprintf(buff,"pwd=`pwd`; cd %s ;   ./softpoint.x leshouches < $pwd/%s > $pwd/%s",SOFTSUSY,fin,fout);
   err=system(buff);
   if(del)un_link(fin);
   if(err){ printf("\n SoftSusy can not be exequted or was finished with error\n"
                   "The command was: %s\n",buff);
            if(del) un_link(fout);        
                    return -2;
          }   
   err=readLesH(fout,0);
   if(del) un_link(fout);
   return err;
}


int  softSusyGMSB(double L,double Mmess,  double tb, double sgn, int N5,double cGrav)
{ 
   char  fin[]="LesHin";
   char  fout[]="lesHout";
   char buff[500];
   int err=gmsbLesH(fin,  L, Mmess, tb, (int)sgn, N5, cGrav);
   if(err) return -1;
   
   sprintf(buff,"pwd=`pwd`; cd %s ;   ./softpoint.x leshouches < $pwd/%s > $pwd/%s",SOFTSUSY,fin,fout);
   err=system(buff);
   if(err){ printf("\n SoftSusy can not be exequted or was finished with error\n"
                   "The command was: %s\n",buff);
                    return -2;
          }   
   err=readLesH(fout,0);
   return err;
}

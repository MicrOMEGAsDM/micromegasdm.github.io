
#include "micromegas.h"

#define NV_MSSM 155

static  struct{char * name; double val;}   mssmVar[NV_MSSM]=
{
{"alfEMZ",7.8180608e-03},
{"alfSMZ",1.172000e-01},
{"SW",    4.810000e-01},
{"MZ",    9.118840e+01},
{"Ml",    1.777000e+00},
{"MbMb",  4.230000e+00},
{"Mtp",   1.750000e+02},
{"MH3",   3.000000e+02},
{"Mh",    0.000000e+00},
{"MHH",   0.000000e+00},
{"MHc",   0.000000e+00},
{"tb",    1.000000e+01},
{"alpha",-1.570800e+00},
{"mu",    1.000000e+03},
{"Am",    0.000000e+00},
{"Al",    0.000000e+00},
{"Ab",    0.000000e+00},
{"At",    0.000000e+00},
{"MNE1",  1.094080e+02},
{"MNE2",  1.973670e+02},
{"MNE3", -1.002830e+03},
{"MNE4",  1.006050e+03},
{"MC1",   1.973490e+02},
{"MC2",   1.006960e+03},
{"MSG",   1.000000e+03},
{"MSne",  9.979600e+02},
{"MSnm",  9.979600e+02},
{"MSnl",  9.979600e+02},
{"MSeL",  1.000910e+03},
{"MSeR",  1.001130e+03},
{"MSmL",  1.000480e+03},
{"MSmR",  1.001560e+03},
{"MSl1",  9.921040e+02},
{"MSl2",  1.009860e+03},
{"MSuL",  9.985690e+02},
{"MSuR",  9.993920e+02},
{"MSsL",  1.001730e+03},
{"MSsR",  1.000300e+03},
{"MSt1",  1.002720e+03},
{"MSt2",  1.017590e+03},
{"MSdL",  1.001730e+03},
{"MSdR",  1.000300e+03},
{"MScL",  9.985640e+02},
{"MScR",  9.993990e+02},
{"MSb1",  9.884350e+02},
{"MSb2",  1.013450e+03},
{"Zn11", -9.988750e-01},
{"Zn21", -1.615420e-02},
{"Zn31",  2.456590e-02},
{"Zn41", -3.719330e-02},
{"Zn12",  1.219980e-02},
{"Zn22", -9.960560e-01},
{"Zn32", -4.233560e-02},
{"Zn42",  7.701540e-02},
{"Zn13", -4.486190e-02},
{"Zn23",  8.375570e-02},
{"Zn33", -7.050390e-01},
{"Zn43",  7.027750e-01},
{"Zn14",  9.293060e-03},
{"Zn24", -2.442380e-02},
{"Zn34", -7.074770e-01},
{"Zn44", -7.062530e-01},
{"Zu11",  9.928800e-01},
{"Zu21",  1.191220e-01},
{"Zu12", -1.191220e-01},
{"Zu22",  9.928800e-01},
{"Zv11",  9.993940e-01},
{"Zv21",  3.480750e-02},
{"Zv12", -3.480750e-02},
{"Zv22",  9.993940e-01},
{"Zl11",  9.293060e-03},
{"Zl21", -2.442380e-02},
{"Zl12", -7.074770e-01},
{"Zl22", -7.062530e-01},
{"Zt11",  9.928800e-01},
{"Zt21",  1.191220e-01},
{"Zt12", -1.191220e-01},
{"Zt22",  9.928800e-01},
{"Zb11",  9.993940e-01},
{"Zb21",  3.480750e-02},
{"Zb12", -3.480750e-02},
{"Zb22",  9.993940e-01},
{"QSUSY",    0        },
{"Yl",    0           },
{"Yt",    0           },
{"Yb",    0           },
{"gY",    0           },
{"g2",    0           },
{"g3",    0           },
{"tb_Q",  0           },
{"vev",   0           },
{"mA_2",  0           },
{"mH1_2", 0           },
{"mH2_2", 0           },
{"Mb",    4.620000e+00},
{"Mt",    1.750000e+02},
{"MW",    80.419}, 
{"sWidth",0.01},
{"dMb",   0.000000e+00},
{"dMbOn", 1.},
{"wt",    1.752400e+00},
{"wZ",    2.494400e+00},
{"wW",    2.088950e+00},
{"wh",    0.000000e+00},
{"wHh",   0.000000e+00},
{"wH3",   0.000000e+00},
{"wHc",   0.000000e+00},
{"wC1",   0.000000e+00},
{"wC2",   0.000000e+00},
{"wNE1",  0.000000e+00},
{"wNE2",  0.000000e+00},
{"wNE3",  0.000000e+00},
{"wNE4",  0.000000e+00},
{"wSG",   0.000000e+00},
{"wSuL",  0.000000e+00},
{"wSuR",  0.000000e+00},
{"wScL",  0.000000e+00},
{"wScR",  0.000000e+00},
{"wSt1",  0.000000e+00},
{"wSt2",  0.000000e+00},
{"wSdR",  0.000000e+00},
{"wSdL",  0.000000e+00},
{"wSsL",  0.000000e+00},
{"wSsR",  0.000000e+00},
{"wSb1",  0.000000e+00},
{"wSb2",  0.000000e+00},
{"wSne",  0.000000e+00},
{"wSnm",  0.000000e+00},
{"wSnl",  0.000000e+00},
{"wSeL",  0.000000e+00},
{"wSeR",  0.000000e+00},
{"wSmL",  0.000000e+00},
{"wSmR",  0.000000e+00},
{"wSl1",  0.000000e+00},
{"wSl2",  0.000000e+00},
{"EE",    3.134100e-01},
{"SC",    1.220000e+00},
{"MG1",   1.100000e+02},
{"MG2",   2.000000e+02},
{"MG3",   3.000000e+02},
{"Ml1",   1.000000e+03},
{"Ml2",   1.000000e+03},
{"Ml3",   1.000000e+03},
{"Mr1",   1.000000e+03},
{"Mr2",   1.000000e+03},
{"Mr3",   1.000000e+03},
{"Mq1",   1.000000e+03},
{"Mq2",   1.000000e+03},
{"Mq3",   1.000000e+03},
{"Mu1",   1.000000e+03},
{"Mu2",   1.000000e+03},
{"Mu3",   1.000000e+03},
{"Md1",   1.000000e+03},
{"Md2",   1.000000e+03},
{"Md3",   1.000000e+03}
};

void printVar(FILE *f, int N)
{
  int i;
  fprintf(f,"\n# MSSM parameters:\n");
  if(N>NV_MSSM) N=NV_MSSM;
  for(i=0;i<N;i++) fprintf(f,"%-6.6s   %f\n", mssmVar[i].name, mssmVar[i].val);
}


int assignVal(char * name, double val)
{
  int i;
  for(i=0;i<NV_MSSM;i++)
  { /*printf("name[%d]=%s\n",i,mssmVar[i].name);*/
    if(strcmp(name,mssmVar[i].name)) continue;
    mssmVar[i].val=val; return 0;
  }
  return 1;
}


double *  findVarAddress(char * name)
{
  int i;
  for(i=0;i<NV_MSSM;i++) if(!strcmp(name,mssmVar[i].name))
  return &(mssmVar[i].val);
  return NULL;
}

int findVal(char * name, double * val)
{
  double * va=findVarAddress(name); 
  if(va){*val=*va; return 0;} else  return 1; 
}



double alfEMZ(double ok){ return findValW("alfEMZ");}
double alfSMZ(double ok){ return findValW("alfSMZ");}
double EE(double ok)    { return findValW("EE");}
double SC(double ok)    { return findValW("SC");}
double SW(double ok)    { return findValW("SW");}
double MZ(double ok)    { return findValW("MZ");}
double Ml(double ok)    { return findValW("Ml");}
double MbMb(double ok)  { return findValW("MbMb");}
double Mtp(double ok)   { return findValW("Mtp");}
double Mb(double ok)    { return findValW("Mb");}
double Mt(double ok)    { return findValW("Mt");}
double MH3(double ok)   { return findValW("MH3");}
double Mh(double ok)    { return findValW("Mh");}
double MHH(double ok)   { return findValW("MHH");}
double MHc(double ok)   { return findValW("MHc");}
double tb(double ok)    { return findValW("tb");}
double alpha(double ok) { return findValW("alpha");}
double mu(double ok)    { return findValW("mu");}
double Am(double ok)    { return findValW("Am");}
double Al(double ok)    { return findValW("Al");}
double Ab(double ok)    { return findValW("Ab");}
double At(double ok)    { return findValW("At");}
double MNE1(double ok)  { return findValW("MNE1");}
double MNE2(double ok)  { return findValW("MNE2");}
double MNE3(double ok)  { return findValW("MNE3");}
double MNE4(double ok)  { return findValW("MNE4");}
double MC1(double ok)   { return findValW("MC1");}
double MC2(double ok)   { return findValW("MC2");}
double MSG(double ok)   { return findValW("MSG");}
double MSne(double ok)  { return findValW("MSne");}
double MSnm(double ok)  { return findValW("MSnm");}
double MSnl(double ok)  { return findValW("MSnl");}
double MSeL(double ok)  { return findValW("MSeL");}
double MSeR(double ok)  { return findValW("MSeR");}
double MSmL(double ok)  { return findValW("MSmL");}
double MSmR(double ok)  { return findValW("MSmR");}
double MSl1(double ok)  { return findValW("MSl1");}
double MSl2(double ok)  { return findValW("MSl2");}
double MSuL(double ok)  { return findValW("MSuL");}
double MSuR(double ok)  { return findValW("MSuR");}
double MSsL(double ok)  { return findValW("MSsL");}
double MSsR(double ok)  { return findValW("MSsR");}
double MSt1(double ok)  { return findValW("MSt1");}
double MSt2(double ok)  { return findValW("MSt2");}
double MSdL(double ok)  { return findValW("MSdL");}
double MSdR(double ok)  { return findValW("MSdR");}
double MScL(double ok)  { return findValW("MScL");}
double MScR(double ok)  { return findValW("MScR");}
double MSb1(double ok)  { return findValW("MSb1");}
double MSb2(double ok)  { return findValW("MSb2");}
double Zn11(double ok)  { return findValW("Zn11");}
double Zn21(double ok)  { return findValW("Zn21");}
double Zn31(double ok)  { return findValW("Zn31");}
double Zn41(double ok)  { return findValW("Zn41");}
double Zn12(double ok)  { return findValW("Zn12");}
double Zn22(double ok)  { return findValW("Zn22");}
double Zn32(double ok)  { return findValW("Zn32");}
double Zn42(double ok)  { return findValW("Zn42");}
double Zn13(double ok)  { return findValW("Zn13");}
double Zn23(double ok)  { return findValW("Zn23");}
double Zn33(double ok)  { return findValW("Zn33");}
double Zn43(double ok)  { return findValW("Zn43");}
double Zn14(double ok)  { return findValW("Zn14");}
double Zn24(double ok)  { return findValW("Zn24");}
double Zn34(double ok)  { return findValW("Zn34");}
double Zn44(double ok)  { return findValW("Zn44");}
double Zu11(double ok)  { return findValW("Zu11");}
double Zu21(double ok)  { return findValW("Zu21");}
double Zu12(double ok)  { return findValW("Zu12");}
double Zu22(double ok)  { return findValW("Zu22");}
double Zv11(double ok)  { return findValW("Zv11");}
double Zv21(double ok)  { return findValW("Zv21");}
double Zv12(double ok)  { return findValW("Zv12");}
double Zv22(double ok)  { return findValW("Zv22");}
double Zl11(double ok)  { return findValW("Zl11");}
double Zl21(double ok)  { return findValW("Zl21");}
double Zl12(double ok)  { return findValW("Zl12");}
double Zl22(double ok)  { return findValW("Zl22");}
double Zt11(double ok)  { return findValW("Zt11");}
double Zt21(double ok)  { return findValW("Zt21");}
double Zt12(double ok)  { return findValW("Zt12");}
double Zt22(double ok)  { return findValW("Zt22");}
double Zb11(double ok)  { return findValW("Zb11");}
double Zb21(double ok)  { return findValW("Zb21");}
double Zb12(double ok)  { return findValW("Zb12");}
double Zb22(double ok)  { return findValW("Zb22");}
/*double dMb(double ok1)   { return findValW("dMb");}*/
double MG1(double ok)   { return findValW("MG1");}
double MG2(double ok)   { return findValW("MG2");}
double MG3(double ok)   { return findValW("MG3");}
double Ml1(double ok)   { return findValW("Ml1");}
double Ml2(double ok)   { return findValW("Ml2");}
double Ml3(double ok)   { return findValW("Ml3");}
double Mr1(double ok)   { return findValW("Mr1");}
double Mr2(double ok)   { return findValW("Mr2");}
double Mr3(double ok)   { return findValW("Mr3");}
double Mq1(double ok)   { return findValW("Mq1");}
double Mq2(double ok)   { return findValW("Mq2");}
double Mq3(double ok)   { return findValW("Mq3");}
double Mu1(double ok)   { return findValW("Mu1");}
double Mu2(double ok)   { return findValW("Mu2");}
double Mu3(double ok)   { return findValW("Mu3");}
double Md1(double ok)   { return findValW("Md1");}
double Md2(double ok)   { return findValW("Md2");}
double Md3(double ok)   { return findValW("Md3");}


double * VarDump(void)
{
  double * b=malloc(sizeof(double)*NV_MSSM);
  int i;
  for(i=0;i<NV_MSSM;i++) b[i]=mssmVar[i].val;
  return b;  
}

void VarRest(double *b)
{ int i; for(i=0;i<NV_MSSM;i++)mssmVar[i].val=b[i]; }

#include"micromegas.h"
#include"micromegas_aux.h"
#include"calchep/include/num_in.h"

extern int isajetsugra_(double*,double*,double*,double*,double*,double*,double*,
                        double*,double*,double*,double*,double*,double*,double*,
                        double*,double*,double*,double*,double*,double*);
int  isajetSUGRA(double tb, double gMG1,double gMG2,double gMG3,
             double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
             double gMl2,double gMl3,double gMr2,double gMr3,
             double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3)
{ return
   isajetsugra_(&tb, &gMG1,&gMG2,&gMG3,
             &gAl, &gAt, &gAb, &sgn, &gMHu, &gMHd,
             &gMl2,&gMl3,&gMr2,&gMr3,
             &gMq2,&gMq3,&gMu2,&gMu3,&gMd2,&gMd3);
}

#define xxxSUGRAc isajetSUGRAc
#define xxxSUGRA  isajetSUGRA
#include "sugrac.inc"

extern int isajetamsb_(double*,double*,double*,double*);

int isajetAMSB(double am0,double m32,double tb,double sgn)
{ return isajetamsb_(&am0,&m32,&tb,&sgn);}

/*
int  isajetGMSB(double Lambda, double Mmess,double tb, double SGNMU,double N5, double cGrav, 
double Rsl, double dmH_d2, double dmH_u2, double d_Y, double n5_1, double n5_2, double n5_3)
{ 
  return  isajetgmsb_(&Lambda, &Mmess,&tb,&SGNMU,&N5,&cGrav,
     &Rsl,&dmH_d2,&dmH_u2,&d_Y,&n5_1,&n5_2,&n5_3);
}
*/

extern int isajetewsbtot_(void);

int  isajetEwsbMSSM(int LCon)
{ int err;
  err=tree2LesH();
  err=isajetewsbtot_();
  if(err<0) return err;
  if(LCon) 
  { double MbMb=findValW("MbMb"),Q;                                                                                
    Q=initQCD(findValW("alfSMZ"),1.4,MbMb,findValW("Mtp"));
    if(Q<0 || Q>=MbMb) return  2; 
    Q=fabs(findValW("MNE1"));
    assignValW("Mt",MtEff(2*Q));
    assignValW("Mb",MbEff(2*Q));
    return 0;
  }else return tree2LesH();
  return 0;
}

int  isajetewsbmssm_(int* LCon) { return isajetEwsbMSSM(*LCon);}

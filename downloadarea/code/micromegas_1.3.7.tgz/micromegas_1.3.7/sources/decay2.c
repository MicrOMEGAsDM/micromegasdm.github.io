#include "micromegas.h"
#include "micromegas_aux.h"
#include "num_out_hhh.h"


double decay2(char *pName, int k, char *n1, char * n2)
{ static double **link=NULL;
  int err,nsub,i; 
  double m1,m2,m3;
  static double  MtR, MbR, SC;
  int kk=k;

  if(link==NULL)
  { link=(double**) malloc(nvar_hhh*sizeof(double*));
    for(i=0;i<nvar_hhh;i++)
     {      if(strcmp(varName_hhh[i+1],"Mt")==0) link[i]=&MtR;
       else if(strcmp(varName_hhh[i+1],"Mb")==0) link[i]=&MbR;
       else if(strcmp(varName_hhh[i+1],"SC")==0) link[i]=&SC;
       else  link[i]=findVarAddress(varName_hhh[i+1]);
       if(link[i]==NULL) printf("width_2: name '%s' not found\n",varName_hhh[i+1]);
     }
  }

  n1[0]=0; n2[0]=0;
  if(k<1||k>nprc_hhh) return 0;
     
  for(nsub=1; nsub<=nprc_hhh; nsub++)
  { if(strcmp(pinf_hhh(nsub,1,&m1),pName)==0)
    { if(kk==k) 
      { double Q;
        if(strcmp(pName,"h")==0 ||strcmp(pName,"H")==0 ||
           strcmp(pName,"H3")==0||strcmp(pName,"H+")==0||
           strcmp(pName,"H-")==0)
        { MtR=MtEff(m1); MbR=MbEff(m1);}
        else { MtR=findValW("Mtp"); MbR=4.5;}
        if(m1<4.5) Q=4.5; else Q=m1;
        SC=sqrt(4*M_PI*alphaQCD(Q));        
        for(i=0;i<nvar_hhh;i++) if(link[i]) va_hhh[i+1]=*(link[i]); 
        if(calcFunc_hhh()){ FError=1; return -1;} 
      } 
      kk--;
    }
    if(kk==0) 
    {  strcpy(n1, pinf_hhh(nsub,2,&m2)); 
       strcpy(n2, pinf_hhh(nsub,3,&m3));
       if (m1 > m2 + m3) 
       {  double pvect[12]={0,0,0,0,0,0,0,0,0,0,0,0};
          double md=m2-m3;
          double ms=m2+m3;
          double pRestOut=sqrt((m1*m1-ms*ms)*(m1*m1-md*md))/(2*m1);
          double totcoef= pRestOut/(8. * M_PI * m1*m1);
          pvect[0]=m1; pvect[4]=m2; pvect[8]=m3;
          pvect[7]=pRestOut; pvect[11]=-pRestOut;
          return  totcoef*sqme_hhh(nsub,pvect,&err);
       }
       return 0;   
    }    
  }
  return 0;
}


double width2(char * pName, int *first)
{ static double **link=NULL;
  int i,nsub,err;
  double width,m1;

  if(link==NULL)
  { link=(double**) malloc(nvar_hhh*sizeof(double*));
    for(i=0;i<nvar_hhh;i++)
    { link[i]=findVarAddress(varName_hhh[i+1]);
      if(link[i]==NULL) printf("width_2: name '%s' not found\n",varName_hhh[i+1]);
    }
  }
   
  for(i=0;i<nvar_hhh;i++) if(link[i]) va_hhh[i+1]=*(link[i]); 
  if(calcFunc_hhh()){ FError=1; return -1;} 
  if(first && (*first!=0)) nsub=*first;
  else 
  { for(nsub=1; nsub<=nprc_hhh && strcmp(pinf_hhh(nsub,1,&m1),pName) ; nsub++);
    if(first) *first=nsub;
  }

  for(width=0; nsub<=nprc_hhh; nsub++)
  {  double m1,m2,m3;
     double pvect[12]={0,0,0,0,0,0,0,0,0,0,0,0};
     char *out2, *out3;
     if(strcmp(pinf_hhh(nsub,1,&m1),pName)) break; 
     out2= pinf_hhh(nsub,2,&m2); out3=pinf_hhh(nsub,3,&m3);
/*
     if(strchr(out2,'~')) continue;
     if(strchr(out3,'~')) continue;
*/
     if (m1 > m2 + m3)
     {
        double md=m2-m3;
        double ms=m2+m3;
        double pRestOut=sqrt((m1*m1-ms*ms)*(m1*m1-md*md))/(2*m1);
        double totcoef= pRestOut/(8. * M_PI * m1*m1);
/*
printf("%s(%f) -> %s(%f) %s(%f) (%f)\n",pName,m1, out2,m2,out3,m3, totcoef*sqme_hhh(nsub,pvect,&err));
*/
        width += totcoef*sqme_hhh(nsub,pvect,&err);
     }
  }  

  return width;
}

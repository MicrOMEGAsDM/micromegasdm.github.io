
#ifndef __MICRO_AUX__
#define __MICRO_AUX__


/*=============================================
C->F and F->C    string convertation     
===============================================*/

extern void  cName2f(char*c_name,char*f_name,int len);
extern void  fName2c(char*c_name,char*f_name,int len);


/* ============================================
    function for CalcHEP interaction session
===============================================*/ 

extern double  ewsbMSSMc(double smOk,
 double tb, double MG1,double MG2,double MG3,
 double Am, double Al, double At, double Ab,
 double MH3,double mu,
 double Ml1,double Ml3,
 double Mr1,double Mr3,double Mq1,double Mq3,
 double Mu1,double Mu3,double Md1,double Md3,
         double lCon);

extern double suspectSUGRAc(double smOk,
  double tb, double gMG1,double gMG2,double gMG3,
  double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
  double gMl2,double gMl3,double gMr2,double gMr3,
  double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3);

extern double isajetSUGRAc(double smOk,
  double tb, double gMG1,double gMG2,double gMG3,
  double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
  double gMl2,double gMl3,double gMr2,double gMr3,
  double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3);

extern double softsusySUGRAc(double smOk,
  double tb, double gMG1,double gMG2,double gMG3,
  double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
  double gMl2,double gMl3,double gMr2,double gMr3,
  double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3);   

extern double sphenoSUGRAc(double smOk,
  double tb, double gMG1,double gMG2,double gMG3,
  double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
  double gMl2,double gMl3,double gMr2,double gMr3,
  double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3);   

/*====================================
   Tools for integration 
=====================================*/

extern double simpson(double (*func)(double), double a, double b, double eps);
extern double gauss(double (*func)(double), double a, double b, int n);
extern int  odeint(double*ystart,int nvar,double x1,double x2, double eps,
                   double h1, void(*derivs)(double,double*,double *));

extern double K2pol(double x); /*bessk1(1/x)*exp(1/x)*sqrt(2/M_PI/x);*/
extern double K1pol(double x); /*bessk2(1/x)*exp(1/x)*sqrt(2/M_PI/x);*/


/*=============================================
   Evaluation of mass spectrum in case of general MSSM via suspect
===============================================*/
extern int MSSMspect(int LCon);


extern int FError;

typedef struct read_param_tag
{ double U[3][3], V[3][3], T[3][3], mc[3], mst[3], msq1, mglu, At, Ab;
 double B[3][3], msb[3], mss[3], mn[5], N[5][5],msnmu, tb;
  double m1, m2, mu,MW, MZ, Mt, Mb, Mhc, Vts,Vtb,Vcb,ee, sw, alphS_MZ;
}  read_param_tag;

extern void calc_eps(struct read_param_tag* param, double *eps_b, double *eps_bp, double *eps_tps);
extern int read_prm(struct read_param_tag* param);


extern int sugraLesH(char *fname,  double tb, double gMG1,double gMG2,double gMG3,
    double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
    double gMl2,double gMl3,double gMr2,double gMr3,
    double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3);

extern int gmsbLesH(char *fname, double L,double Mmess, double  tb, int  sgn, int N5, double cGrav);
extern int amsbLesH(char *fname, double m0,double m32, double  tb, int  sgn);
extern int sugraEXLesH(char *fname, double m0, double mg1,  double mg2, double mg3,double a0,double tb,int sgn);


extern void CheckNCsector(double *zero_, double*m1_, double*m2_,double*mu_, double*tb_,
double *mz_, double* sw_);

extern double * VarDump(void);
extern void VarRest(double *b);

extern double width2(char * pName, int *first);

extern int  tree2LesH(void);
extern int  getdelfilesstat_(void);

#endif

#include "micromegas.h"
#include "micromegas_aux.h"

double saveSM(double MbMb,double Mtp,double SW,double alfSMZ,double alfEMZ,double MZ,double Ml)
{
  double Qmin;
  assignValW("MbMb",  MbMb); 
  assignValW("Mtp",   Mtp);
  assignValW("SW",    SW);
  assignValW("alfSMZ",alfSMZ);
  assignValW("alfEMZ",alfEMZ);
  assignValW("MZ",    MZ);
  assignValW("Ml",    Ml);
  Qmin=initQCD(alfSMZ,1.4,MbMb,Mtp);
  if(Qmin<0 || Qmin>MbMb) return 0; else return 1;
}

double dMb(double ok)      {return deltaMb();}
double  deltarho(double ok){ return  deltarho_();} 
double  gmuon(double ok)   { return  gmuon_();   }
double  bsgnlo(double ok)  { return  bsgnlo_();  }
double  bsmumu(double ok)  { return  bsmumu_();  }

double  Omega(double qcdOk, double dMbOn)
{ double omega;
  int dmb_on=(dMbOn>0);
  double * b=VarDump();
  assignValW("sWidth",0.01);
  calcDep(dmb_on);
  omega=darkOmega(NULL,1,1.E-6);
  VarRest(b); free(b);
  return omega;
}

double MTrun(double ok, double Q) { return MtRun(Q);}
double MBrun(double ok, double Q) { return MbRun(Q);}


double alphaSRun(double ok, double Q){ return  alphaQCD(Q);}

double saveQCD(double Mt, double Mb, double dMb)
{ assignValW("Mt",Mt);
  assignValW("Mb",Mb);
  assignValW("dMb",dMb); 
  return 1;
}  


 double wZ  (double ok){ static int first=0;  return width2("Z",&first);}
 double wW  (double ok){ static int first=0;  return width2("W+",&first);}
 double wt  (double ok){ static int first=0;  return width2("t",&first);}
 double wb  (double ok){ static int first=0;  return width2("b",&first);}
 double wh  (double ok){ static int first=0;  return width2("h",&first);}
 double wHh (double ok){ static int first=0;  return width2("H",&first);}
 double wH3 (double ok){ static int first=0;  return width2("H3",&first);}
 double wHc (double ok){ static int first=0;  return width2("H+",&first);}
 double wC1 (double ok){ static int first=0;  return width2("~1+",&first);}
 double wC2 (double ok){ static int first=0;  return width2("~2+",&first);}
 double wNE1(double ok){ static int first=0;  return width2("~o1",&first);}
 double wNE2(double ok){ static int first=0;  return width2("~o2",&first);}
 double wNE3(double ok){ static int first=0;  return width2("~o3",&first);}
 double wNE4(double ok){ static int first=0;  return width2("~o4",&first);}
 double wSG (double ok){ static int first=0;  return width2("~g",&first);}
 double wSeL(double ok){ static int first=0;  return width2("~eL",&first);}
 double wSeR(double ok){ static int first=0;  return width2("~eR",&first);}
 double wSmL(double ok){ static int first=0;  return width2("~mL",&first);}
 double wSmR(double ok){ static int first=0;  return width2("~mR",&first);}
 double wSl1(double ok){ static int first=0;  return width2("~l1",&first);}
 double wSl2(double ok){ static int first=0;  return width2("~l2",&first);}
 double wSne(double ok){ static int first=0;  return width2("~ne",&first);}
 double wSnm(double ok){ static int first=0;  return width2("~nm",&first);}
 double wSnl(double ok){ static int first=0;  return width2("~nl",&first);}
 double wSuL(double ok){ static int first=0;  return width2("~uL",&first);}
 double wSuR(double ok){ static int first=0;  return width2("~uR",&first);}
 double wScL(double ok){ static int first=0;  return width2("~cL",&first);}
 double wScR(double ok){ static int first=0;  return width2("~cR",&first);}
 double wSt1(double ok){ static int first=0;  return width2("~t1",&first);}
 double wSt2(double ok){ static int first=0;  return width2("~t2",&first);}
 double wSdR(double ok){ static int first=0;  return width2("~dR",&first);}
 double wSdL(double ok){ static int first=0;  return width2("~dL",&first);}
 double wSsL(double ok){ static int first=0;  return width2("~sL",&first);}
 double wSsR(double ok){ static int first=0;  return width2("~sR",&first);}
 double wSb1(double ok){ static int first=0;  return width2("~b1",&first);}
 double wSb2(double ok){ static int first=0;  return width2("~b2",&first);}



#include<stdio.h>
#include"micromegas.h"
#include"micromegas_aux.h"
#include<errno.h>

void unlink_(char* name, int len)
{ char buff[100];
   int errnoTmp=errno;
   fName2c(name,buff,len);
   unlink(buff);
   errno=errnoTmp;
}


int  assignval_(char * f_name, double * val, int len) /* for Fortran assignment */
{  char buff[20];
   fName2c(f_name,buff,len);
   return assignVal(buff, *val);
}

int findval_(char*f_name, double*val, int len)  /*FORTRAN*/
{
  char c_name[20];
  fName2c(f_name,c_name,len);
  return findVal(c_name,val);
}


void printvar_(int *n) { printVar(stdout, *n);}

void  lsp_(char*str,int len)
{
  int i;
  char buff[10];

  strcpy(buff,lsp());
  for(i=0;i<strlen(buff)&&i<len;i++) str[i]=buff[i];
  for(;i<len;i++) str[i]=' ';
}



void printmasses_(int* sort)
{ printMasses(stdout,*sort);}

int calcdep_(int*dMbOn) { return calcDep(*dMbOn);}


double darkomega_(double * Xf_, int * Fast, double *Beps)  { return   darkOmega(Xf_, *Fast, *Beps);} 


double darkomegafo_(double *Xf, int*Fast,double*Beps){return darkOmegaFO(Xf,*Fast,*Beps);}


double printchannels_(double*Xf,double*cut,double*Beps,int* prcnt)
{return printChannels(*Xf,*cut,*Beps,* prcnt,stdout);}

double mbrun_(double*q){ return MbRun(*q);}
double mtrun_(double*q){ return MtRun(*q);}
double mbeff_(double*q){ return MbEff(*q);}
double mteff_(double*q){ return MtEff(*q);}

int  sphenosugra_(double* tb, double* gMG1,double* gMG2,double* gMG3,
   double* gAl, double* gAt, double* gAb, double* sgn, double* gMHu, double* gMHd,
   double* gMl2,double* gMl3,double* gMr2,double* gMr3,
   double* gMq2,double* gMq3,double* gMu2,double* gMd2,double* gMu3,double* gMd3)
{ return  sphenoSUGRA(*tb, *gMG1,*gMG2,*gMG3,         
   *gAl, *gAt, *gAb, *sgn, *gMHu,*gMHd,
   *gMl2,*gMl3,*gMr2,*gMr3,
   *gMq2,*gMq3,*gMu2,*gMd2,*gMu3,*gMd3);
}


int  softsusysugra_(double* tb, double* gMG1,double* gMG2,double* gMG3,
   double* gAl, double* gAt, double* gAb, double* sgn, double* gMHu, double* gMHd,
   double* gMl2,double* gMl3,double* gMr2,double* gMr3,
   double* gMq2,double* gMq3,double* gMu2,double* gMd2,double* gMu3,double* gMd3)
{ return  softSusySUGRA(*tb, *gMG1,*gMG2,*gMG3,         
   *gAl, *gAt, *gAb, *sgn, *gMHu,*gMHd,
   *gMl2,*gMl3,*gMr2,*gMr3,
   *gMq2,*gMq3,*gMu2,*gMd2,*gMu3,*gMd3);
}


double deltamb_(void){ return  deltaMb();}

double decay2_(char *pName, int *k, char *n1, char * n2, int l0, int l1, int l2)
{  char pName_c[10],n1_c[10],n2_c[10];
   double w;

   fName2c(pName,pName_c,l0);

   w=decay2(pName_c, *k, n1_c, n2_c);
  
   cName2f(n1_c,n1,l1);
   cName2f(n2_c,n2,l2);     

   return w;
}

void newprocess_(char * procname,  char*libname, int *addressf, int l1, int l2)
{ char procname_c[100], libname_c[100];
  void * address_c;
  fName2c(procname,procname_c,l1);
  fName2c(libname,libname_c,l2);  
  address_c=newProcess(procname_c,libname_c);
  memcpy(addressf,&address_c,sizeof(void*));

  return;
}

int infor22_(int *address, int *nsub, char * pIn1, char * pIn2, char * pOut1,char * pOut2,
                  double*m1,double*m2,double*m3,double*m4, int l1,int l2,int l3,int l4)
{
     char pIn1c[10], pIn2c[10], pOut1c[10], pOut2c[10];
     int res; 
     void*address_c; 

     memcpy(&address_c,address,sizeof(void*));

     res=infor22(address_c, *nsub, pIn1c,pIn2c,pOut1c,pOut2c, m1,m2,m3,m4);

     cName2f(pIn1c, pIn1, l1);
     cName2f(pIn2c, pIn2, l2);
     cName2f(pOut1c,pOut1,l3);
     cName2f(pOut2c,pOut2,l4);
     return res;
}

double cs22_(int * address, int * nsub, double *Pcm, double *c1, double *c2, int * err)
{ 
  void*address_c;
  memcpy(&address_c,address,sizeof(void*)); 
  return cs22(address_c, *nsub, *Pcm, *c1, *c2, err); 
}

int readlesh_(char *fname, int *SMtb, int len)
{ char * cname=malloc(len+2);
  int err;
  fName2c(fname,cname,len);
  err= readLesH(cname, *SMtb);
  free(cname);
  return err;
}

int writelesh_(char *fname, int len)
{ char * cname=malloc(len+2);
  int err;
  fName2c(fname,cname,len);
  err= writeLesH(cname);
  free(cname);
  return err;
}

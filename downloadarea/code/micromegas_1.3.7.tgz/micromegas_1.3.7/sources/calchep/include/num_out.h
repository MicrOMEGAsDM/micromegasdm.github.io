#ifndef __NUM_OUT_ext
#define __NUM_OUT_ext

#include<stdlib.h>
#include<string.h> 
#include<math.h>

extern const int nin_ext;
extern const int nout_ext;
extern const int nprc_ext;
extern const int nvar_ext;
extern const int nfunc_ext;

extern char * pinf_ext(int nsub, int nprtcl, double* pmass);
extern char * varName_ext[];

extern double sqme_ext(int nsub, double * momenta, int * err);
extern int calcFunc_ext(void);
extern int rwidth_ext, gwidth_ext, twidth_ext;
extern double va_ext[];

extern  char * den_info_ext(int nsub, int n, int * mass, int * width);

extern void build_cb_ext(int nsub); 
extern void destroy_cb_ext(void);    
extern int cb_pow_ext;   
extern int cb_nc_ext; 
extern int * cb_chains_ext;
extern double * cb_coeff_ext;


#define  DENOMINATOR_ERROR   2
#endif


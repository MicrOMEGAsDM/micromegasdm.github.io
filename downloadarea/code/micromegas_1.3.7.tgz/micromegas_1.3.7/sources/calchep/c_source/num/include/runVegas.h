#ifndef __RUNVEGAS__
#define __RUNVEGAS__

#include<stdio.h>
#include"vegas.h"

extern int runVegas(int init);
extern int runEvents(int init);
typedef  struct { 
                   long ncall0;
                   int itmx0;
                   int wrtEvnt;
                } mcintr_;
extern mcintr_ mcintr_1;

extern int nSess;

extern double inP1,inP2;

extern int saveVegasGrid( FILE * f); 
extern int readVegasGrid( FILE * f);

typedef struct vegas_integral
{
   double s0,s1,s2;
   long  nCallTot;
   int n_it,old;
}  vegas_integral;

extern vegas_integral integral; 

#endif

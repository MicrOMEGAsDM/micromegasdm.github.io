/*
 Copyright (C) 1997, Alexander Pukhov 
*/
#include<stdlib.h>
#include<stdio.h>
#include"num_out.h"
#include"usrfun.h"
extern double pvect[400];


double usrfun(char * name)
{
   fprintf(stdout," User function U%s not defined\n",name);
   exit(10);
   return 0.;
} 

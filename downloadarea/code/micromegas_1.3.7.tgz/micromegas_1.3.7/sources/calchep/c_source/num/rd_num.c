/*
 Copyright (C) 1997, Alexander Pukhov 
*/
#include <stdio.h>
#include <ctype.h>
#include "num_out.h"
#include "rd_num.h"

int  rd_num(char* s, double *p)
{
  int n;   

  if (isdigit(*s)) { sscanf(s,"%lf",p); return 1;}

  for(n=1;n<=nvar_ext+nfunc_ext;n++) if(strcmp(varName_ext[n],s)==0) {*p=va_ext[n];return 1;}

  return 0;   
}

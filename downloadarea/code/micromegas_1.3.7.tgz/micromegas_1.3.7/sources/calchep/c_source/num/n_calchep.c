/*
 Copyright (C) 1997, Alexander Pukhov, e-mail pukhov@theory.npi.msu.su 
*/

#include "tptcmac.h" 
#include "chep_crt.h"
#include "os.h"
#include "files.h" 
#include "rw_sess.h"
#include "num_out.h"
#include "num_in.h"
#include"n_calchep_.h"


static void  readtext(char* fname)
{
   FILE * txt;
   trim(fname);
   txt=fopen(fname,"r");
   if (txt == NULL)
   {
      messanykey(10,10," File not found ");
      return;
   }
   showtext (1, 1, 80,maxRow(),"",txt);
   fclose(txt);
}

static void  viewresults(void)
{searchrec  s;
 
 int   i,k,doserror;
 void *  pscr2 = NULL;  
 char f_name[STRSIZ];
 char  menustr[2016];


   menustr[0]=15;

   k=1;
   strcpy(f_name,"*.*");
   doserror = find_first(f_name,&s,anyfile);
   while (doserror == 0 && k<=2000)
   {
     for (i = 1; (i <= strlen(s.name))&&(i<=15); i++) menustr[k++]=s.name[i-1];
     for (i = strlen(s.name) + 1; i <= 15; i++) menustr[k++]=' ';
     doserror = find_next(&s);
   }
   menustr[k]=0;
   if (menustr[1] == 0 )
   {
      messanykey(10,15,"directory  is empty");
      return;
   }
        
      k=1;
      do
      {
         menu1(10,10,"",menustr,"",&pscr2,&k);
         if (k > 0)
         {sprintf(f_name,"%.15s",menustr+k*15-14);
          readtext(f_name);
         }
      }  while (k != 0);
}


                                                                    
static void f6_key_prog (int x){  viewresults(); }
                                                                        

static void f9_key_prog (int x)
{
    if( mess_y_n(15,15," Quit session? ")) 
    {
        w_sess__(NULL);
        finish();
        exit(0);
    }
    
}
         

#ifdef _WIN32
int main_n(int argc,char** argv)
#else
int main(int argc,char** argv)
#endif
{
  int n;


  for ( n=1;n<=(argc-1);n++)
  {
     if (strcmp(argv[n],"-blind")==0 )
     {  blind=TRUE;
        inkeyString=argv[n+1];
        break;
     }
  }

  { char *p=getenv("CALCHEP");
#include"rootDir.h"    
    if(!p) p=rootDir;
    strcpy(_pathtocomphep,p);
  }                           

  sprintf(pathtocomphep,"%s%c",_pathtocomphep,d_slash);
  sprintf(pathtohelp,"%shelp%c",pathtocomphep,f_slash);


   f3_key[3]=f6_key_prog;   f3_mess[3]="Results";
   f3_key[6]=f9_key_prog;   f3_mess[6]="Quit";


/* **  initialization of the session */

    wrtprc_();
    inipar_();
    r_sess__(NULL);
              
  { char inifile[100]="calchep.ini;../calchep.ini"; 
    start1(version,scat("%s%s",pathtocomphep,"icon"),inifile); 
    goto_xy(10,10); print("Calculation of constrants.  Be patient, please.");   
    escpressed();
  }

  n_comphep();
  finish();  
  return 0;        
}

/*
 Copyright (C) 1997, Alexander Pukhov, e-mail pukhov@theory.npi.msu.su 
*/

#include "tptcmac.h" 

#include "chep_crt.h"
#include "os.h"
#include "files.h" 
#include "rw_sess.h"
#include "mc_menu.h" 
#include "param.h"
#include "num_out.h"
#include "width_12.h"

#include"n_calchep_.h"

void n_comphep(void)
{
  char ExitMessage[]="Quit session?";
  clr_scr(FGmain,BGmain); 

  while(checkParam()) 
   if(mess_y_n(15,15, "You have to quit the session and\n"
                      "change parameters into the\n"
                      "session.dat file (Y) or do it by\n"
                      "means of menu function in the \n"
                      "current session (N)"))
     {w_sess__(NULL); return;} else change_parameter(54,7);
 
          
  do if(nin_ext==1 && nout_ext==2) decay12(); else  monte_carlo_menu();
  while(!mess_y_n(15,15,ExitMessage));
 
  w_sess__(NULL);
}

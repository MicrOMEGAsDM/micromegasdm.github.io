/*
 Copyright (C) 1997, Alexander Pukhov 
*/

#include<math.h>
#include"4_vector.h"
#include"decay.h"

#include"decay.inc"


#ifndef  __SIMPSON__
#define __SIMPSON__
extern double simpson9(double (*func)(double), double a, double b, double eps);
#endif

#ifndef __MC_MENU__
#define __MC_MENU__
extern void monte_carlo_menu(void);
#endif

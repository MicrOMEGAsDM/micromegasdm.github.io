#ifndef __ALPHAS2__
#define __ALPHAS2__
#include<stdio.h>
extern int qcdmen_(void);
extern int w_qcd__(FILE *mode);
extern int r_qcd__(FILE *mode);
extern void alf_(double q);
extern double scale_(void);
extern void i_qcd(void);

#endif

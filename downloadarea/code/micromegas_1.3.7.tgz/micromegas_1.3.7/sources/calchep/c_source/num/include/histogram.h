#ifndef __HIST__
#define __HIST__

#include"file_scr.h"

extern table histTab;
extern void editHist(void);
extern void showHist(void);
extern int wrt_hist(FILE *nchan);
extern int rdr_hist(FILE *nchan);
extern int clearHists(void);
extern void fillHists(double w);
extern int correctHistList(void);
#endif

#ifndef __SF_PDF__
#define __SF_PDF__

extern int     p_pdf(char *p_name);
extern void    n_pdf(int i, char *name);
extern int     r_pdf(int i, char *name);
extern void    m_pdf(int i);
extern int     be_pdf(int i,double * be, double * mass);
extern double  c_pdf(int i, double x,double q);
extern double  alpha_pdf(double q);
extern int alphaMode;
extern double alpha_pdf(double q );


#endif

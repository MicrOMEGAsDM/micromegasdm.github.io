#ifndef __EVENTS__
#define __EVENTS__
#include"vegas.h"
extern void  generateEvents( vegasGrid * vegPtr, int init, 
double (*func)(double *,double), char * fname, FILE * iprt);
extern int saveEventMax(FILE * f);
extern int readEventMax(FILE * f);

int saveEventSettings(FILE * f);
int readEventSettings(FILE * f);

#endif

#include "f_c.h"
#include "out_ext.h"
#include "out_int.h"
#include"tptcmac.h"
#include "syst2.h"
#include"crt_util.h"
#include"parser.h"
#include"usrfunc.P"
#include"reader3m.h"
#include"file_scr.h"
#include"kinaux.P"
#include"4_vector.h"
#include"edittab.h"


wdth_ wdth_1;
sqs_  sqs_1;
static table singTab={"*** Table ***"," Singularites",
" Invariant    |> Mass  <|> Width <| Power|",NULL};

static struct {
    char lvinvr[2000]	/* was [10][200] */;
    double rgmass[200], rgwdth[200];
    long nextrg[200], ndeg[200];
} invsng_;

static double DP[16];
#define invsng_1 invsng_



static int addreg_(char * lv, double rgmasw, double rgwdtw, int nndeg)
{
     int nreg=0;
     int lastrg=-1;
L10:
    if (invsng_1.lvinvr[nreg * 10] != 0)
    {
        if (!strcpy(lv,invsng_1.lvinvr+nreg*10)) lastrg = nreg;
        ++nreg;
        goto L10;
    }
    if (nreg >= 199)  return 0;
    strcpy(invsng_1.lvinvr+nreg*10,lv);
    invsng_1.rgmass[nreg] = rgmasw;
    invsng_1.rgwdth[nreg] = rgwdtw;
    invsng_1.ndeg[nreg] = nndeg;
    invsng_1.nextrg[nreg] = 0;
    if (lastrg >=0 ) invsng_1.nextrg[lastrg ] = nreg+1;
    return 0;
} /* addreg_ */


static int fillRegArray(void)
{
  linelist ln=singTab.strings;
  int lineNum=0;
  double mass,width;
  double *rptr;
  char invStr[STRSIZ], massStr[STRSIZ], widthStr[STRSIZ];

  invsng_1.lvinvr[0] = 0;  
  while (ln != NULL)
  {  
    int power=0;
    char lv[10]={0,0,0,0,0,0,0,0,0,0};
    int i,k,n;
    invStr[0]=0;
    massStr[0]=0;
    widthStr[0]=0;    
    lineNum++;
    sscanf(ln->line,"%[^|]%*c%[^|]%*c%[^|]%*c%ld",invStr,massStr,widthStr,&power);

/*============ Invariant ===========*/
    k=0;
    i=0; while(invStr[i]!=0) 
    { if(invStr[i]!=' ')
      { n=invStr[i]-'0';
        if(n>0 && n<=nin_()+nout_())
        { lv[k]=n;
          k++;   
        }else
        {
           sprintf(errorText," Error in  regularization table line %d .$"
                              " Wrong field 'Invariant' .",lineNum);
           goto errorExit;                      
        }
      }
      i++;
    }

    if (lv[0]==0)
    {
       sprintf(errorText," Error in  regularization table line %d .$"
                              " Wrong field 'Invariant' .",lineNum);
       goto errorExit;                          
    }
/*================ Mass ============*/
   rptr = (double*) readexprassion(massStr,bact_3m,uact_3m,rd_3m);
   if (rderrcode != 0)
   {    sprintf(errorText," Error in  regularization table line %d .$"
                          " Wrong field 'Mass' .",lineNum);
        goto errorExit;
   }                                         
   mass=*rptr;
   free(rptr);
/*==================Width ==========*/    
   rptr = (double *) readexprassion(widthStr,bact_3m,uact_3m,rd_3m);
   if (rderrcode != 0)
   {    sprintf(errorText," Error in  regularization table line %d .$"
                          " Wrong field 'Width' .",lineNum);
        goto errorExit;
   }                                         
   width=*rptr;
   free(rptr);
          
/*============ Power ===============*/     
    if( power<1 ||power>2 ) 
    { 
       sprintf(errorText," Error in  regularization table line %d .$"
                         " Power is out of range.",lineNum);
       goto errorExit;                      
    }
    addreg_(lv,mass,width,power);     
    ln=ln->next;
  }
  
  
  return 0;
  errorExit: messanykey(2,10,errorText);
           return 1;  
}



double usrcut_(void) { return 1; }

int i_usr__(void){ invsng_1.lvinvr[0] = 0; }
     
int w_usr__(FILE *mode)
{
   writetable0(&singTab,mode);
} 

int r_usr__(FILE *mode)
{
     readtable0(&singTab,mode);
     if(!fillRegArray()) invsng_1.lvinvr[0] = 0;
     
} 

static int um(void)
{
 do edittable(&singTab,1,0,0); while (fillRegArray());
 return 0;
} 


int (*usrmen_)(void)=&um;



static double smpl(int nsub, double * momenta, int * err )
{
    /* System generated locals */
    double ret_val, d__1, d__2, d__3;

    static long nn;
    static double vinv;
    static long nvbuff;
    
    *err=0;
    nvbuff = nin_() + nout_() + 3;
    ret_val = 1.;
    nn = 1;
L1:
    if (invsng_1.lvinvr[nn * 10 - 10] == 0) 
    {  
	return ret_val;
    }
/*    lvtonv_(&invsng_1.lvinvr[nn * 10 - 10], &nvbuff);*/
    vinv = sqrMom( &invsng_1.lvinvr[nn * 10 - 10],momenta);
    if (invsng_1.rgwdth[nn - 1] == 0.) {
/* Computing 2nd power */
	d__3 = invsng_1.rgmass[nn - 1];
	d__2 = (d__1 = vinv - d__3 * d__3, abs(d__1));
	ret_val /= pow_di(d__2, invsng_1.ndeg[nn - 1]);
    } else {
/* Computing 2nd power */
	d__2 = invsng_1.rgmass[nn - 1];
/* Computing 2nd power */
	d__1 = vinv - d__2 * d__2;
/* Computing 2nd power */
	d__3 = invsng_1.rgmass[nn - 1] * invsng_1.rgwdth[nn - 1];
	ret_val /= d__1 * d__1 + d__3 * d__3;
    }
    ++nn;
    goto L1;
} /* sqme_ */

#include"sqme0.c"


#include "out_ext.h"
#include "f_c.h"
#include "tptcmac.h"
#include "syst2.h"

/* Common Block Declarations */

double va[6];
    
/* ****************************** */
/*    CompHEP  version  3.2    * */
/* ****************************** */
char  processch[80];

int init_(void) { return 0; }
int nin_(void)  { return 2; } 
int nout_(void) { return 4;} 
int lenr_(void) { return 8;} 
int nprc_(void) { return 1; } 

int pinf_(char *ret_val, int nsub, int nprtcl)
{
    static char names[6][4] = {"A1", "A2","A3", "A4", "A5","A6"};
    strcpy(ret_val,names[nprtcl-1]);
    return  ;
} /* pinf_ */

int nvar_(void) { return 6;} 
int nfunc_(void){ return 0;}

int vinf_(int numvar, char * name, double *val)
{
 
    static char names[6][6] = {"M1", "M2", "M3", "M4","M5","M6"};

    if (numvar > 6) return 0;
    strcpy(name, names[numvar-1]);
    *val = va[numvar-1];
    return 1;
} /* vinf_ */

 int asgn_(int numvar, double valnew)
{
    if (numvar < 1 || numvar > 6) {
	return 0;
    }
    va[numvar - 1] = valnew;
    return 0;
} /* asgn_ */

int pmas_(int nsub, int nprtcl, double *val)
{
     static int nvalue[6] = { 1,2,3,4,5,6 };

    static int n;

    n = nvalue[nprtcl-1];
    *val = va[n - 1];
    
    return 0;
} /* pmas_ */

void vini_(void)
{
  int i;
   char pname[10];
   processch[0]=0;
   for( i=1;i<=nin_();i++) 
   {  pinf_(pname,1,i);
      strcat(processch,pname); 
      strcat(processch," ");
   }
   strcat(processch,"->");
   for( i=1+nin_();i<=nout_()+nin_() ;i++) 
   { 
      pinf_(pname,1,i); 
      strcat(processch,pname); 
      strcat(processch," ");
   }    

    va[0] = 0.;
    va[1] = 0.;
    va[2] = 0.;
    va[3] = 0.;
    va[4] = 0.;
    va[5] = 0.;
    sqs_1.sqrts=100.000000;    
} /* vini_ */


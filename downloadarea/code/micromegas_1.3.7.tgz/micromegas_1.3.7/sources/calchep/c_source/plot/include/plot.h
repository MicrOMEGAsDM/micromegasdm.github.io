/*-------------------------------------------------*
 * C -version by Victor Edneral, Moscow University *
 *        The latest revision of 23.01.1994        *
 *-------------------------------------------------*/

#ifndef __PLOT__
#define __PLOT__

  extern void   plot_0(double xMin, double xMax, 
                       int dim, double *f, double *ff,                             
                       char* upstr, char* xstr, char* ystr);
#endif

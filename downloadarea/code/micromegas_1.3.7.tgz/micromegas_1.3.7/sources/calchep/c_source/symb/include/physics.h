#ifndef __PHYSICS_
#define __PHYSICS_

#include "tptcmac.h"
#include "model.h"
#include "diagrams.h"
#include "syst2.h"



extern unsigned   subproc_f, subproc_sq;

extern char  modelmenu[STRSIZ];
extern int  maxmodel;

extern int  nsub, ndiagr,n_model;


#endif

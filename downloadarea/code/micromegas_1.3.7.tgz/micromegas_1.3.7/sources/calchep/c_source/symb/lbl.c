/*
 Copyright (C) 2000, Alexander Pukhov, e-mail: pukhov@theory.npi.msu.su 
*/
#include"chep_crt.h"
#include "syst2.h"
#include "lbl.h"
#include "os.h"
#include "s_files.h"

void  cheplabel(void)
{
 int  key; 
 char fname[STRSIZ];
 FILE *f;
 
 while(1)
 {
/*   goto_xy(20,2);  print("Skobeltsyn Institute of Nuclear Physics");
   goto_xy(28,3);  print("Moscow State University");
*/

/*   goto_xy(22,2); print("%s(17.07.2001)",version);*/

   scrcolor(Blue,LightGray);
   goto_xy(7,3); print(" CalcHEP - a package for Calculation in High Energy Physics");
   scrcolor(FGmain,BGmain);
    goto_xy(15,4);  print("Version 2.1; Last correction May  16, 2002");
   goto_xy(3,6);print("Author of the package: Alexander Pukhov <pukhov@theory.sinp.msu.ru>");
scrcolor(Blue,LightGray);   
   goto_xy(15,7);print("<pukhov@theory.sinp.msu.ru>");
scrcolor(FGmain,BGmain);
   goto_xy(3,7);print("The package contains ");
   scrcolor(Blue,LightGray);print("MSSM model");
   scrcolor(FGmain,BGmain); print(" by Andrei Semenov:");
   goto_xy(10,8); scrcolor(Blue,LightGray); 
   print("http://theory.sinp.msu.ru/~semenov/mssm.html");
   scrcolor(FGmain,BGmain);
   goto_xy(3,9);  print("The package contains  also:");
   goto_xy(3,10);  print("*)the codes written by  V.Edneral, V.Ilyin, A.Kryukov, A.Semenov"); 
   goto_xy(5,11); print("for the CompHEP package;");
   goto_xy(3,12); print("*)the FeynHiggsFast by S. Heinemeyer;");

   scrcolor(Blue,LightGray);  goto_xy(10,13);
   print("http://www-itp.physik.uni-karlsruhe.de/feynhiggs");
   scrcolor(FGmain,BGmain);
   
   goto_xy(3,14); print("*)CTEQ5 structure functions:   ");  
 scrcolor(Blue,LightGray);    print("http://cteq.org"); 
 scrcolor(FGmain,BGmain); print("  ;");

   goto_xy(3,15); print("*)program Vegas  by  G.P. Lepage;");  
    
/*
  scrcolor(Blue,LightGray);
   goto_xy(20,7); print("Preliminary release. Do not distribute it.");
scrcolor(FGmain,BGmain);
   
  goto_xy(25,9);print("Copyright (C) 2001,  AUTHOR: A.Pukhov");


   goto_xy(15,11); print(" The author express the gratitude to his colleagues"); 
   goto_xy(15,12); print("    V.Edneral, V.Ilyin, A.Kryukov, A.Semenov"); 
   goto_xy(15,13); print("   for their permission to use the  program code");
   goto_xy(15,14); print("   which they  created for the  CompHEP package.");
  
   goto_xy(15,14); print("publications which result from using the program should");
   goto_xy(15,15); print("contain a reference to the article describing CalcHEP."); 
*/
   goto_xy(25,17); print("Click the field below to get");
          chepbox(19,18,39,20); chepbox(41,18,61,20);
   scrcolor(Blue,LightGray);  
   goto_xy(21,19 ); print("License Agreement"); 
   goto_xy(46,19); print("References");
   scrcolor(Black,LightGray);
    
/*
   goto_xy(1,22); print("For contacts:");
   goto_xy(1,23); print("Alexander Pukhov<pukhov@theory.sinp.msu.ru>");
*/

   goto_xy(10,23); print(" WWW page: ");
   scrcolor(Blue,LightGray);
   print("   http://theory.sinp.msu.ru/~pukhov/calchep.html");
   scrcolor(FGmain,BGmain);
   clearTypeAhead();
   key= inkey();
   if(key==KB_MOUSE &&  mouse_info.row==19 &&
    mouse_info.col >19 &&  mouse_info.col<61)
   { if(mouse_info.col<39)  
     { sprintf(fname,"%s%cLicence.txt",pathtocomphep,f_slash);
       f=fopen(fname,"r");
       showtext (5, 1, 75,1,"",f); 
       fclose(f);
     }
     else if(mouse_info.col>41) 
     { 
       sprintf(fname,"%s%cReference.txt",pathtocomphep,f_slash);
       f=fopen(fname,"r");
       showtext (5, 1, 75,1,"",f);
       fclose(f);
    } else break;
   }else break;
 }
 clr_scr(FGmain,BGmain);
}

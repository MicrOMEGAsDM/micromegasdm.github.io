#ifndef  __S_FILES__ 
#define __S_FILES__

#include"files.h"
#include "syst2.h"

typedef struct catrec
   {
      int      nsub_, ndiagr_;
      long      factpos, rnumpos, denompos;
   }      catrec;

    extern FILE *  menup;
    extern FILE *  menuq;
    extern FILE * diagrp;   /* file of Adiagram; */
    extern FILE * diagrq;   /* file of CSdiagram; */

    extern FILE * archiv;
    extern FILE * catalog;
    extern char mdFls[4][10];
    extern shortstr  _pathtouser, pathtouser;
    
#define MENUQ_NAME   scat("%stmp%cmenuq.ch",pathtouser,f_slash)    
#define MENUP_NAME   scat("%stmp%cmenup.ch",pathtouser,f_slash)
#define DIAGRP_NAME  scat("%stmp%cproces.tp",pathtouser,f_slash)
#define DIAGRQ_NAME  scat("%stmp%ccsproces.tp",pathtouser,f_slash)
#define ARCHIV_NAME  scat("%stmp%carchive.bt",pathtouser,f_slash)
#define CATALOG_NAME scat("%stmp%ccatalog.tp",pathtouser,f_slash)


extern void  wrt_menu(int menutype, int k,
              char*txt,int ndel,int ncalc,int nrest,long recpos);
extern int  rd_menu(int   menutype, int k,
              char*txt,int*ndel,int*ncalc,int*nrest,long*recpos);

#define  FREAD1(d,f)   fread(&(d),sizeof(d),1,f)
#define  FWRITE1(d,f)  f_write(&(d),sizeof(d),1,f)

#endif

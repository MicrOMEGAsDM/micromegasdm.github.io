#ifndef __CWEIGHT_OLD
#define __CWEIGHT_OLD

	extern void  cwtarg_old1(vcsect * g);
	extern void  cwtarg_old2(vcsect * g);

/*  - calculate color weight (two int: n,d) - 08/01/90
      by A.P.Krykov
*/

#endif

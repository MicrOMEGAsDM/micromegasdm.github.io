#ifndef __CHESS_
#define __CHESS_

#include"sets.h"

typedef setofbyte indvertset;   /*  1..3*maxVert */


typedef struct
   {
      byte   weit, g5, vlnc;
      indvertset   ind;
		byte         link[2*maxvert];
	}  vertinfostr ;

extern vertinfostr	vertinfo[2 * maxvert];
extern int  n_vrt;
extern int  prgcode[2 * maxvert][2];


extern void  makeprgcode(void);

#define MEMORY_OPTIM  0

#endif

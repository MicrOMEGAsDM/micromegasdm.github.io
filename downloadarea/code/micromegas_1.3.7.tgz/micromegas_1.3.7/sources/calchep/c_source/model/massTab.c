#include<math.h>
static double dinter_(double x, int n, double *xi, double *yi)
{
    int i;
    double x1, x2, x3, x4;
    if(x> xi[n-1])
    { double M1=xi[n-2], M2=xi[n-1], m1=yi[n-2],m2=yi[n-1];
      double A,B; 
      m1*=m1; m2*=m2;M1=log(M1);M2=log(M2);
      
      B=(m2-m1)/(m1*m2*(M1-M2));
      A=(M1*m1-M2*m2)/(m1*m2*(M1-M2));
      
      return sqrt(m1*m2*(M1-M2)/( (M1*m1-M2*m2)+(m2-m1)*log(x))); 
    }
/*
printf("X=%f\n",x);
*/
    /* Parameter adjustments */
    --yi;
    --xi;

    /* Function Body */
    if (x <= xi[2]) 
    {	x1 = xi[1];
	x2 = xi[2];
	x3 = xi[3];
/*
printf("1x= %f %f %f \n", x1,x2,x3);
printf("1y= %f %f %f \n", yi[1],yi[2],yi[3]);
*/
	return  yi[1] * (x - x2) * (x - x3) / ((x1 - x2) * (x1 - x3)) + 
		yi[2] * (x - x1) * (x - x3) / ((x2 - x1) * (x2 - x3)) + 
		yi[3] * (x - x1) * (x - x2) / ((x3 - x1) * (x3 - x2));
    } else if (x > xi[n - 1]) 
    {	x1 = xi[n - 2];
	x2 = xi[n - 1];
	x3 = xi[n];
/*
printf("2x= %f %f %f \n", x1,x2,x3);
printf("2y= %f %f %f \n", yi[n - 2], yi[n - 1],yi[n    ]);
*/
	return  yi[n - 2] * (x - x2) * (x - x3) / ((x1 - x2) * (x1 - x3)) +
		yi[n - 1] * (x - x1) * (x - x3) / ((x2 - x1) * (x2 - x3)) +
		yi[n    ] * (x - x1) * (x - x2) / ((x3 - x1) * (x3 - x2));
    } else 
    {	for(i = 2; x > xi[i]; i++) ;
	x1 = xi[i - 1];
	x2 = xi[i];
	x3 = xi[i + 1];
	x4 = xi[i + 2];
/*
printf("3x= %f %f %f %f \n", x1,x2,x3,x4);
printf("3y= %f %f %f %f \n", yi[i-1], yi[i  ], yi[i+1],yi[i+2]);
*/
	return   yi[i-1]*(x-x2)*(x-x3)*(x-x4)/((x1-x2)*(x1-x3)*(x1-x4)) + 
	         yi[i  ]*(x-x1)*(x-x3)*(x-x4)/((x2-x1)*(x2-x3)*(x2-x4)) + 
	         yi[i+1]*(x-x1)*(x-x2)*(x-x4)/((x3-x1)*(x3-x2)*(x3-x4)) + 
	         yi[i+2]*(x-x1)*(x-x2)*(x-x3)/((x4-x1)*(x4-x2)*(x4-x3));
    }
} /* dinter_ */

#include "tab.dat" 

double MbH3int(double MH3)
{ return  dinter_(MH3, MH3_power,MH3_tab,  MbH3_tab);}

double McH3int(double MH3)
{ return  dinter_(MH3, MH3_power ,MH3_tab,  McH3_tab);}

double MtopH3int(double MH3)
{ return  dinter_(MH3, MH3_power,MH3_tab,  MtopH3_tab);}


double MbHint(double MH)
{/* double Mmax=MH_tab[MH_power-1];
 if(MH>Mmax)
 {  
   return    MbH_tab[MH_power-1]*sqrt(log(Mmax/0.1187)/log(MH/0.1187));
  }
 else 
*/ return  dinter_(MH, MH_power,MH_tab,  MbH_tab); 

}

double McHint(double MH)
{ return  dinter_(MH, MH_power,MH_tab,  McH_tab);}

double MtopHint(double MH)
{ return  dinter_(MH, MH_power,MH_tab,  MtopH_tab);}



double Mbhint(double Mh)
{ return  dinter_(Mh, Mh_power,Mh_tab,  Mbh_tab);}

double Mchint(double Mh)
{ return  dinter_(Mh, Mh_power,Mh_tab,  Mch_tab);}


double MbHcint(double MHc)
{ return  dinter_(MHc, MHc_power,MHc_tab,  MbHc_tab);}

double MtopHcint(double MHc)                    
{ return  dinter_(MHc, MHc_power,MHc_tab,  MtopHc_tab);}

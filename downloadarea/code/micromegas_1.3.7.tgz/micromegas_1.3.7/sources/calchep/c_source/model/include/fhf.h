#ifndef __FHF__
#define __FHF__


#include"f2c.h"

/* Common Block Declarations */

typedef  struct smpara_ {
    double mw, mz, sw2, mt, mtrun, mb, as, alphasmz, gs, el, gf;
} smpara_;

extern  smpara_  smpara_1;

typedef struct  para_ {
    double cf, eps;
} para_;

extern para_  para_1;

typedef struct susypara_ {
    double mst1, mst2, stt, ctt, delmst, msb1, msb2, stb, ctb, msusy, 
	    msusytl, msusytr, msusybl, msusybr, mtlr, mblr, au, ad, mmm, mgl, 
	    mue, beta, alpha, tb, ma;
} susypara_;

extern  susypara_  susypara_1;

typedef struct  higgsmass_{
    double mhh, mlh;
} higgsmass_;

extern  higgsmass_  higgsmass_1;

typedef struct  selec_{
    long selec2, selec3;
} selec_;

extern selec_ selec_1;

typedef 
struct lle_ {
    double mlhlle1, mlhlle2, mlhllediag1, mlhllediag2, mhhllediag1, 
	    mhhllediag2, alphadiag1, alphadiag2, mhptree, mhp;
} lle_;

extern lle_ lle_1;



extern void cspen(doublecomplex * ret_val, doublecomplex * z__);
extern void def2(void);
 
extern  void feynhiggsfastsub(void);

extern void mhiggslle(
 double * msusytl, 
 double *msusytr, 
 double *mtlr, 
 double *mblr, 
 double *mt, 
 double *mtrun, 
 double *mb, 
 double *mst1, 
 double *mst2, 
 double *stt, 
 double *ma, 
 double *tb, 
 double *alpha, 
 double *gf, 
 double *as, 
 double *cf, 
 double *el, 
 double *mz, 
 double *mw, 
 double *mue, 
 double *mlhlle1, 
 double *mlhlle2, 
 double *mlhllediag1, 
 double *mlhllediag2, 
 double *mhhllediag1, 
 double *mhhllediag2, 
 double *alphadiag1, 
 double *alphadiag2, 
 double *mhp);

extern double fhf2(double tb, double mu, double ml, double mr, double mbr,
		double at, double ab, double mg2, double mg3,
		double ma, double mt, double mb, double tp);

extern double sort4(double m1, double m2, double m3, double m4, double dn);


#endif

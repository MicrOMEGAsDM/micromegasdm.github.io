/* f2c.h  --  Standard Fortran to C header file */

/**  barf  [ba:rf]  2.  "He suggested using FORTRAN, and everybody barfed."

	- From The Shogakukan DICTIONARY OF NEW ENGLISH (Second edition) */
#ifndef F2C_INCLUDE__
#define F2C_INCLUDE__


typedef struct { double r, i; } doublecomplex;

#define ABS(x) ((x) >= 0 ? (x) : -(x))

extern double z_abs(doublecomplex * z);
extern void z_div(doublecomplex*res,doublecomplex*n,doublecomplex*d);
extern void pow_zi(doublecomplex * res, doublecomplex * x, long * n);
extern void z_log(doublecomplex * res, doublecomplex * z);


#endif

/* cspen.f -- translated by f2c (version 20010320).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/


#include "f2c.h"
#include"fhf.h"


/* Table of constant values */

static doublecomplex c_b2 = {1.,0.};

/* ------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------ */
/* CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC */
void cspen(doublecomplex * ret_val, doublecomplex * z__)
{
    /* Initialized data */
long c__2=2;

    static double b[9] = { .1666666666666666666666666667,
	    -.0333333333333333333333333333,.0238095238095238095238095238,
	    -.0333333333333333333333333333,.0757575757575757575757575758,
	    -.2531135531135531135531135531,1.1666666666666666666666666667,
	    -7.09215686274509804,54.97117794486215539 };

    /* System generated locals */
    long i__1;
    double d__1;
    doublecomplex z__1, z__2, z__3, z__4, z__5, z__6, z__7, z__8, z__9, z__10,
	     z__11;

    /* Local variables */
    static long k;
    static doublecomplex u, w;
    static double a1, az, rz;
    static doublecomplex sum;

/* CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC */
/*       SPENCE-FUNKTION KOMPLEX, FREI NACH HOLLIK                     C */
/* ---------------------------------------------------------------------C */
/*       20.07.83    LAST CHANGED 10.05.89        ANSGAR DENNER        C */
/* CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC */
/*     BEACHTE:                 B(N)=B2N */
/*     B(1)=1./6. */
/*     B(2)=-1./30. */
/*     B(3)=1./42. */
/*     B(4)=-1./30. */
/*     B(5)=5./66. */
/*     B(6)=-691./2730. */
/*     B(7)=7./6. */
/*     B(8)=-3617./510. */
/*     B(9)=43867./798. */
/*     B(10)=-174611./330. */
/*     B(11)=854513./138. */
/*     PI=3.1415926535897932384 */
/*     PI*PI/6.=1.6449..., PI*PI/3=3.28986... */

    z__1.r = z__->r * 1. - z__->i * 0., z__1.i = z__->r * 0. + z__->i * 1.;
    z__->r = z__1.r, z__->i = z__1.i;
    rz = z__->r;
    az = z_abs(z__);
    z__1.r = 1. - z__->r, z__1.i = -z__->i;
    a1 = z_abs(&z__1);
/*      write(*,*)'z, rz, az, a1:',z,rz,az,a1 */
/*     IF((SNGL(RZ) .EQ. 0.0) .AND. (SNGL(DIMAG(Z)) .EQ. 0.0)) THEN */
/* ---> CHANGED  10.5.89 */
    if (az < 1e-20) {
	z__3.r = 1. - z__->r, z__3.i = -z__->i;
	z_log(&z__2, &z__3);
	z__1.r = -z__2.r, z__1.i = -z__2.i;
	 ret_val->r = z__1.r,  ret_val->i = z__1.i;
/*        write(*,*) 'cspen:', cspen */
	return ;
    }
    if (rz == 1. && z__->i == 0.) {
	 ret_val->r = 1.64493406684822643,  ret_val->i = 0.;
/*        write(*,*) 'cspen:', cspen */
	return ;
    }
    if (rz > .5) {
	goto L20;
    }
    if (az > 1.) {
	goto L10;
    }
    z__3.r = 1. - z__->r, z__3.i = -z__->i;
    z_log(&z__2, &z__3);
    z__1.r = -z__2.r, z__1.i = -z__2.i;
    w.r = z__1.r, w.i = z__1.i;
    z__3.r = w.r * .25, z__3.i = w.i * .25;
    z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i * 
	    w.r;
    z__1.r = w.r - z__2.r, z__1.i = w.i - z__2.i;
    sum.r = z__1.r, sum.i = z__1.i;
    u.r = w.r, u.i = w.i;
    if (z_abs(&u) < 1e-10) {
	goto L2;
    }
/*      write(*,*) 'u:',u */
/*      write(*,*) 'sum:',sum */
    for (k = 1; k <= 9; ++k) {
	z__3.r = u.r * w.r - u.i * w.i, z__3.i = u.r * w.i + u.i * w.r;
	z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i *
		 w.r;
	d__1 = (double) ((k << 1) * ((k << 1) + 1));
	z__1.r = z__2.r / d__1, z__1.i = z__2.i / d__1;
	u.r = z__1.r, u.i = z__1.i;
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z_div(&z__1, &z__2, &sum);
	if (z_abs(&z__1) < 1e-20) {
	    goto L2;
	}
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z__1.r = sum.r + z__2.r, z__1.i = sum.i + z__2.i;
	sum.r = z__1.r, sum.i = z__1.i;
/* L1: */
    }
L2:
     ret_val->r = sum.r,  ret_val->i = sum.i;
/*        write(*,*) 'cspen:', cspen */
    return ;
L10:
    z_div(&z__4, &c_b2, z__);
    z__3.r = 1. - z__4.r, z__3.i = -z__4.i;
    z_log(&z__2, &z__3);
    z__1.r = -z__2.r, z__1.i = -z__2.i;
    w.r = z__1.r, w.i = z__1.i;
    z__3.r = w.r * .25, z__3.i = w.i * .25;
    z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i * 
	    w.r;
    z__1.r = w.r - z__2.r, z__1.i = w.i - z__2.i;
    sum.r = z__1.r, sum.i = z__1.i;
    u.r = w.r, u.i = w.i;
    if (z_abs(&u) < 1e-10) {
	goto L12;
    }
    for (k = 1; k <= 9; ++k) {
	z__3.r = u.r * w.r - u.i * w.i, z__3.i = u.r * w.i + u.i * w.r;
	z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i *
		 w.r;
	d__1 = (double) ((k << 1) * ((k << 1) + 1));
	z__1.r = z__2.r / d__1, z__1.i = z__2.i / d__1;
	u.r = z__1.r, u.i = z__1.i;
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z_div(&z__1, &z__2, &sum);
	if (z_abs(&z__1) < 1e-20) {
	    goto L12;
	}
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z__1.r = sum.r + z__2.r, z__1.i = sum.i + z__2.i;
	sum.r = z__1.r, sum.i = z__1.i;
/* L11: */
    }
L12:
    z__3.r = -sum.r, z__3.i = -sum.i;
    z__2.r = z__3.r - 1.64493406684822643, z__2.i = z__3.i;
    z__7.r = -z__->r, z__7.i = -z__->i;
    z_log(&z__6, &z__7);
    pow_zi(&z__5, &z__6, &c__2);
    z__4.r = z__5.r * .5, z__4.i = z__5.i * .5;
    z__1.r = z__2.r - z__4.r, z__1.i = z__2.i - z__4.i;
     ret_val->r = z__1.r,  ret_val->i = z__1.i;
/*        write(*,*) 'cspen:', cspen */
    return ;
L20:
    if (a1 > 1.) {
	goto L30;
    }
    z_log(&z__2, z__);
    z__1.r = -z__2.r, z__1.i = -z__2.i;
    w.r = z__1.r, w.i = z__1.i;
    z__3.r = w.r * .25, z__3.i = w.i * .25;
    z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i * 
	    w.r;
    z__1.r = w.r - z__2.r, z__1.i = w.i - z__2.i;
    sum.r = z__1.r, sum.i = z__1.i;
    u.r = w.r, u.i = w.i;
    if (z_abs(&u) < 1e-10) {
	goto L22;
    }
    for (k = 1; k <= 9; ++k) {
	z__3.r = u.r * w.r - u.i * w.i, z__3.i = u.r * w.i + u.i * w.r;
	z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i *
		 w.r;
	d__1 = (double) ((k << 1) * ((k << 1) + 1));
	z__1.r = z__2.r / d__1, z__1.i = z__2.i / d__1;
	u.r = z__1.r, u.i = z__1.i;
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z_div(&z__1, &z__2, &sum);
	if (z_abs(&z__1) < 1e-20) {
	    goto L22;
	}
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z__1.r = sum.r + z__2.r, z__1.i = sum.i + z__2.i;
	sum.r = z__1.r, sum.i = z__1.i;
/* L21: */
    }
L22:
    z__3.r = -sum.r, z__3.i = -sum.i;
    z__2.r = z__3.r + 1.64493406684822643, z__2.i = z__3.i;
    z_log(&z__5, z__);
    z__7.r = 1. - z__->r, z__7.i = -z__->i;
    z_log(&z__6, &z__7);
    z__4.r = z__5.r * z__6.r - z__5.i * z__6.i, z__4.i = z__5.r * z__6.i + 
	    z__5.i * z__6.r;
    z__1.r = z__2.r - z__4.r, z__1.i = z__2.i - z__4.i;
     ret_val->r = z__1.r,  ret_val->i = z__1.i;
/*        write(*,*) 'cspen:', cspen */
    return ;
L30:
    z_div(&z__3, &c_b2, z__);
    z__2.r = 1. - z__3.r, z__2.i = -z__3.i;
    z_log(&z__1, &z__2);
    w.r = z__1.r, w.i = z__1.i;
    z__3.r = w.r * .25, z__3.i = w.i * .25;
    z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i * 
	    w.r;
    z__1.r = w.r - z__2.r, z__1.i = w.i - z__2.i;
    sum.r = z__1.r, sum.i = z__1.i;
    u.r = w.r, u.i = w.i;
    if (z_abs(&u) < 1e-10) {
	goto L32;
    }
    for (k = 1; k <= 9; ++k) {
	z__3.r = u.r * w.r - u.i * w.i, z__3.i = u.r * w.i + u.i * w.r;
	z__2.r = z__3.r * w.r - z__3.i * w.i, z__2.i = z__3.r * w.i + z__3.i *
		 w.r;
	d__1 = (double) ((k << 1) * ((k << 1) + 1));
	z__1.r = z__2.r / d__1, z__1.i = z__2.i / d__1;
	u.r = z__1.r, u.i = z__1.i;
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z_div(&z__1, &z__2, &sum);
	if (z_abs(&z__1) < 1e-20) {
	    goto L32;
	}
	i__1 = k - 1;
	z__2.r = b[i__1] * u.r, z__2.i = b[i__1] * u.i;
	z__1.r = sum.r + z__2.r, z__1.i = sum.i + z__2.i;
	sum.r = z__1.r, sum.i = z__1.i;
/* L31: */
    }
L32:
    z__3.r = sum.r + 3.28986813369645287, z__3.i = sum.i;
    z__7.r = z__->r - 1., z__7.i = z__->i;
    z_log(&z__6, &z__7);
    pow_zi(&z__5, &z__6,&c__2);
    z__4.r = z__5.r * .5, z__4.i = z__5.i * .5;
    z__2.r = z__3.r + z__4.r, z__2.i = z__3.i + z__4.i;
    z_log(&z__9, z__);
    z__11.r = 1. - z__->r, z__11.i = -z__->i;
    z_log(&z__10, &z__11);
    z__8.r = z__9.r * z__10.r - z__9.i * z__10.i, z__8.i = z__9.r * z__10.i + 
	    z__9.i * z__10.r;
    z__1.r = z__2.r - z__8.r, z__1.i = z__2.i - z__8.i;
     ret_val->r = z__1.r,  ret_val->i = z__1.i;
/* L50: */
/*        write(*,*) 'cspen:', cspen */
} /* cspen_ */


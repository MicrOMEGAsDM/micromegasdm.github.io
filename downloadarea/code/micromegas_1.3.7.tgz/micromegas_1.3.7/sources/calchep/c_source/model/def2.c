#include<math.h>
#include<stdio.h>
#include "f2c.h"
#include "fhf.h"

void def2(void)
{
    /* System generated locals */
    double d__1, d__2, d__3;

    /* Builtin functions */

    /* Local variables */
    static double sgnb, sgnt, b, bb, m12, m22, tt, c2b, ml2b, mr2b, ml2t, 
	    mr2t;

    b = atan(susypara_1.tb);
    c2b = cos(b * 2.);
/*      write(*,*) 'def2:' */
/*      write(*,*) msusytl, msusytr, msusybl, msusybr, mz, sw2, mt,mb,c2b */
    d__1 = susypara_1.msusytl;
    d__2 = smpara_1.mz;
    d__3 = smpara_1.mt;
    ml2t = d__1 * d__1 + d__2 * d__2 * c2b * (.5 - smpara_1.sw2 * 
	    .66666666666666663) + d__3 * d__3;
    d__1 = susypara_1.msusytr;
    d__2 = smpara_1.mz;
    d__3 = smpara_1.mt;
    mr2t = d__1 * d__1 + d__2 * d__2 * c2b * (smpara_1.sw2 * 
	    .66666666666666663) + d__3 * d__3;
    d__1 = susypara_1.msusybl;
    d__2 = smpara_1.mz;
    d__3 = smpara_1.mb;
    ml2b = d__1 * d__1 + d__2 * d__2 * c2b * (smpara_1.sw2 * 
	    .33333333333333331 - .5) + d__3 * d__3;
    d__1 = susypara_1.msusybr;
    d__2 = smpara_1.mz;
    d__3 = smpara_1.mb;
    mr2b = d__1 * d__1 + d__2 * d__2 * c2b * (smpara_1.sw2 * 
	    -.33333333333333331) + d__3 * d__3;
/*      write(*,*) 'diagonal entries:' */
/*      write(*,*) ml2t, mr2t */
    sgnt = (ml2t - mr2t) / (d__1 = ml2t - mr2t, ABS(d__1));
    sgnb = (ml2b - mr2b) / (d__1 = ml2b - mr2b, ABS(d__1));
    d__1 = ml2t - mr2t;
    d__2 = smpara_1.mt;
    d__3 = susypara_1.mtlr;
    tt = atan(-sgnt * 2. * smpara_1.mt * susypara_1.mtlr / (-sgnt * (ml2t - 
	    mr2t) - sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * d__3))));
    susypara_1.stt = sin(tt);
    susypara_1.ctt = cos(tt);
    d__1 = ml2b - mr2b;
    d__2 = smpara_1.mb;
    d__3 = susypara_1.mblr;
    bb = atan(-sgnb * 2. * smpara_1.mb * susypara_1.mblr / (-sgnb * (ml2b - 
	    mr2b) - sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * d__3))));
    susypara_1.stb = sin(bb);
    susypara_1.ctb = cos(bb);
    d__1 = ml2t - mr2t;
    d__2 = smpara_1.mt;
    d__3 = susypara_1.mtlr;
    m12 = (ml2t + mr2t + sgnt * sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * 
	    d__3))) * .5;
    d__1 = ml2t - mr2t;
    d__2 = smpara_1.mt;
    d__3 = susypara_1.mtlr;
    m22 = (ml2t + mr2t - sgnt * sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * 
	    d__3))) * .5;
    if (m12 < 0. || m22 < 0.) {
	susypara_1.mst1 = 0.;
	susypara_1.mst2 = 0.;
	goto L100;
    }
    
    susypara_1.mst1 = sqrt(m12);
    susypara_1.mst2 = sqrt(m22);


L100:
    d__1 = ml2b - mr2b;
    d__2 = smpara_1.mb;
    d__3 = susypara_1.mblr;
    m12 = (ml2b + mr2b + sgnb * sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * 
	    d__3))) * .5;
    d__1 = ml2b - mr2b;
    d__2 = smpara_1.mb;
    d__3 = susypara_1.mblr;
    m22 = (ml2b + mr2b - sgnb * sqrt(d__1 * d__1 + d__2 * d__2 * 4. * (d__3 * 
	    d__3))) * .5;
    if (m12 < 0. || m22 < 0.) {
	susypara_1.msb1 = 0.;
	susypara_1.msb2 = 0.;
	goto L200;
    }
    susypara_1.msb1 = sqrt(m12);
    susypara_1.msb2 = sqrt(m22);
L200:
    ;
} /* def2_ */


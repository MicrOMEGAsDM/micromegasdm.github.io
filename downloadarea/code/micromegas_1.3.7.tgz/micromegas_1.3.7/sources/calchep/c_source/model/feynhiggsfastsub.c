#include<math.h>
#include<stdio.h>
#include "f2c.h"
#include"fhf.h"


void feynhiggsfastsub(void)
{
    /* System generated locals */
    double d__1, d__2, d__3, d__4, d__5, d__6, d__7, d__8;

    /* Local variables */
    static double gmue, mtold;
    static double mb2, mw2, mz2;
    static double mhh2, mlh2;

    d__1 = smpara_1.mz;
    mz2 = d__1 * d__1;
    d__1 = smpara_1.mw;
    mw2 = d__1 * d__1;
    d__1 = smpara_1.mw / smpara_1.mz;
    smpara_1.sw2 = 1. - d__1 * d__1;
    d__1 = smpara_1.mw;
    d__2 = smpara_1.mw;
    d__3 = smpara_1.mz;
    smpara_1.el = sqrt(smpara_1.gf * 8. * (d__1 * d__1) * (1 - d__2 * d__2 / (
	    d__3 * d__3)) / sqrt(2.));
    smpara_1.gs = sqrt(M_PI * 4 * smpara_1.as);
    gmue = smpara_1.gf;
    d__1 = smpara_1.mb;
    mb2 = d__1 * d__1;
/*      write(*,*) 'mtrun:', alphasmz, mt, mmz, pi */
    d__1 = smpara_1.mt;
    d__2 = smpara_1.mz;
    smpara_1.as = smpara_1.alphasmz / (7.6666666666666661 / (M_PI * 4.) *
	     smpara_1.alphasmz * log(d__1 * d__1 / (d__2 * d__2)) + 1.);
    smpara_1.mtrun = smpara_1.mt / (4. / (M_PI * 3.) * smpara_1.as + 1.);
    if (selec_1.selec2 >= 3) {
        smpara_1.mt = smpara_1.mtrun;
/*	printf("using running top mass: %f\n",smpara_1.mtrun);  */
    }

    susypara_1.au = susypara_1.mtlr + susypara_1.mue / susypara_1.tb;
    susypara_1.ad = susypara_1.mblr + susypara_1.mue * susypara_1.tb;
/*      ad = au */
/* c --> note: At = Ab is an arbitrary choice */
/*      mblr = ad - mue*tb */
    susypara_1.beta = atan(susypara_1.tb);
    d__1 = susypara_1.ma;
    d__2 = smpara_1.mz;
    d__4 = susypara_1.ma;
    d__5 = smpara_1.mz;
    d__3 = d__4 * d__4 + d__5 * d__5;
    d__6 = smpara_1.mz;
    d__7 = susypara_1.ma;
    d__8 = cos(susypara_1.beta * 2.);
    mlh2 = (d__1 * d__1 + d__2 * d__2 - sqrt(d__3 * d__3 - d__6 * d__6 * 4. * 
	    (d__7 * d__7) * (d__8 * d__8))) * .5;
    higgsmass_1.mlh = sqrt(mlh2);
    d__1 = susypara_1.ma;
    d__2 = smpara_1.mz;
    d__4 = susypara_1.ma;
    d__5 = smpara_1.mz;
    d__3 = d__4 * d__4 + d__5 * d__5;
    d__6 = smpara_1.mz;
    d__7 = susypara_1.ma;
    d__8 = cos(susypara_1.beta * 2.);
    mhh2 = (d__1 * d__1 + d__2 * d__2 + sqrt(d__3 * d__3 - d__6 * d__6 * 4. * 
	    (d__7 * d__7) * (d__8 * d__8))) * .5;
    higgsmass_1.mhh = sqrt(mhh2);
    d__1 = susypara_1.ma;
    d__2 = smpara_1.mz;
    susypara_1.alpha = acos(-cos(susypara_1.beta * 2.) * (d__1 * d__1 - d__2 *
	     d__2) / (mhh2 - mlh2)) / 2.;
    if (susypara_1.alpha > 0.) {
	susypara_1.alpha = -susypara_1.alpha;
    }
    d__1 = susypara_1.ma;
    d__2 = smpara_1.mw;
    lle_1.mhptree = sqrt(d__1 * d__1 + d__2 * d__2);
    def2();
/* ------------------------------------------------------------- */
    mtold = smpara_1.mt;
    mhiggslle(&susypara_1.msusytl, &susypara_1.msusytr, &susypara_1.mtlr, &
	    susypara_1.mblr, &mtold, &smpara_1.mt, &smpara_1.mb, &
	    susypara_1.mst1, &susypara_1.mst2, &susypara_1.stt, &
	    susypara_1.ma, &susypara_1.tb, &susypara_1.alpha, &smpara_1.gf, &
	    smpara_1.as, &para_1.cf, &smpara_1.el, &smpara_1.mz, &smpara_1.mw,
	     &susypara_1.mue, &lle_1.mlhlle1, &lle_1.mlhlle2, &
	    lle_1.mlhllediag1, &lle_1.mlhllediag2, &lle_1.mhhllediag1, &
	    lle_1.mhhllediag2, &lle_1.alphadiag1, &lle_1.alphadiag2, &
	    lle_1.mhp);
} /* feynhiggsfastsub_ */

/*
 Copyright (C) 1997, Alexander Pukhov 
*/
#include "syst.h"
#include "polynom.h"
/*#include "test_wrt.h"*/
#include "tensor.h"
#include "spinor.h"

int spinLength;

static poly     spnr;         /* from calcspur */
static int     nused;        /* from calcspur */
static int  used[118];    /* from calcspur */ 
static poly     t1_;          /* from multspinmemb */
static poly     t2_;          /* from multtwospin */
static int  forspur;      /* from multtwospin */
static char     indlist[119]; /* from multtwospin */

static poly  calconespur(void)  /*  (Nused,Used,Spnr), recursion  */ 
{int        nu; 
 int    sign, si, sk; 
 int        i, k; 
 poly        ans, r1, r2; 

   nu = spnr->tail.spin.l; 
   if (nu == nused)   /*  IF last step  */ 
   { 
      newmonom(&ans); 
      ans->coef.complex.re = (poly)plusone();
      ans->coef.complex.im = NULL; 
      for (i = 0; i < tensLength; i++) ans->tail.power[i] = 0;
      ans->next = NULL; 
      return ans; 
   }   /*  IF last step  */ 

   ans = NULL; 
   k = 1; 
   while (used[k-1]) ++(k); 
   used[k-1] = TRUE; 
   nused += 2; 
   sk = spnr->tail.spin.g[k-1]; 
   sign = 1; 
   for (i = k + 1; i <= spnr->tail.spin.l; i++) 
   if (!used[i-1]) 
   { 
      si = spnr->tail.spin.g[i-1]; 
      used[i-1] = TRUE; 
      r1 = calconespur(); 
      used[i-1] = FALSE; 

      if (r1 != NULL) 
      if (sk < 0 && si < 0)  multtenspoly(&r1,scalarmult(sk,si)); 
      else 
      { 
         r2 = r1; 
         while (r2 != NULL) 
         { 
            if (si > 0) r2->tail.tens[si-1] = sk; 
            if (sk > 0) r2->tail.tens[sk-1] = si; 
            r2 = r2->next; 
         } 
      } 

      if (sign == -1) multtensint(&r1,-1); 
      sign = -sign; 
      sewtens(&ans,&r1,tensLength); 
   }   /*  For i:=k+1... */ 
   used[k-1] = FALSE; 
   nused -= 2; 
   return ans; 
} 


poly  calcspur(poly spnr1)
{poly         summ, onesp; 
 int         i, i1, i2, i3, i4, j; 
 int     c, cc, sgn; 
 char     ee[4]; 
 poly         tmpsp, tmpsp2; 


  /* Nested function: calconespur */ 
  /*  CalcSpur  */ 
   spnr = spnr1;
   summ = NULL; 
   while (spnr != NULL) 
   { 
      if (spnr->tail.spin.g5 == 0) 
      { 
         nused = 0; 
         for (j = 1; j <= spnr->tail.spin.l; j++) 
            used[j-1] = FALSE;   /*  for recursion  */ 
         /*  (Spnr)  */ 
         onesp = calconespur(); 
      } 
      else 
      { 
         if (spnr->tail.spin.l < 4) onesp = NULL; 
         else 
         { 
            onesp = NULL; 
            for (j = 1; j <= spnr->tail.spin.l; j++) 
               used[j-1] = FALSE; 
            for (i1 = 1; i1 <= spnr->tail.spin.l - 3; i1++) 
            for (i2 = i1 + 1; i2 <= spnr->tail.spin.l - 2; i2++) 
            for (i3 = i2 + 1; i3 <= spnr->tail.spin.l - 1; i3++) 
            for (i4 = i3 + 1; i4 <= spnr->tail.spin.l; i4++) 
            { 
               nused = 4; 
               for (j = 1; j <= spnr->tail.spin.l; j++) 
                  used[j-1] = FALSE; 
               ee[0] = spnr->tail.spin.g[i1-1]; used[i1-1] = TRUE; 
               ee[1] = spnr->tail.spin.g[i2-1]; used[i2-1] = TRUE; 
               ee[2] = spnr->tail.spin.g[i3-1]; used[i3-1] = TRUE; 
               ee[3] = spnr->tail.spin.g[i4-1]; used[i4-1] = TRUE; 
               j = 1; 
               sgn = ((i1 + i2 + i3 + i4) & 1) == 0 ? 1 : -1; 
               do 
               { 
                  c = ee[j-1]; 
                  cc = ee[j + 1-1]; 
                  if (cc < c) 
                     ++(j); 
                  else 
                     if (cc > c) 
                     { 
                        ee[j-1] = cc; 
                        ee[j + 1-1] = c; 
                        sgn = -sgn; 
                        if (j > 1) 
                           --(j); 
                        else 
                           ++(j); 
                     } 
                     else 
                        sgn = 0; 
               } while (!(j == 4 || sgn == 0)); 
               if (sgn != 0) 
               { 
                  tmpsp = calconespur(); 
                  if (sgn == -1) multtensint(&tmpsp,-1); 
                  tmpsp2 = tmpsp; 
                  while (tmpsp2 != NULL) 
                  { 
                     for (i = 0; i < 4; i++) 
                     tmpsp2->tail.tens[maxIndex+i] = ee[i]; 
                     tmpsp2->coef.complex.im=tmpsp2->coef.complex.re;
                     tmpsp2->coef.complex.re=NULL;
                     tmpsp2 = tmpsp2->next; 
                  } 
                  sewtens(&onesp,&tmpsp,tensLength); 
               } 
            } 
         } 
      } 
      multtensComplexpoly(&onesp,spnr->coef.complex.re,spnr->coef.complex.im); 
      sewtens(&summ,&onesp,tensLength); 
      onesp = spnr; 
      spnr = spnr->next; 
      delpoly(&(onesp->coef.complex.re));
      delpoly(&(onesp->coef.complex.im)); 
      delmonom(&onesp); 

   } 
/*    MultTensInt(Summ,4); */ 
   return summ; 
}   /*  CalcSpure  */ 


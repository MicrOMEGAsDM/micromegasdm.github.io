#ifndef  __INTERFACE__
#define  __INTERFACE__

#ifdef __cplusplus
extern "C" {
#endif 

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<unistd.h>

typedef struct numout
{
  void * handle;
  int nprc; 
  int nvar; 
  int nfunc;
  int nIn;
  int nOut;
  char * (*pinf)(int , int , double*);
  char * (*den)(int, int, int*,int*);
  char ** varName;
  double (*sqme)(int , double * , int * );
  int (*calcFunc)(void);
  double * va;   
  int * rwidth;  
  int * twidth;
  int * gwidth;
  double ** link;
  int init;
} numout;


/*=============================
     MSSM 2->2 cross sections
=============================*/

extern numout *  newProcess(char*Process,char* lib);
extern double cs22(numout * cc, int nsub_,double P,  double cos1, double cos2 , int * err);

extern int  infor22(numout * cc, int nsub_, char* name1,char* name2,
               char*name3,char*name4,double* m1,double*m2,double*m3,double*m4);

extern double decay2(char *pName, int k, char *n1, char * n2);

extern double annihilation(double v, int k, char* n1, char* n2);


/*==============================
       QCD functions 
================================*/

extern double  initQCD(double MZalphaS,double McMc,double MbP,double MtP);
extern double alphaQCD(double Q);
extern double MbRun(double Q);
extern double MbEff(double Q);
extern double MtRun(double Q);
extern double MtEff(double Q);
extern double MbPole;

/*=========================
   Parameter assignments 
==========================*/

extern int assignVal(char * name, double val);
extern double *  findVarAddress(char * name); 
extern int readLesH(char * filename, int SWtb);
extern int writeLesH(char *fname);
extern void assignValW(char * name, double val);
extern double findValW(char * name);

/*=====================================================
   MSSM Parameters input at low scale
=======================================================*/

extern int  suspectEwsbMSSM( int  lCon);

extern int  isajetEwsbMSSM(int lCon);

extern int readEwsb(char * fname);

extern int ewsbInitFile(char * filename, int LCon);


/*=============================================
  MSSM Parameters motivated by SUGRA scenario
  =============================================*/
extern int  suspectSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                        );
extern int isajetSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                      );


extern int  softSusySUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                         );

extern int sphenoSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl,double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                      );

/*=============================================
  MSSM Parameters motivated by other  scenarios
  =============================================*/

extern int suspectAMSB(double am0,double m32,double stgbeta,double ssgnmu0);

extern int isajetAMSB(double am0,double m32,double tb,double sgn);
extern int softSusyAMSB(double am0,double m32,double tb,double sgn);
extern int sphenoAMSB(double am0,double m32,double tb,double sgn);

extern int isajetGMSB(double Lambda, double Mmess,double tb, double SGNMU,double N5, double cGrav,
double Rsl, double dmH_d2, double dmH_u2, double d_Y, double n5_1, double n5_2, double n5_3);



/*====================================================
   Evaluation of running masses and particles  widths
======================================================*/

extern int calcDep(int dMbOn);
  
/*===========================================
   Checking of parameters 
  ===========================================*/ 

extern int findVal(char * name, double * val);
extern void printMSSMvar(FILE *f);
extern void printVar(FILE *f, int N);
extern void  printMasses(FILE * f, int sort);
extern char * lsp(void);
extern double lspmass_(void);


/*=====================================
    Relic density evaluation 
  =====================================*/ 

extern double darkOmega(double *Xf,int Fast, double Beps);
extern double darkOmegaFO(double *Xf,int fast,double Beps);
extern double printChannels(double Xf,double cut,double Beps,int prcnt,FILE *f );   

/*================================================
  Experimental constrains  on the  MSSM parameters  
  ===============================================*/
extern double deltarho_(void);
extern double gmuon_(void);
extern double gmuonold_(void);
extern int    masslimits_(void);
extern double bsgnlo_(void);
extern double deltaMb(void);
extern double bsmumu_(void);

typedef  struct { int del; double q;} common1int;

extern void delFiles(int x); 
extern void delfiles_(int *x);


/*===============================================
      Auxilary  functions 
=================================================*/ 


extern void un_link(char * f); /* delete file without errno corruption */

                                                                                                                                                                
extern double vscnngg(double v);
extern double vscnngz(double v);

#endif

#ifdef __cplusplus
}
#endif 

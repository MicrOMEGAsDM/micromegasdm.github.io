#include"spheno_path.h"

/*===================================*/
#include"micromegas.h"
#include"micromegas_aux.h"

#include<sys/wait.h>

int  sphenoSUGRA(double tb, double gMG1,double gMG2,double gMG3,
             double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
             double gMl2,double gMl3,double gMr2,double gMr3,
             double gMq2,double gMq3,double gMu2,double gMu3,double gMd2,double gMd3)
{ 
   char  buff[1000];
   int err;
   FILE*f;
   int del=getdelfilesstat_();

   err=sugraLesH("LesHouches.in", tb, gMG1,gMG2,gMG3,
             gAl, gAt, gAb, sgn, gMHu, gMHd,
             gMl2,gMl3,gMr2,gMr3,
             gMq2,gMq3,gMu2,gMu3,gMd2,gMd3);
             
             

   if(err) {printf("can not write down LesHouches.in file\n"); exit(10);}

   f=fopen("Control.in","w");
   fprintf(f,"0       | ErrorLevel\n"
             ".false. ! Calculation of branching ratios\n"
             ".false. ! Calculation of cross sections\n");
   fclose(f);
      
   sprintf(buff,"%s/SPheno",SPHENO);
   un_link("SPheno.spc");
   err=system(buff);   
   if(del)
   {
     un_link("Control.in");
     un_link("LesHouches.in");
     un_link("Messages.out");
     un_link("SPheno.out");
   }
   if(err<0 || WIFSIGNALED(err)>0 ) { if(del)un_link("SPheno.spc"); exit(err);}
   if( WEXITSTATUS(err) >0) { if(del)un_link("SPheno.spc"); return -1;}

   err=readLesH("SPheno.spc",0);
   if(del)un_link("SPheno.spc");
   return err;
}

#define xxxSUGRAc  sphenoSUGRAc
#define xxxSUGRA   sphenoSUGRA
#include "sugrac.inc"


int  sphenoAMSB(double m0,double m32, double tb, double sgn)
{ 
   char  buff[1000];
   int err;
   FILE*f;
   int del=getdelfilesstat_();
   err=amsbLesH("LesHouches.in", m0,m32, tb, (int)sgn);
   if(err) {un_link("LesHouches.in"); return -1;}
   un_link("SPheno.spc");
   
   f=fopen("Control.in","w");
   fprintf(f,"0       | ErrorLevel\n"
             ".false. ! Calculation of branching ratios\n"
             ".false. ! Calculation of cross sections\n");
   fclose(f);
      
   sprintf(buff,"%s/SPheno",SPHENO);
   err=system(buff);

   if(del) 
   {
     un_link("Control.in");
     un_link("LesHouches.in");
     un_link("Messages.out");
     un_link("SPheno.out");
   }

   if(err){ printf("\n Spheno can not be exequted or was finished with error\n"
                   "The command is " SPHENO "/SPheno\n");
            if(del) un_link("SPheno.spc");       
                    return -1;
          }   
   err=readLesH("SPheno.spc",0);
   if(del) un_link("SPheno.spc");

   return err;
}


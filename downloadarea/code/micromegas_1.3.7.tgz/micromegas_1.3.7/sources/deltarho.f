      REAL*8 FUNCTION  deltarho()
c--------------------------------------------------
c   calculates leading one-loop SUSY delta_rho contributions of 3rd gen
c sfermions (plus leading two-loop QCD contributions) 
c  INPUT: MT, gmst(2), gmsb(2),gmstau(2),msn: top,stop,sbottom,
c  stau, stau neutrino masses and stop, sbottom, stau mixing angles
c  OUTPUT: drho = rho-1 
c--------------------------------------------------
      IMPLICIT NONE        
      REAL*8 findValW
      REAL*8 mt,msn,thetat,thetab,thel
      REAL*8 GF

      REAL*8 GFmem,delrho 
      REAL*8 ct,st,cb,ctau ,stau,cta2,sta2,ct2,st2,cb2,sb2,drho
      REAL*8 su_fr,drhotau,pi,drhotb,mt1,mt2,mb1,mb2,mta1,mta2,sb
      REAL*8 x,y

      su_fr(x,y) = x+y-2*x*y/(x-y)*dlog(x/y)
c
      GF=1.16639d-5
      pi = 4*datan(1.d0)
      mt=findValW('Mtp')
      thetat=atan2(findValW('Zt12'),findValW('Zt11'))
      thetab=atan2(findValW('Zb12'),findValW('Zb11'))
      thel=atan2(findValW('Zl12'),findValW('Zl11'))

      ct=dcos(thetat)
      st=dsin(thetat)
      cb=dcos(thetab)
      sb=dsin(thetab)
      ctau =dcos(thel)
      stau =dsin(thel)
      cta2=ctau**2
      sta2=stau**2
      ct2=ct**2
      st2=st**2
      cb2=cb**2
      sb2=sb**2

      mt1=findValW('MSt1')**2
      mt2=findValW('MSt2')**2
      mb1=findValW('MSb1')**2
      mb2=findValW('MSb2')**2
      mta1=findValW('MSl1')**2
      mta2=findValW('MSl2')**2
      msn=findValW('MSnl')
c
      drhotb= (ct2*(cb2*su_fr(mt1,mb1)+sb2*su_fr(mt1,mb2)) +
     .      st2*(cb2*su_fr(mt2,mb1)+sb2*su_fr(mt2,mb2)) -
     .      ct2*st2*su_fr(mt1,mt2)-cb2*sb2*su_fr(mb1,mb2))
      drhotau= -cta2*sta2*su_fr(mta1,mta2)+cta2*su_fr(mta1,msn**2) +
     .sta2*su_fr(mta2,msn**2)
      drho = 3*drhotb*(1.d0 +2*0.12/3/pi*(1.d0+pi**2/3))+drhotau
      deltarho = GF/(8* pi**2* dsqrt(2.d0))*drho
      end


#ifdef __hpux
#include<dl.h>
#else
#include <dlfcn.h>
#endif

#include <unistd.h>

#include <sys/wait.h>

#include <sys/types.h>
 #include <sys/utsname.h>


#include <sys/stat.h>
#include <fcntl.h>
#include <sys/file.h>


#include "num_out_hhh.h"
#include "micromegas.h"

#include "s_particles.tab"
#include "h_particles.tab"
#include "path.h"

#include "micromegas_aux.h"


static int checkLockFile(void)
{ int fd,ret;
  static char *lockTxt=NULL; 
  if(lockTxt==NULL)
  {
     struct utsname buff;
     uname(&buff);
     lockTxt=(char*)malloc(100);
     sprintf(lockTxt," process %d on %s\n",getpid(),buff.nodename);
  }

  fd=open(SOURCES "/work/lock", O_WRONLY|O_CREAT,0666);
  if(fd<0)
  { printf("Can not creat lock file: " SOURCES "/work/lock\nProgram terminated\n");
    exit(55); return -1;
  }
/*     ret=flock(fd,LOCK_EX);   */
  ret = lockf(fd, F_TLOCK, 10);
  if(ret)
  { printf("Library generation is temporary locked by other program\n"
           "see file " SOURCES "/work/lock\n");
    lockf(fd, F_LOCK, 10);
  }
  write(fd,lockTxt,strlen(lockTxt));
  return fd;
}

static void* newSymbol(void*handle,char *name)
{
#ifdef __hpux
void * addr;
     if(shl_findsym((shl_t*)&handle,name,TYPE_UNDEFINED,&addr)) return NULL;
       else return addr;
#else
      return dlsym(handle, name);
#endif
}

static void * dLoad(char * libName)
{
#ifdef __hpux
       return  shl_load(libName,0,0L);
#else
       return dlopen(libName, RTLD_NOW);
#endif
}


static void dClose(void * handle)
{
#ifdef __hpux
       shl_unload(handle);
#else
       dlclose(handle);
#endif
}


static int runWidthFlag=0;
static double (*sqme)(int nsub,double *pvect, int * err_code);

static char * inP[NC];
static int   inAP[NC];
static int    inG[NC];

static numout * code22[NC][NC];

static int inC[NC][NC];    /* combinatoric coefficients */
static double inDelta[NC]; /* inDelta[i]= (inMass[i]-M)/M; */
static double inG_[NC];    /* inG[i]*pow(1+inDelta[i],1.5);*/
static double * inMassAddress[NC];
static double inMass[NC];  /* masses */
static int sort[NC];

static int LSP;
double M;                  /* =inMass[LSP] */
double M1,M2;
static double DeltaXf;

/* 2->2 kinematic */
static double pvect[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static double pmass[4];
static double PcmOut;
static double totcoef;

#define XSTEP 1.1
static double eps=0.001; /* precision of integration */

static int nsub=1;       /*  subprocess number  */

static double MassCut;

static int fast_;    /* to pass the Fast argument */
static double xf_;   /* to pass the Xf argument   */
  
#define MPlank 1.22E19 /*GeV*/

static int  kin22(double PcmIn)
{  
   double ms,md,sqrtS;

   sqrtS=sqrt(pmass[0]*pmass[0]+PcmIn*PcmIn)+sqrt(pmass[1]*pmass[1]+PcmIn*PcmIn);
   ms = pmass[2] + pmass[3];  if(ms>=sqrtS*0.9999999) return 1;
   md = pmass[2] - pmass[3];
   PcmOut = sqrt((sqrtS-ms)*(sqrtS+ms)*(sqrtS-md)*(sqrtS+md))/(2*sqrtS);
   totcoef = PcmOut /(32.0*M_PI*PcmIn*sqrtS*sqrtS);
   pvect[3] = PcmIn;
   pvect[7] =-PcmIn;
   pvect[0] = sqrt(PcmIn*PcmIn   + pmass[0]*pmass[0]);
   pvect[4] = sqrt(PcmIn*PcmIn   + pmass[1]*pmass[1]);
   pvect[8] = sqrt(PcmOut*PcmOut + pmass[2]*pmass[2]);
   pvect[12]= sqrt(PcmOut*PcmOut + pmass[3]*pmass[3]);

   return 0;
}


static double  dSigma_dCos(double  cos_f)
{
   double  r;
   double sin_f=sqrt(fabs((1-cos_f)*(1+cos_f)));
   int err_code=0;
   pvect[11]=PcmOut*cos_f;
   pvect[15]=-pvect[11];
   pvect[10]=PcmOut*sin_f;
   pvect[14]=-pvect[10];
   r = (*sqme)(nsub,pvect,&err_code);
   err_code=0;
   return r * totcoef;
}

static  double sigma_simpson(double PcmIn)
{ if(kin22(PcmIn)) return 0; else return simpson(dSigma_dCos,-1.,1,0.3*eps);}

static  double sigma_gauss(double PcmIn)
{ if(kin22(PcmIn)) return 0.; else return  gauss(dSigma_dCos,-1.,1.,5);}

static double (*sigma)(double)= sigma_gauss;

static double geff(double x)
{ double sum=0; int l;

  for(l=0;l<NC;l++)
  { int k=sort[l];
    double A=x*inDelta[k];
    if(A>15 || M+inMass[k] > MassCut) return sum;
    sum+=inG_[k]*exp(-A)*K2pol(1/(x+A));
  }
  return sum;
}


static void termod(double t, double * sqrt_gStar, double * heff)
{
  const  double table[276][3]=
  {
#include"geff_heff.tab"
  };

  if(t>= table[0][0])
  { if(sqrt_gStar) *sqrt_gStar=table[0][1];
    if(heff)             *heff=table[0][2];
  } else if(t<=0 )
  { if(sqrt_gStar) *sqrt_gStar=table[275][1];
    if(heff)             *heff=table[275][2];
  } else
  {
    int hi=0, lo=275, c;
    double tlo,thi;
    double slo,shi;

    for(c=138; lo-hi >1; c=(lo+hi)/2) if(table[c][0]< t) lo=c; else hi=c;

    tlo=table[lo][0];
    thi=table[hi][0];

    if(sqrt_gStar)
    {
       slo=table[lo][1];
       shi=table[hi][1];
       *sqrt_gStar=( (thi-t)*slo - (tlo-t)*shi)/(thi-tlo);
    }
    if(heff)
    {  slo=table[lo][2];
       shi=table[hi][2];
       *heff=( (thi-t)*slo - (tlo-t)*shi)/(thi-tlo);
    }
  }
}

static double y_pass;

static double weight_integrand(double v)
{  double x,gf;
   double sqrt_gStar;

   if(v==0.) return 0;
   x=xf_-3*log(v)/(y_pass-2);
   gf=geff(x);

   termod(M/x,&sqrt_gStar,NULL);
   return K1pol(1/(x*y_pass))*3*v*v*sqrt_gStar/(sqrt(x)*gf*gf*(y_pass-2));
}

static double weightBuff_x[1000];
static double weightBuff_y[1000];
static int inBuff=0;

static double weight(double y)
{ int i;
  double w;
  for(i=0;i<inBuff;i++) if(y==weightBuff_x[i]) return weightBuff_y[i];
  y_pass=y;
  w=  simpson(weight_integrand,0.,1.,0.3*eps);
  if(inBuff<1000){weightBuff_x[inBuff]=y; weightBuff_y[inBuff++]=w;}
  return w;
}

static int exi;

static double s_integrand( double u)
{  double z,y,sv_tot,w;
   double Xf_1;
   double ms,md,sqrtS,PcmIn;
   
   if(u==0. || u==1.) return 0.;

   z=1-u*u;
   y=2 +(DeltaXf - 3*log(z))/xf_;
   sqrtS=M*y;

   ms = M1 + M2;  if(ms>=sqrtS)  return 0;
   md = M1 - M2;
   PcmIn = sqrt((sqrtS-ms)*(sqrtS+ms)*(sqrtS-md)*(sqrtS+md))/(2*sqrtS);
   sv_tot=sigma(PcmIn);         

   if(exi) { w=weight(y); Xf_1=1;} else {w=K1pol(1/(xf_*y)); Xf_1=xf_;}

   return sqrt(2*Xf_1*y/M_PI)*y*(PcmIn*PcmIn/(M*M))*sv_tot*w*6*u*z*z;
}

static int Npow;

static double s_pow_integrand(double u)
{
   double ms,md,sqrtS;
   double z,y,sv_tot,pp,w,Xf_1;
   double PcmIn;
   
   if(u==0. || u==1.) return 0.;

   z=1-u*u;
   y=2+(DeltaXf - 3*log(z))/xf_;

   ms = M1 + M2;
   md = M1 - M2;
   sqrtS=(M*y);
   PcmIn = sqrt((sqrtS-ms)*(sqrtS+ms)*(sqrtS-md)*(sqrtS+md))/(2*sqrtS);
   pp= PcmIn* PcmIn;

   switch(Npow)
   { case 0: sv_tot=1; break;
     case 1: sv_tot= pp; break;
     case 2: sv_tot= pp*pp; break;
     case 3: sv_tot= pp*pp*pp; break;
   }

   if(exi){ w=weight(y); Xf_1=1;} else { w=K1pol(1/(xf_*y)); Xf_1=xf_;}
   return sqrt(Xf_1*y/(2*M_PI))*y*(PcmIn/M)*sv_tot*w*6*u*z*z;
}

static double m2u(double m) {return sqrt(1-exp((DeltaXf+xf_*(2-m/M))/3));}

typedef struct gridStr
{  int n;
   double ul[100];
   double ur[100];
   int pow[100];
}  gridStr;

static double u_max;

static gridStr   makeGrid(double mp,double wp)
{
  gridStr grd;

  int n=0,j;
  int pow_[6]={3,3,4,4,3,3};
  double c[5]={-8,-3,0,3,8};

  grd.ul[0]=0.;
  for(j=0;j<5;j++) if(mp+c[j]*wp>M*(2+DeltaXf/xf_))
  {  grd.ur[n]=m2u(mp+c[j]*wp);
     grd.pow[n]=pow_[j];
     grd.ul[n+1]=grd.ur[n];
     if( grd.ur[n]>u_max) { grd.ur[n]=u_max;  grd.n=n+1; return grd;}
     n++;
  }
  grd.ur[n]=u_max;
  grd.pow[n]=pow_[5];
  grd.n=n+1;
  return grd;
}

#ifdef DEBUG
static void printGrid(gridStr * grd)
{ int i;
  printf("~~~~~~~~~~~~~\n");
  for(i=0;i<grd->n;i++) printf("%E %E %d\n",grd->ul[i],grd->ur[i],grd->pow[i]);
  printf("~~~~~~~~~~~~~\n");
}
#endif

static gridStr  crossGrids(gridStr * grid1, gridStr * grid2)
{ gridStr grid;
  int n=0,i0=0,i1=0,i;
  grid.ul[0]=0.;
  while(i0<grid1->n && i1<grid2->n)
  { double d0= grid1->pow[i0]/(grid1->ur[i0]-grid1->ul[i0]);
    double d1= grid2->pow[i1]/(grid2->ur[i1]-grid2->ul[i1]);
    double d = ( d0>d1? d0:d1);
    int m=(grid1->pow[i0] > grid2->pow[i1]? grid1->pow[i0]:grid2->pow[i1]);

    if(grid1->ur[i0] < grid2->ur[i1]) { grid.ur[n]=grid1->ur[i0++];}
    else                              { grid.ur[n]=grid2->ur[i1++];}


    grid.pow[n]=0.999+d*(grid.ur[n]-grid.ul[n]);

    if(grid.pow[n]>m) grid.pow[n]=m;
    if(grid.pow[n]==1) grid.pow[n]=2;

    n++;
    grid.ul[n]=grid.ur[n-1];
  }
  grid.n=n;
  for(i=0;i<grid.n;i++) if(grid.ur[i]-grid.ul[i]>0.4
                         && grid.pow[i]<4)  grid.pow[i]=4;
  return grid;
}


static void testSubprocesses(void)
{
 static int first=1;
 int k1,k2,i,j;

 if(first)
 {  first=0;

    for(i=0,j=0;i<NSP;i++)
    {  
       inP[j]=Sparticles[i].name;
       inMassAddress[j]=findVarAddress(Sparticles[i].mass);
       if(!inMassAddress[j]) 
       { printf(" Can not find mass  %s among parameetrs\n",Sparticles[i].mass);
         exit(5);
       }

       inG[j]=(Sparticles[i].spin2+1)*Sparticles[i].cdim;
       if(strcmp(Sparticles[i].name,Sparticles[i].aname))
       {
         inAP[j]=j+1;
         j++;
         inP[j]=Sparticles[i].aname;
         inG[j]=inG[j-1];
         inAP[j]=j-1;
         inMassAddress[j]=inMassAddress[j-1];
       } else inAP[j]=j;
       j++;
    }

    for(i=0;i<NC;i++) sort[i]=i;
    for(k1=0;k1<NC;k1++) for(k2=0;k2<NC;k2++) inC[k1][k2]=-1;
    for(k1=0;k1<NC;k1++) for(k2=0;k2<NC;k2++) if(inC[k1][k2]==-1)
    {  int kk1=inAP[k1];
       int kk2=inAP[k2];
       inC[k1][k2]=1;
       if(inC[k2][k1]==-1) {inC[k2][k1]=0; inC[k1][k2]++;}
       if(inC[kk1][kk2]==-1) {inC[kk1][kk2]=0; inC[k1][k2]++;}
       if(inC[kk2][kk1]==-1) {inC[kk2][kk1]=0; inC[k1][k2]++;}
    }

    for(k1=0;k1<NC;k1++) for(k2=0;k2<NC;k2++) code22[k1][k2]=NULL;
 }

 for(i=0;i<NC;i++) inMass[i]=fabs(*(inMassAddress[i]));
 for(i=0; i<NC-1;)
 { int i1=i+1;
   if(inMass[sort[i]] > inMass[sort[i1]])
   { int c=sort[i]; sort[i]=sort[i1]; sort[i1]=c;
     if(i) i--; else i++;
   } else i++;
 }

 LSP=sort[0];
 M=inMass[LSP];

 for(i=0;i<NC;i++)
 { inDelta[i]= (inMass[i]-M)/M;
   inG_[i]=inG[i]*pow(1+inDelta[i],1.5);
 }

  for(k1=0;k1<NC;k1++)  for(k2=0;k2<NC;k2++) if(code22[k1][k2]) code22[k1][k2]->init=0;

}
 
int calcDep(int dMbOn)
{ int i;
  double Q;
  double *MtA=findVarAddress("Mt");
  double *MbA=findVarAddress("Mb");
  double Mtp=findValW("Mtp");
  double sWidth=findValW("sWidth");
  double sw;
  double Qmin;
  double MbMb=findValW("MbMb");
  testSubprocesses();
  twidth_hhh=1;


  Qmin=initQCD(findValW("alfSMZ"),1.4,MbMb,Mtp);
  if(Qmin<0 || Qmin>MbMb) return 1;

  Q=2*fabs(findValW("MNE1"));
  assignValW("SC",sqrt(4*M_PI*alphaQCD(Q/2)));
  assignValW("EE",sqrt(4*M_PI*findValW("alfEMZ")));
  sw=findValW("SW");
  assignValW("MW", sqrt(1.-sw*sw)*findValW("MZ")); 

  if(dMbOn) assignValW("dMb",deltaMb()); else assignValW("dMb",0.);

  for(i=0;i< NH; i++) 
  { 
    Q=findValW(higgsInfor[i].mass); 
    *MtA=MtEff(Q);*MbA=MbEff(Q);
    assignValW(higgsInfor[i].width, width2(higgsInfor[i].name,&higgsInfor[i].wPos));
    if(FError) return 2;
  }


  Q=Mtp/2; *MtA=Mtp; *MbA=MbEff(Q); assignValW("wt",width2("t",NULL)); if(FError) return 2;
  Q=45;              *MbA=MbEff(Q); assignValW("wZ",width2("Z",NULL)); if(FError) return 2;
                                    assignValW("wW",width2("W+",NULL));if(FError) return 2;

  Q=2*fabs(findValW("MNE1")); *MtA=MtEff(Q); *MbA=MbEff(Q);   

  if(sWidth>0) for(i=0;i< NSP;i++) assignVal(Sparticles[i].width,sWidth*M);
  else         for(i=0;i< NSP;i++) assignVal(Sparticles[i].width, 
                            width2(Sparticles[i].name,&Sparticles[i].wPos));
  return 0;
}


static numout* loadLib(void* handle, char * lib)
{ int err=0;
  numout * cc;
  int *buff;
  char name[100];
  if(!handle) return NULL;   

  cc=malloc(sizeof(numout));
  cc->handle=handle;
  sprintf(name,"nprc_%s",lib);
  buff= newSymbol(handle, name);if(!buff) err=1; else cc->nprc=*buff;
      sprintf(name,"nvar_%s",lib);
  buff= newSymbol(handle,name);if(!buff) err=2; else cc->nvar=*buff;
  sprintf(name,"nfunc_%s",lib);
  buff= newSymbol(handle,name); if(!buff) err=3; else cc->nfunc=*buff;
  sprintf(name,"pinf_%s",lib);
  cc->pinf= newSymbol(handle,name); if(!cc->pinf) err=4;
  sprintf(name,"varName_%s",lib);
  cc->varName= newSymbol(handle,name); if(!cc->varName) err=5;
  sprintf(name,"sqme_%s",lib);
  cc->sqme=newSymbol(handle,name); if(!cc->sqme) err=6;
  sprintf(name,"calcFunc_%s",lib);
  cc->calcFunc=newSymbol(handle,name); if(!cc->calcFunc) err=7;
  sprintf(name,"rwidth_%s",lib);
  buff=newSymbol(handle, name); if(!buff) err=8; else{cc->rwidth=buff; *buff=0;}
  sprintf(name,"twidth_%s",lib);
  buff=newSymbol(handle, name); if(!buff) err=9; else{cc->twidth=buff; *buff=0;}

  sprintf(name,"gwidth_%s",lib);
  buff=newSymbol(handle, name); if(!buff)err=10 ; else{cc->gwidth=buff; *buff=0;}

  sprintf(name,"va_%s",lib);
  cc->va=newSymbol(handle, name); if(!cc->va) err=11;

  sprintf(name,"den_info_%s",lib);
  cc->den=newSymbol(handle,name); if(!cc->pinf) err=12;

  sprintf(name,"nin_%s",lib);
  buff=newSymbol(handle,name); if(!buff) err=13; else cc->nIn=*buff;

  sprintf(name,"nout_%s",lib);
  buff=newSymbol(handle,name); if(!buff) err=14; else cc->nOut=*buff;

  if(err || cc->nprc==0)
  {
/*         dClose(handle); */
      free(cc); return NULL;
  } else
  { int i;
        cc->init=0;
        cc->link=malloc(sizeof(double*)*(1+cc->nvar));
        cc->link[0]=NULL;
        for(i=1;i<=cc->nvar;i++) cc->link[i]=findVarAddress(cc->varName[i]);
  }
  return cc;
}



static int  new_code(int k1,int k2)
{
   char proclibf[1000],ext[40], *c;
   void * handle=NULL;

   sprintf(ext,"_%s_%s",inP[k1]+1,inP[k2]+1);
   while((c=strchr(ext,'+'))){ (*c)='P';}
   while((c=strchr(ext,'-'))){ (*c)='M';}

   sprintf(proclibf,"%s/2-2/omglib%s.so",SOURCES,ext);

   handle=dLoad(proclibf);
   if(!handle)
   { char command[1000];
     int ret,fd;
     fd=checkLockFile();

     sprintf(command,"cd %s/work; ./new_channel \"%s,%s\" %s",SOURCES, inP[k1],inP[k2],ext);
     ret=system(command);
     close(fd);

     if(ret==0) handle=dLoad(proclibf); else 
     { printf(" Can not compile %s,%s ->2*x library\n",  inP[k1],inP[k2]);
       printf(" Program terminated\n");
       exit(ret);
     }   
   }
   if(!handle)
   { inC[k1][k2]=0;
     printf("Can not generate %s,%s -> 2*x processes\n",inP[k1],inP[k2]);
/*     printf("DLERROR: %s\n",dlerror()); */
     exit(2);
   }
   else
   {  
      numout * cc=loadLib(handle, ext+1);
      if(cc) 
      { (*cc->twidth)=1;
        code22[k1][k2]=cc;
      } else inC[k1][k2]=0;
   }
   return 0;
}





static void gaussC2(double * c, double * x, double * f)
{
  double  A[2][2];
  int i,j;
  double det;
  double B[2];
    
  for(i=0;i<2;i++)
  { int l=1; for(j=0;j<2;j++) {A[i][j]=l*c[i+j]; l=-l;}  
     B[i]=l*c[2+i];
  }
  
  det=A[0][0]*A[1][1] - A[0][1]*A[1][0];
  
  f[0]= ( B[0]*A[1][1]-B[1]*A[0][1])/det;
  f[1]= (-B[0]*A[1][0]+B[1]*A[0][0])/det;
  
  det=sqrt(f[0]+f[1]*f[1]/4.);
   
  x[0]= -f[1]/2.-det;
  x[1]= -f[1]/2.+det;
 
  for(i=0;i<2;i++) { B[i]=c[i]; A[0][i]=1; }
  for(j=0;j<2;j++)   A[1][j]=A[0][j]*x[j];

  det= A[0][0]*A[1][1] - A[0][1]*A[1][0];
  
  f[0]= ( B[0]*A[1][1]-B[1]*A[0][1])/det;
  f[1]= (-B[0]*A[1][0]+B[1]*A[0][0])/det;
} 



static double aRate(double X, int everage,int Fast, float ** wPrc)
{
  double Sum=0.;
  int i,l1,l2;
  int nPrc=0;
  char* pname[5];
  gridStr grid,grid1;
  double MassCutOut=MassCut+M*log(100.)/X;
  int nPrcTot=0;
  double  swidth,Msmall,Mlarge;
  swidth=findValW("sWidth");

  if(MassCutOut<M*(2+10/X)) MassCutOut=M*(2+10/X); 

  xf_=X;
  exi=everage;

  if(wPrc) *wPrc=NULL;

  for(l1=0;l1<NC;l1++)
  { int k1=sort[l1]; if(M+inMass[k1]>MassCut) break;
  for(l2=0;l2<NC;l2++)
  {
    double Sumkk=0.;
    double x[2],f[2];
    double factor;
    int k2=sort[l2];
    if(inMass[k1]+inMass[k2] > MassCut) break;

    if(inC[k1][k2]<=0) continue;
    if(code22[k1][k2]==NULL) new_code(k1,k2);
    if(inC[k1][k2]<=0) continue;


    if(!code22[k1][k2]->init)
    { numout * cd=code22[k1][k2];
      for(i=1;i<=cd->nvar;i++) if(cd->link[i]) cd->va[i]=*(cd->link[i]);
      *(cd->twidth)=1;
      if( cd->calcFunc() ) {FError=1; return -1;}
      *(cd->rwidth)=runWidthFlag;
      cd->init=1;
    }

    if(wPrc)
    {  nPrcTot+=code22[k1][k2]->nprc;
       *wPrc=(float*)realloc(*wPrc,sizeof(float)*(nPrcTot));
    }

    sqme=code22[k1][k2]->sqme;
    DeltaXf=(inDelta[k1]+inDelta[k2])*X;
    inBuff=0;

    M1=inMass[k1];
    M2=inMass[k2];
    
    Msmall=M1>M2? M1-M*(1-swidth): M2-M*(1-swidth);
    Mlarge=M1>M2? M2+M*(1-swidth): M1+M*(1-swidth);

    u_max=m2u(MassCutOut);
    if(Fast)
    { 
      if(Fast==1)
      {  double c[4];

         for(Npow=0;Npow<4;Npow++) c[Npow]=simpson(s_pow_integrand, 0. ,1. ,1.E-4);
         gaussC2(c,x,f);
         for(i=0;i<2;i++){ x[i]=sqrt(x[i]); f[i]*=2*x[i]/M;}
      }else 
      {
         double c[2];
         for(Npow=0;Npow<2;Npow++) c[Npow]=simpson(s_pow_integrand, 0. ,1. ,1.E-4);
         x[0]= sqrt(c[1]/c[0]);
         f[0]= c[0]*2*x[0]/M;
      }
    }
    factor=inC[k1][k2]*inG[k1]*inG[k2]*exp(-DeltaXf);
    for(nsub=1; nsub<= code22[k1][k2]->nprc;nsub++,nPrc++)
    { double u_min=0.;
      double a=0;

      if(wPrc) (*wPrc)[nPrc]=0;

      for(i=0;i<4;i++)  pname[i]=code22[k1][k2]->pinf(nsub,i+1,pmass+i);
      if(pmass[2]+pmass[3]>MassCutOut) continue; 


      if( (pmass[2]>Mlarge && pmass[3]<Msmall)
      ||(pmass[3]>Mlarge && pmass[2]<Msmall))
           { *(code22[k1][k2]->twidth)=1; *(code22[k1][k2]->gwidth)=1;}    
      else { *(code22[k1][k2]->twidth)=0; *(code22[k1][k2]->gwidth)=0;} 
      
      if(pmass[2]+pmass[3] > pmass[0]+pmass[1])
      { double smin=pmass[2]+pmass[3];
        if((pmass[0]!=M1 || pmass[1]!=M2)&&(pmass[0]!=M2 || pmass[1]!=M1))
        { double ms=pmass[0]+pmass[1];
          double md=pmass[0]-pmass[1];
          double Pcm=sqrt((smin-ms)*(smin+ms)*(smin-md)*(smin+md))/(2*smin);
          smin=sqrt(M1*M1+Pcm*Pcm)+sqrt(M2*M2+Pcm*Pcm);
        }
        u_min=m2u(smin); 
      }else  u_min=0;

      if(!Fast) a=simpson(s_integrand,u_min,1.,eps); 
      else if(Fast!=1) a=f[0]*sigma(x[0]); else
      {
          int isPole=0;
          char * s;
          int m,w,n;
          double mass,width;

          for(n=1;(s=code22[k1][k2]->den(nsub,n,&m,&w));n++)
          if(m && w && strcmp(s,"\1\2")==0 )
          { mass=code22[k1][k2]->va[m];
            width=code22[k1][k2]->va[w];
            if(mass<MassCutOut && mass+8*width > pmass[0]+pmass[1]
                            && mass+8*width > pmass[2]+pmass[3])
            { if((pmass[0]!=M1 || pmass[1]!=M2)&&(pmass[0]!=M2 || pmass[1]!=M1))
              { double ms=pmass[0]+pmass[1];
                double md=pmass[0]-pmass[1];
                double Pcm=sqrt((mass-ms)*(mass+ms)*(mass-md)*(mass+md))/(2*mass);
                mass=sqrt(M1*M1+Pcm*Pcm)+sqrt(M2*M2+Pcm*Pcm);
              }
              grid1=makeGrid(mass,width);
              if(isPole) grid=crossGrids(&grid,&grid1); else grid=grid1;
              isPole++;
            }
          }
          if(isPole==0)
          {  grid.n=1;
             grid.ul[0]=u_min;
             grid.ur[0]=u_max;
             grid.pow[0]=3;
          }

          if(grid.n==1 && pmass[0]+pmass[1]> 1.1*(pmass[2]+pmass[3]))
                a=f[0]*sigma(x[0])+f[1]*sigma(x[1]);
          else for(i=0;i<grid.n;i++)if(u_min<=grid.ur[i])
          {  
             double ul= u_min<grid.ul[i]? grid.ul[i]:u_min;
             double da=gauss(s_integrand,ul,grid.ur[i],grid.pow[i]);
             a+=da;             
          }
      }
/*
printf("X=E%.2E (%d) %.3E %s %s %s %s\n",X,everage, a, pname[0],pname[1],pname[2],pname[3]);
*/
      Sumkk+=a;
      if(wPrc) (*wPrc)[nPrc] = a*factor;
    }
    Sum+=factor*Sumkk;

  }
  }
  if(wPrc) for(i=0; i<nPrc;i++)  (*wPrc)[i]/=Sum;
  if(!everage) { double gf=geff(X);  Sum/=gf*gf;}
/*
exit(1);
*/
  return Sum;
}


static double Yeq(double X)
{  double heff;
   termod(M/X,NULL,&heff);
   return (45/(4*M_PI*M_PI*M_PI*M_PI))*X*X*
                    geff(X)*sqrt(M_PI/(2*X))*exp(-X)/heff;
}
                          

struct {double*data;double xtop; int pow,size;} vSigmaGrid={NULL,0,0,0}; 

static double darkOmega1(double * Xf,double Z1,double dZ1,int Fast,double Beps)
{
  double X = *Xf;
  double sqrt_gStar;

  double CCX=(Z1-1)*(Z1+1);
  double dCCX=(Z1-1+dZ1)*(Z1+1+dZ1)-CCX;
  double d, dYdX,Yeq0X;
  double dCC,dCC1,dCC2,X1,X2,vSigma,vSigma1,vSigma2;
  double cFactor=sqrt(M_PI/45)*MPlank*M;
  int i;

  if(vSigmaGrid.data==NULL) 
  { vSigmaGrid.data=(double*)malloc(20*sizeof(double));
    vSigmaGrid.size=20; 
  }
    
  sigma= (Fast)?sigma_gauss:sigma_simpson;

  if(Beps>=1) Beps=0.9999999;

  MassCut=M*(2-log(Beps)/X);
  d=X*0.01; dYdX=(Yeq(X+d)-Yeq(X-d))/(2*d);
  Yeq0X=Yeq(X)/X;
  termod(M/X,&sqrt_gStar,NULL);
  vSigma=aRate(X,0,Fast,NULL); if(FError) return -1;
  dCC=-CCX-dYdX/(vSigma*cFactor*sqrt_gStar*Yeq0X*Yeq0X);


  vSigmaGrid.data[0]=vSigma;
  vSigmaGrid.xtop=X;
  vSigmaGrid.pow=1;  

  if(fabs(dCC)<dCCX) { *Xf=X; return Yeq(X)*sqrt(1+dCC+CCX);} 
   
  dCC1=dCC;dCC2=dCC;X1=X;X2=X; vSigma1=vSigma;vSigma2=vSigma;
  while(dCC2>0) 
  {  
     X1=X2;
     dCC1=dCC2;
     vSigma1=vSigma2;
     X2=X2/XSTEP;
     X=X2;
     MassCut=M*(2-log(Beps)/X);
     termod(M/X,&sqrt_gStar,NULL);
     d=0.01*X; dYdX= (Yeq(X+d)-Yeq(X-d))/(2*d);
     Yeq0X=Yeq(X)/X;
     vSigma2=aRate(X,0,Fast,NULL); if(FError) return -1;
     dCC2=-CCX-dYdX/(vSigma2*cFactor*sqrt_gStar*Yeq0X*Yeq0X);
     
     if(vSigmaGrid.pow==vSigmaGrid.size)
     { vSigmaGrid.size+=10;
       vSigmaGrid.data=(double*)realloc(vSigmaGrid.data,sizeof(double)*vSigmaGrid.size);
     }       
     for(i=vSigmaGrid.pow;i;i--) vSigmaGrid.data[i]=vSigmaGrid.data[i-1];
     vSigmaGrid.xtop=X; vSigmaGrid.data[0]=vSigma2; vSigmaGrid.pow++;
  }
             
  while (dCC1<0)
  {  
     X2=X1;
     dCC2=dCC1;
     vSigma2=vSigma1;
     X1=X1*XSTEP;
     X=X1;
     MassCut=M*(2-log(Beps)/X);
     termod(M/X,&sqrt_gStar,NULL);
     d=0.01*X; dYdX=(Yeq(X+d)-Yeq(X-d))/(2*d);
     Yeq0X=Yeq(X)/X;
     vSigma1=aRate(X,0,Fast,NULL); if(FError) return -1;
     dCC1=-CCX-dYdX/(vSigma1*cFactor*sqrt_gStar*Yeq0X*Yeq0X);

     if(vSigmaGrid.pow==vSigmaGrid.size)
     { vSigmaGrid.size+=10;
       vSigmaGrid.data=(double*)realloc(vSigmaGrid.data,sizeof(double)*vSigmaGrid.size);
     }       

     vSigmaGrid.data[vSigmaGrid.pow++]=vSigma1; 
  }
            
  for(;;) 
  { 
     if(fabs(dCC1)<dCCX)  { *Xf=X1; return Yeq(X1)*sqrt(1+dCC1+CCX);}
     if(fabs(dCC2)<dCCX)  { *Xf=X2; return Yeq(X2)*sqrt(1+dCC2+CCX);}
                
     X=(X1*dCC2 - X2*dCC1)/(dCC2-dCC1);
     MassCut=M*(2-log(Beps)/X);
     termod(M/X,&sqrt_gStar,NULL);
     d=0.01*X;  dYdX= (Yeq(X+d)-Yeq(X-d))/(2*d);
     Yeq0X=Yeq(X)/X;
     vSigma= (vSigma1*(X2-X) - vSigma2*(X1-X))/(X2-X1);
     dCC=-CCX-dYdX/(vSigma*cFactor*sqrt_gStar*Yeq0X*Yeq0X);
     if(dCC*dCC1>0) {dCC1=dCC;X1=X;vSigma1=vSigma;} else {dCC2=dCC;X2=X;vSigma2=vSigma;}
  }             

}


static void XderivLn(double x, double *Y, double *dYdx)
{
  double y=exp(Y[0]);
  double yeq=Yeq(x);
  double sqrt_gStar;
  int i=log(x/vSigmaGrid.xtop)/log(XSTEP)-0.00001;
  double X1=vSigmaGrid.xtop*pow(XSTEP,i);   double sigmav1=vSigmaGrid.data[i];
  double X2=vSigmaGrid.xtop*pow(XSTEP,i+1); double sigmav2=vSigmaGrid.data[i+1];
  double sigmav;  
  
  sigmav1=log(sigmav1); sigmav2=log(sigmav2);

  if(i>0) 
  { double X0=vSigmaGrid.xtop*pow(XSTEP,i-1); double sigmav0=vSigmaGrid.data[i-1]; 

sigmav0=log(sigmav0);

    sigmav=sigmav0*(x-X1)*(x-X2)/(X0-X1)/(X0-X2)
          +sigmav1*(x-X0)*(x-X2)/(X1-X0)/(X1-X2)
          +sigmav2*(x-X0)*(x-X1)/(X2-X0)/(X2-X1); 
  }else if(i+2<vSigmaGrid.pow)
  { double X0=vSigmaGrid.xtop*pow(XSTEP,i+2); double sigmav0=vSigmaGrid.data[i+2];
sigmav0=log(sigmav0);
    sigmav=sigmav0*(x-X1)*(x-X2)/(X0-X1)/(X0-X2)
          +sigmav1*(x-X0)*(x-X2)/(X1-X0)/(X1-X2)
          +sigmav2*(x-X0)*(x-X1)/(X2-X0)/(X2-X1); 
    
  } else sigmav=(sigmav1*(x-X2)-sigmav2*(x-X1))/(X1-X2);

/*printf("sigmav=%e\n");*/
  
sigmav=exp(sigmav);
  
  termod(M/x,&sqrt_gStar,NULL);

  *dYdx=-(M/x/x)*MPlank*sqrt_gStar*sqrt(M_PI/45)*sigmav*(y-yeq*yeq/y);
  
/*printf("x=%e dydx=%e\n",x,*dYdx);*/

}


double darkOmegaFO(double * Xf_, int Fast, double Beps)
{
  double Yf,Yi;

  double  Z1=2.5;
  double  dZ1=0.05;
  double x;
  double Xf=25;
  

  if(Beps>=1) Beps=0.9999999;
  Yf=  darkOmega1(&Xf, Z1, dZ1,Fast, Beps); if(FError) return -1;
  x=Xf;
  Yi=1/( (M/x)*sqrt(M_PI/45)*MPlank*aRate(x, 1,Fast, NULL) );
  if(!finite(Yi)||FError)   return -1;
  if(Xf_) *Xf_=Xf; 
  return  2.742E8*M/(1/Yf +  1/Yi); /* 2.828-old 2.755-new 2.742 next-new */
}


double darkOmega(double * Xf, int Fast, double Beps)
{
  double Yt,Yi,Xt=25;
  double Z1=1.1;
  double Z2=10; 
  int i;
  double Xf1;
  if(Beps>=1) Beps=0.9999999;
  if(Z1<=1) Z1=1.1;

  fast_=Fast;
  
  Yt=  darkOmega1(&Xt, Z1, (Z1-1)/5,Fast, Beps); if(FError) return -1;
  Xf1=Xt;
  for(i=0; ;i++)
  { double X2=vSigmaGrid.xtop*pow(XSTEP,i+1);
    double y;

    if(Yt>=Z2*Yeq(Xt))  break;
    
    if(Xt>X2*0.999999) continue; 
    while(vSigmaGrid.pow<=i+1)
    { double X;
      if(vSigmaGrid.pow==vSigmaGrid.size)
      { vSigmaGrid.size+=10;
        vSigmaGrid.data=(double*)realloc(vSigmaGrid.data,sizeof(double)*vSigmaGrid.size);
      } 
     
      X=vSigmaGrid.xtop*pow(XSTEP,vSigmaGrid.pow);
      MassCut=M*(2-log(Beps)/X);      
      vSigmaGrid.data[vSigmaGrid.pow++]=aRate(X,0,Fast,NULL);
      if(FError) return -1;     
    }
    y=log(Yt);
    odeint(&y,1 , Xt , X2 , 1.E-3, (X2-Xt)/2, &XderivLn); 
    Yt=exp(y);
    Xt=X2;
  }
  if(Xf) *Xf=0.5*(Xf1+Xt);

  Yi=1/( (M/Xt)*sqrt(M_PI/45)*MPlank*aRate(Xt,1,Fast,NULL) );
  if(!finite(Yi)||FError)  return -1;

  return  2.742E8*M/(1/Yt  +  1/Yi); /* 2.828-old 2.755-new,2.742 -newnew */
}


double printChannels(double Xf ,double cut, double Beps, int prcn, FILE * f)
{ int i, nsub, l1,l2;
  int nPrc,nform=log10(1/cut)-2;
  float *wPrc;
  double Sum;

  MassCut=M*(2-log(Beps)/Xf);

  Sum=aRate(Xf, 1,1,&wPrc)*(M/Xf)*sqrt(M_PI/45)*MPlank/(2.742E8*M);
  if(FError) return -1;
  if(wPrc==NULL) return 0;
  if(nform<0)nform=0;

  fprintf(f,"\nChannels which contribute to 1/(omega) more than %G%%.\n",100*cut );
  if(prcn) fprintf(f,"Relative contrubutions in %% are displyed\n");
     else  fprintf(f,"Absolut  contrubutions to 1/Omega are  displyed\n");

  for(l1=0,nPrc=0;l1<NC;l1++)
  { int k1=sort[l1]; if(M+inMass[k1]>MassCut) break;
  for(l2=0;l2<NC;l2++)
  {                
    int k2=sort[l2];

    if( inMass[k1]+inMass[k2]>MassCut) break;
    if( inC[k1][k2]<=0) continue;

    for(nsub=1; nsub<=code22[k1][k2]->nprc; nsub++,nPrc++) if(fabs(wPrc[nPrc])>=cut)
    {  char *pname[4];
       for(i=0;i<4;i++)  pname[i]=code22[k1][k2]->pinf(nsub,i+1,NULL);
       if(prcn)
       { if(cut <0.000001) fprintf(f,"%.1E%% %s %s -> %s %s \n",
                         100*wPrc[nPrc],pname[0],pname[1],pname[2],pname[3]);
         else              fprintf(f,"%*.*f%% %s %s -> %s %s \n",nform+3,nform,
                         100*wPrc[nPrc],pname[0],pname[1],pname[2],pname[3]);
       } else 
        fprintf(f,"%.1E %s %s -> %s %s \n",Sum*wPrc[nPrc],pname[0],pname[1],pname[2],pname[3]);    
    }
  }
  }
  return 1/Sum;
}

/*
static int findChannel(char * name1,char * name2,int *k1_,int * k2_)
{ int k1,k2;
  int err;

  for(k1=0;k1<NC && strcmp(inP[k1],name1);k1++);
  for(k2=0;k2<NC && strcmp(inP[k2],name2);k2++);
  if(k1==NC || k2==NC) return 5;
  if(inC[k1][k2]<0) return 4;

  err=0;
  if(inC[k1][k2]==0)
  {  int kk=k1; k1=k2; k2=kk;
     err=1;
     if(inC[k1][k2]==0)
     { err=2;
       k1=inAP[k1];
       k2=inAP[k2];
       if(inC[k1][k2]==0)
       {  err=3;
          kk=k1; k1=k2; k2=kk;
          if(inC[k1][k2]==0) err=4;
       }
     }
  }
  if(err<4) 
  { if(code22[k1][k2]==NULL) new_code(k1,k2);
    if(inC[k1][k2]<=0) err=4;
    else{ *k1_=k1; *k2_=k2;}
  }
  return err;
}

*/

numout *  newProcess(char*Process,char* lib)
{
   char proclibf[1000];
   void * handle=NULL;
   int new=0;
   numout * cc;
   char *c=strstr(lib,"omglib_");

   sprintf(proclibf,"%s/2-2/%s.so",SOURCES,lib);

   handle=dLoad(proclibf);
   if(!handle)
   {  char command[1000];
      int ret,fd;
      if(c==lib)
      {  printf("The library '%s.so' was not generated yet in Omega "
                " calculation and can not be compiled this manner\n",lib);   
         return NULL;
      }
      fd=checkLockFile();
      
      sprintf(command,"cd %s/work; ./newProcess \"%s\" %s",SOURCES, Process,lib);
      ret=system(command);
      close(fd);
      if(ret<0 || WIFSIGNALED(ret)>0 ) exit(10);
      
      
      if(ret==0) handle=dLoad(proclibf); else 
      { printf(" Can not compile %s \n", Process);
        return NULL;
      }
      new=1;   
   }
   
   if(!c)  cc=loadLib(handle,lib);
   else    cc=loadLib(handle,lib+7);
   if(!cc && new) dClose(handle); 
   return cc;
}


double cs22(numout * cc, int nsub_, double P, double cos1, double cos2 , int * err) 
{
  int i;

  for(i=1;i<=cc->nvar;i++) if(cc->link[i]) cc->va[i]=*(cc->link[i]);

  if( cc->calcFunc() ) {*err=4; return 0;}
  *(cc->rwidth)=0;
  *(cc->twidth)=1;
  for(i=0;i<4;i++) cc->pinf(nsub_,1+i,pmass+i); 
  *err=0;
  sqme=cc->sqme;
  nsub=nsub_; 
  if(kin22(P)) return 0; else return 3.8937966E8*simpson(dSigma_dCos,cos1,cos2,0.3*eps);
}


int infor22(numout * cc, int nsub_, 
         char* name1,char* name2,char* name3,char* name4,
         double* m1,double* m2,double* m3,double* m4)
{
  int i;
  char   *nn;
  char   *n[4];
  double *m[4];
  
  n[0]=name1; n[1]=name2; n[2]=name3; n[3]=name4;
  m[0]=m1;    m[1]=m2;    m[2]=m3;    m[3]=m4;  

    
/*  if(cc->nin !=2 || cc->nout!=2) return 1; */

  if(nsub_<1 || nsub_> cc->nprc) return 2;

  for(i=1;i<=cc->nvar;i++) if(cc->link[i]) cc->va[i]=*(cc->link[i]);
  if( cc->calcFunc()) return 4;
    
  for(i=0;i<4;i++) 
  {  
     nn=cc->pinf(nsub_,i+1,m[i]);
     if(n[i]) strcpy(n[i],nn);
  }

  return 0;
}

double lspmass_(void) {return M;}

#ifdef notUsed


double crossSection(char*name1,char*name2,char*name3,char*name4,double P, int * err)
{
  static char name1_[4]="", name2_[4]="", name3_[4]="", name4_[4]=""; 
  static int k1,k2,nsub_;
  static numout * cc;
  int i;
    
  if(strcmp(name1,name1_)||strcmp(name2,name2_)||strcmp(name3,name3_)||strcmp(name4,name4_))
  { 
    *err=findChannel(name1,name2,&k1,&k2)/2;
    if(*err) return 0; 
    cc=code22[k1][k2];
    for(nsub_=1;nsub_<=cc->nprc;nsub_++)
    if( (strcmp(cc->pinf(nsub_,3,NULL),name3)==0 && strcmp(cc->pinf(nsub_,4,NULL),name4)==0)
      ||(strcmp(cc->pinf(nsub_,4,NULL),name3)==0 && strcmp(cc->pinf(nsub_,3,NULL),name4)==0)
      ) break;
    if(nsub_>cc->nprc) {*err=3; return 0;}
           
    strcpy(name1_,name1); strcpy(name2_,name2); strcpy(name3_,name3); strcpy(name4_,name4);
  }

  if(!cc->init)
  { 
    for(i=1;i<=cc->nvar;i++) if(cc->link[i]) cc->va[i]=*(cc->link[i]);
    if( cc->calcFunc() ) {*err=4; return 0;}
    *(cc->rwidth)=runWidthFlag;
    cc->init=1;
  }

  for(i=0;i<4;i++) cc->pinf(nsub_,1+i,pmass+i); 
  *err=0;
  sqme=cc->sqme;
  nsub=nsub_; 
  return 3.8937966E8*sigma_simpson(P);  
}

double diffCrossSection(char*name1,char*name2,char*name3,char*name4,double P, double cosine, int * err)
{
  static char name1_[4]="", name2_[4]="", name3_[4]="", name4_[4]=""; 
  static int k1,k2,nsub_,r;
  static numout * cc;
  int i;
    
  if(strcmp(name1,name1_)||strcmp(name2,name2_)||strcmp(name3,name3_)||strcmp(name4,name4_))
  { 
    *err=findChannel(name1,name2,&k1,&k2);
    if(*err==1) r=-1; else r=1;
    *err=*err/2;  
    if(*err) return 0;
    cc=code22[k1][k2];
    
    for(nsub_=1;nsub_<=cc->nprc;nsub_++)
    if( (strcmp(cc->pinf(nsub_,3,NULL),name3)==0 && strcmp(cc->pinf(nsub_,4,NULL),name4)==0)
      ||(strcmp(cc->pinf(nsub_,4,NULL),name3)==0 && strcmp(cc->pinf(nsub_,3,NULL),name4)==0)
      ) break;  
    if(nsub_>cc->nprc) {*err=3; return 0;}
    
    if(strcmp(cc->pinf(nsub_,3,NULL),name3)) r*=-1;

    strcpy(name1_,name1); strcpy(name2_,name2); strcpy(name3_,name3); strcpy(name4_,name4);
  }

  if(!cc->init)
  { 
    for(i=1;i<=cc->nvar;i++) if(cc->link[i]) cc->va[i]=*(cc->link[i]);
    if( cc->calcFunc() ) {*err=4; return 0;}
     *(cc->rwidth)=runWidthFlag;
    cc->init=1;
  }

  for(i=0;i<4;i++) cc->pinf(nsub_,1+i,pmass+i); 
  *err=0;

  sqme=cc->sqme;
  kin22(P);

  nsub=nsub_; 
  return 3.8937966E8*dSigma_dCos(r*cosine);  
}

int procInfor(char*name1,char*name2,char*name3,char*name4,int k)
{ int k1,k2;
  numout * cc;
  int err=findChannel(name1,name2,&k1,&k2)/2;
  if(err) return err;

  cc=code22[k1][k2];
  if(k>cc->nprc) return 3;
  strcpy(name3,cc->pinf(k,3,NULL));
  strcpy(name4,cc->pinf(k,4,NULL));
  return 0;
}

double annihilation(double v, int k,char* n1, char* n2)
{ double cs;
  double v0=v/299792.;
  double P=v0*M/sqrt(1-v0*v0);  
  int err;
  if(k<1) goto exi;
  if(procInfor("~o1","~o1",n1,n2,k)) goto exi;
  cs=crossSection("~o1","~o1",n1,n2,P,&err);
  if(err) goto exi;
  return v0*cs*299792.*1.E-31;
exi: 
   n1[0]=0; n2[0]=0; return 0;
}	


double sigmaEff(double X,int fast, double Beps)
{
  MassCut=M*(2-log(Beps)/X);     
  return  aRate(X, 1,fast,NULL); 
} 

double hEff(double t){ double g,h; termod(t,&g,&h); return h;}
double gStarSqrt(double t){double g,h; termod(t,&g,&h); return g;}

#endif

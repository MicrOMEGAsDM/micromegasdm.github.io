#ifndef __NUM_OUT_hhh
#define __NUM_OUT_hhh

#include<stdlib.h>
#include<string.h> 
#include<math.h>

extern const int nin_hhh;
extern const int nout_hhh;
extern const int nprc_hhh;
extern const int nvar_hhh;
extern const int nfunc_hhh;

extern char * pinf_hhh(int nsub, int nprtcl, double* pmass);
extern char * varName_hhh[];

extern double sqme_hhh(int nsub, double * momenta, int * err);
extern int calcFunc_hhh(void);
extern int rwidth_hhh, gwidth_hhh, twidth_hhh;
extern double va_hhh[];

extern  char * den_info_hhh(int nsub, int n, int * mass, int * width);

extern void build_cb_hhh(int nsub); 
extern void destroy_cb_hhh(void);    
extern int cb_pow_hhh;   
extern int cb_nc_hhh; 
extern int * cb_chains_hhh;
extern double * cb_coeff_hhh;


#define  DENOMINATOR_ERROR   2
#endif


#include<ctype.h>

#include <unistd.h>

#include "calchep/include/num_out.h"
#include "micromegas.h"
#include "micromegas_aux.h"

#include "s_particles.tab"
#include "h_particles.tab"

#include<errno.h>

void un_link(char * f)
{ int errnoTmp=errno;   
  unlink(f);
  errno=errnoTmp;
}

char *lsp(void)
{ int i;
  char * ls=NULL;
  double mmin=-1,mcur;
  for(i=0; i<28; i++) if(findVal(Sparticles[i].mass,&mcur)==0)
  {  mcur=fabs(mcur);
     if(mmin<0 || mmin>mcur) { mmin=mcur; ls=Sparticles[i].name;}
  }
  return ls;
}


void printMasses(FILE * f,int sort)
{

if(f)fprintf(f,"\nHiggs masses and widths\n");
{

  int i;
  double q;
  for(i=0;i<NH;i++) if(!findVal(higgsInfor[i].mass,&q))
  {
    if(f)fprintf(f,"%-3.3s : %-6.6s=%7.1f ", higgsInfor[i].name,
                  higgsInfor[i].mass,fabs(q));
    if(!findVal(higgsInfor[i].width,&q))
      if(f)fprintf(f,"(%-6.6s=%.1E)", higgsInfor[i].width,q);
     if(f) fprintf(f,"\n");
  }
}


if(f) fprintf(f,"\nMasses of SuperParticles:\n");
{  int i,col;
   int n[28],  nn[28];
   double mass[28];
   int pow;

   for(pow=0,i=0; i<28; i++) if(findVal(Sparticles[i].mass,mass+i)==0)
   {  mass[i]=fabs(mass[i]);
      n[pow]=i;
      nn[pow]=i;
       pow++;
   }

   if(pow>1)
   for(i=0;i<pow-1;)
   {  int i1=i+1;
      if( mass[n[i]] > mass[n[i1]])
      { int k=n[i]; n[i]=n[i1]; n[i1]=k;
        if(i==0) i++; else i--;
      } else i++;
   }


  for(col=0,i=0;i<pow;i++)
  { int k;
    if(sort)k=n[i];else k=nn[i];
    if(f)fprintf(f,"%-3.3s : %-6.6s= %7.1f ", Sparticles[k].name,
      Sparticles[k].mass,mass[k]);
    col++;
    if(f)
    { if(col==1 || col==2) fprintf(f,"|| ");
      if(col==3) { col=0; fprintf(f,"\n");}
    }
  }
  printf("\n");
  fprintf(f,"\n~o1 = %.3f*bino %+.3f*wino %+.3f*higgsino1 %+.3f*higgsino2\n",
            findValW("Zn11"), findValW("Zn12"), findValW("Zn13"), findValW("Zn14"));

}
}

void assignValW(char*name, double  val)
{ if(assignVal(name,val)==1) printf(" %s not found\n",  name); }

double  findValW(char*name)
{
  double val;

  if(findVal(name,&val))
  {  printf(" name %s not found\n",name);
     return 0;
  } else return val;
}

void fName2c(char*f_name,char*c_name,int len)
{ int i; for(i=len-1;i>=0 &&f_name[i]==' ';i--);
  c_name[i+1]=0;
  for(;i>=0;i--) c_name[i]=f_name[i];
}

void cName2f(char*c_name,char*f_name,int len)
{ int i; for(i=0;i<len &&c_name[i];i++) f_name[i]=c_name[i];
         for(   ;i<len            ;i++) f_name[i]=' ';
}

void assignvalw_(char* f_name, double * val, int len)
{  char buff[20];
   fName2c(f_name,buff,len);
   assignValW(buff, *val);
}

double findvalw_(char*f_name, int len)  /*FORTRAN*/
{
  char c_name[20];
  fName2c(f_name,c_name,len);
  return findValW(c_name);
}


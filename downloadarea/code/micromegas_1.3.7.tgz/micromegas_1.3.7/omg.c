/*    By default, the mass loop corrections are calculated by SuSpect  
  To use Isajet for such purpose  uncomment  the line below and modify 
  micro_make  to link  Isajet (EXTLIB=...)  
*/

/*#define suspectEwsbMSSM isajetEwsbMSSM */

#include"sources/micromegas.h"

int main(int argc,char** argv)
{
  int    dMbOn=0;
  int    LCon=0;
  int    fast=1; 
  double Beps=1.E-6;
  
  double cut=0.01;

  double Omega,Xf;
  int i,err;  

/* to save RGE input/output files  uncomment  */
/*  delFiles(0);  */  

  if(argc==1) 
  { 
     printf(" The program needs parameters,\n"
            "names of files which contain MSSM parameters\n");
     exit(1);
  }

  for(i=1;i<argc;i++)
  { 
     printf("Initial file  \"%s\"\n",argv[i]);
     
     err=readEwsb(argv[i]);
     
     if(err==-1)     {printf("Can not open the file\n"); continue;}
     else if(err==-2){printf("Not all parameters are specified\n"); continue;}
     else if(err==-3){printf("Inconsistent set of parameters\n"); continue;}  
     else if(err>0)  { printf("Wrong file contents at line %d\n",err);continue;}
     

     suspectEwsbMSSM(LCon);

     err=calcDep(dMbOn);
     if(err) {printf("Inconsistent set of parameters\n"); continue;}
     printMasses(stdout,1);

     if(strcmp(lsp(),"~o1"))
     {  printf("Wrong input: ~o1 is not LSP\n");
        continue; 
     }

     Omega=darkOmega(&Xf,fast,Beps);
     printf("Xf=%.2E Omega=%.2E  (file: %s)\n", Xf, Omega,  argv[i]);
     printChannels(Xf,cut,Beps,1,stdout); 

  }
  return 0;
}

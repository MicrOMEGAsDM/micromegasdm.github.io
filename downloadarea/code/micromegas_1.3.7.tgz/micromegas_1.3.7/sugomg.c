/*=== default RGE is SuSpect === 
   To use another package  uncomment one of lines below and modify
   micro_make  to link  the corresponding package
================================*/ 
/*#define suspectSUGRA  isajetSUGRA   */  /*=====for ISAJET   ======*/
/*#define suspectSUGRA  softSusySUGRA */  /*=====for SOFTSUSY ======*/
/*#define suspectSUGRA  sphenoSUGRA   */  /*=====for SPHENO   ======*/

#include"sources/micromegas.h"

int main(int argc,char** argv)
{
  int fast=1, dMbOn=1;
  double Beps=1.E-6, cut=0.01;
  double Omega,Xf;   
  int err;  
  double m0,mhf,a0,tb;
  double gMG1, gMG2, gMG3,  gAl, gAt, gAb,  sgn, gMHu,  gMHd,
         gMl2, gMl3, gMr2, gMr3, gMq2, gMq3, gMu2, gMu3, gMd2, gMd3;

/* to save RGE input/output files uncomment next line */
/*  delFiles(0); */

  if(argc<5) 
  { 
    printf(" This program needs 4 parameters:\n"
           "   m0      common scalar mass at GUT scale\n"
           "   mhf     common gaugino mass at GUT scale\n"
           "   a0      trilinear soft breaking parameter at GUT scale\n"
           "   tb      tan(beta) \n");
    printf(" Auxiliary parameters are:\n"
           "   sgn     +/-1,  sign of Higgsino mass term (default 1)\n"    
           "   Mtp     top quark pole mass\n"
           "   MbMb    Mb(Mb) scale independent b-quark mass\n"
           "   alfSMZ  strong coupling at MZ\n");                        
      exit(1); 
  } else  
  {  double Mtp,MbMb,alfSMZ;
     sscanf(argv[1],"%lf",&m0);
     sscanf(argv[2],"%lf",&mhf);
     sscanf(argv[3],"%lf",&a0);
     sscanf(argv[4],"%lf",&tb);
     if(argc>5)sscanf(argv[5],"%lf",&sgn); else sgn=1;
     if(argc>6){ sscanf(argv[6],"%lf",&Mtp);    assignValW("Mtp",Mtp);      }
     if(argc>7){ sscanf(argv[7],"%lf",&MbMb);   assignValW("MbMb",MbMb);    }
     if(argc>8){ sscanf(argv[8],"%lf",&alfSMZ); assignValW("alfSMZ",alfSMZ);}
  }

/*==== simulation of mSUGRA =====*/
  gMG1=mhf, gMG2=mhf,gMG3=mhf;
  gAl=a0,   gAt=a0,  gAb=a0;  gMHu=m0,  gMHd=m0;
  gMl2=m0,  gMl3=m0, gMr2=m0, gMr3=m0;
  gMq2=m0,  gMq3=m0, gMu2=m0, gMd2=m0, gMu3=m0, gMd3=m0;

  err=suspectSUGRA(tb,  
    gMG1, gMG2, gMG3,  gAl,  gAt, gAb,  sgn, gMHu, gMHd,
    gMl2, gMl3, gMr2, gMr3, gMq2,  gMq3, gMu2, gMu3, gMd2, gMd3);

  if(err<0){ printf(" No RGE solution \n");  return err;} 
  if(err>0){ printf(" non fatal problems in RGE\n");}
   
  err=calcDep(dMbOn);
  if(err) { printf("Inconsistent set of parameters\n"); return 1;}
 
/*  printVar(stdout,125);  */


  printMasses(stdout,1);

  if(strcmp(lsp(),"~o1"))
  {  printf("Wrong parameters: ~o1 is not LSP\n"); return 2; }


  Omega=darkOmega(&Xf,fast,Beps);
  printf("Xf=%.2e Omega=%.2e\n",Xf,Omega);

  printChannels(Xf,cut,Beps,1,stdout);

  printf("deltartho=%.2E\n",deltarho_());
  printf("gmuon=%.2E\n", gmuon_());
  printf("bsgnlo=%.2E\n", bsgnlo_());
  printf("bsmumu=%.2E\n", bsmumu_());
  if(masslimits_()==0) printf("MassLimits OK\n");
/* to save results in SLHA format  use */
/*  writeLesH("slha.out"); */
  return 0;
}

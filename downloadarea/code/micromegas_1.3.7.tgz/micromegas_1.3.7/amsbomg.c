/*=== default RGE is SuSpect === 
   To use another package  uncomment one of lines below and modify
   micro_make  to link  the corresponding package
================================*/ 
/*#define suspectAMSB  isajetAMSB  */   /*=====for ISAJET   ======*/
/*#define suspectAMSB  softSusyAMSB*/   /*=====for SOFTSUSY ======*/
/*#define suspectAMSB  sphenoAMSB  */   /*=====for SPHENO   ======*/

#include"sources/micromegas.h"

int main(int argc,char** argv)
{
  int fast=1, dMbOn=1;
  double Beps=1.E-6, cut=0.01;
  double Omega,Xf;   
  int err;  
  double m0,m32,sgn,tb;

/* to save RGE input/output files uncomment next line */
/*  delFiles(0); */
  
  
  if(argc<3) 
  { 
    printf(" This program needs 3 parameters:\n"
           "   m0      common scalar mass term \n"
           "   m32     gravitino mass\n"
           "   tb      tan(beta)\n");
    printf(" Auxiliary parameters are:\n"
           "   sgn(mu)  +/-1,  sign of Higgsino mass term (default 1)\n"    
           "   Mtp     top quark pole mass\n"
           "   MbMb    Mb(Mb) scale independent b-quark mass\n"
           "   alfSMZ  strong coupling at MZ\n");                        
      exit(1); 
  } else  
  {  double Mtp,MbMb,alfSMZ;
     sscanf(argv[1],"%lf",&m0);
     sscanf(argv[2],"%lf",&m32);
     sscanf(argv[3],"%lf",&tb);
     if(argc>4)sscanf(argv[4],"%lf",&sgn); else sgn=1;
     if(argc>5){ sscanf(argv[5],"%lf",&Mtp);    assignValW("Mtp",Mtp);      }
     if(argc>6){ sscanf(argv[6],"%lf",&MbMb);   assignValW("MbMb",MbMb);    }
     if(argc>7){ sscanf(argv[7],"%lf",&alfSMZ); assignValW("alfSMZ",alfSMZ);}
  }


  err=suspectAMSB(m0,m32,tb,sgn);  
  
  if(err<0){ printf(" No RGE solution \n");  return err;} 
  if(err>0){ printf(" non fatal problems in RGE\n");}

  err=calcDep(dMbOn);
  if(err) { printf("Inconsistent set of parameters\n"); return 1;}
 
/*  printVar(stdout,125);  */

  printMasses(stdout,1);
  if(strcmp(lsp(),"~o1"))
  {  printf("Wrong parameters: ~o1 is not LSP\n"); return 2; }

  Omega=darkOmega(&Xf,fast,Beps);
  printf("Xf=%.2e Omega=%.2e\n",Xf,Omega);

  printChannels(Xf,cut,Beps,1,stdout);

  printf("deltartho=%.2E\n",deltarho_());
  printf("gmuon=%.2E\n", gmuon_());
  printf("bsgnlo=%.2E\n", bsgnlo_());
  printf("bsmumu=%.2E\n", bsmumu_());
  if(masslimits_()==0) printf("MassLimits OK\n");
/* to save results in SLHA format  use */
/*  writeLesH("slha.out"); */
  return 0;
}


#ifndef  __MICRO_FORT__
#define  __MICRO_FORT__


extern int sortoddparticles_(char * name,int len);
/* 
    INTEGER FUNCTION sortOddParticles(name)
    character *(*) name
*/


/*=============================
     MSSM 2->2 cross sections
=============================*/

extern void newprocess_(char*Process,char* lib, int* address,int len1,int len2);
/* 
   Subroutine newProcess(Process, lib, address)
   character *(*) Process
   character *(*) lib
   integer address(2)
*/

extern double cs22_(int * address, int * nsub,double * P,  double * cos1, 
   double * cos2 , int * err);
/* 
   REAL*8 FUNCTION cs22( address,nsub,P,cos1,cos2,err) 
   integer address(2),nsub,err
   real*8 P,cos1,cos2
*/   
      
extern double pwidth2_(int * address,int *nsub);
/* 
    REAL*8 FUNCTION pWidth2(address, nsub)
    integer address(2),nsub
*/

extern void  procinfo1_(int * address, int * ntot, int *nin, int *nout);
/*   
    subroutine procInfo1(address, ntot,nin,nout)
    integer address(2), ntot, nin,nout
*/      
 
extern void procinfo2_(int * address ,int *nsub,char*names,double*masses,int len);
/*  
    subroutine  procInfo2(address, names, masses)
    integer address(2)
    character *(*) names
    real*8 (*) masses
*/      

extern  double decay2info_(char * pname, int *N, int len);
/*   
    real*8 function decay2Info(pname, Nfile)
    character*(*) pname
    integer Nfile 
*/
/*===================
      Variables 
=====================*/


extern int  assignval_(char * name, double * val, int len);
/*  
      integer function assignVal(name, val)
      character *(*) name
      real*8 val
*/    
   

extern int findval_(char * name,double * val,int len);
/*  
     integer function findVal(name,val)
     character *(*) name
     real*8 val
*/ 

extern void   assignvalw_(char * name, double * val, int len);
/*
     subroutine assignValW(name,val)
     character *(*) name
     real*8 val
*/
            
extern double findvalw_(char * name, int len);
/*   
     real*8 function findValW(name)
     character *(*) name
*/


extern int readvar_(char *fname, int len);
/*
     integer  function readVar(fname)
     character *(*) fname
*/

  
/*===========================================
   Checking of parameters 
  ===========================================*/ 
extern void printvar_(int * N);
/*
     subroutine printVar(N)
     integer N
*/
     
extern void  printmasses_(int *N, int*sort);
/*
     subroutine printMasses(N, sort)
     integer N,sort

*/

extern double lopmass_(void);

/*=====================================
    Relic density evaluation 
  =====================================*/ 

extern double darkomega_(double *Xf,int * Fast, double* Beps);
/*
     real*8 function darkOmega(Xf,Fast,Beps)
     real*8 Xf,Fast,Beps
*/


extern double printchannels_(double *Xf,double*cut,double* Beps,int *prcnt,int*N );
/*
     real*8 function printChannels(Xf,cut,Beps,prcn,N)
     real*8 Xf,cut,Beps
     integer prcn,N
*/
/*===============================================
    Annihilation spectra
=================================================*/
extern double calcspectrum_(double *v,int*outP,double *tab,int * err);
/* 
   real*8 function calcSpectrum(v,outP,tab,err)
   real*8 v
   integer outP
   interger err
   real*8 tab(250)
*/
     
extern void spectrinfo_(double*Xmin,double*tab,double*Ntot,double*Etot);
/* 
    subroutine spectrInfo(Xmin,tab,Ntot,Etot)
    real*8 Xmin,tab(250),Ntot,Etot
*/
int  spectrtable_(double*tab, char*fname,char*mess,double *Xmin,int *N,
                   int len1,int len2);
/*
    integer function  spectrTable(tab,fname,mess,Xmin,N)
    real*8 tab(250)
    character*(*) fname
    character*(*) mess
    real*8 Xmin
    integer N                   
*/

extern double halofactor_(double *fi,double (*rhoQ)(double*));
/*
  real*8 function HaloFactor( fi, rhoQ)
  real*8  fi, rho 
  external rhoQ
*/ 

extern double rhoqisotermic_(double *x);
/* 
  real*8 function RhoQisotermic(x)
  real*8 x 

*/ 

extern double zinterp_(double*x, double*tab);
/*
   real*8 function zinterp_(x,tab)
   real*8 x,tab(250)
*/


extern double findparam_(char *name, int *err, int len);
/* 
   real*8 function findParam(name,err)
   character*(*) name
   integer err
*/   
                                                                                
#endif

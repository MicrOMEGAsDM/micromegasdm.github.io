#include<stdio.h>
#include <unistd.h>
#include"../sources/micromegas_aux.h"

int main(void)
{ int i; 
  FILE*f;
/*  if(access("EXCLUDE",R_OK)==0) return 0; */
  f=fopen("EXCLUDE","w");
  for(i=0;i<Nodd;i++)
  { if(i) fprintf(f,",");
    fprintf(f,"%s",OddPrtcls[i].name);
    if(strcmp(OddPrtcls[i].name,OddPrtcls[i].aname))
    fprintf(f,",%s",OddPrtcls[i].aname);
  }
  fprintf(f,"\n");
  fclose(f);
return 0;
}  

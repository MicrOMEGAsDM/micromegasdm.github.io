#ifndef  __MICROMEGAS__
#define  __MICROMEGAS__

#ifdef __cplusplus
extern "C" {
#endif 

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<unistd.h>
#include"../CalcHEP_src/include/num_out.h"

typedef struct numout
{
  void * handle;
  double ** link;
  double *Q,*SC,*GG;
  int init;
  CalcHEP_interface * interface; 
} numout;

extern int sortOddParticles(char * name);
extern double sWidth;

/*=============================
     (1)2->2 matrix elements
=============================*/
extern double decay2Info(char * pname, FILE* f);
extern numout *  newProcess(char*Process,char* lib);
extern double cs22(numout * cc, int nsub,double P,  double cos1, double cos2 , int * err);
extern double pWidth2(numout * cc,int nsub);
extern int  procInfo1(numout*cc, int *nsub, int * nin, int *nout);
extern int procInfo2(numout*cc,int nsub,char**name,double*mass);

/*===================
      Variables 
=====================*/

extern double * varAddress(char * name); 
extern int    assignVal(char * name, double val);
extern int findVal(char * name,double * val);
extern void   assignValW(char * name, double val);
extern double findValW(char * name);
extern double findParam(char * name, int * err);
extern int readVar(char *fname);
  
/*===========================================
   Checking of parameters 
  ===========================================*/ 
extern void printVar(FILE *f);
extern void  printMasses(FILE * f, int sort);
extern double lopmass_(void);

/*=====================================
    Relic density evaluation 
  =====================================*/ 

extern double darkOmega(double *Xf,int Fast, double Beps);
extern double darkOmegaFO(double *Xf,int fast,double Beps);
extern double printChannels(double Xf,double cut,double Beps,int prcnt,FILE *f );   

/*===============================================
    Annihilation spectra
=================================================*/
                                                                                
extern double calcSpectrum(double v ,int outP,double *tab,int*errcode);
/* input parameters:
       a)  v velocity in c=1 units, v is about 0.001.
       b)  outP   0-gamma; 1-positron; 2-antiproton; 3,4,5 -
         for neutrinos (electron, muon and tau correspondinly)
output parameters:
       a) returned value v*sigma/M_lop^2 in sm^3/(GeV^2*sec)
       b) array of 250 double elements to store spectra.
       c) errcode !=0 if  in process of decays of outgoing particles 
          we get a non-SM particle which has not 1->2 decays.  
*/
extern double zInterp(double x, double * tab);
/* input parameter:
        a) x=log(E/Nmass)
        b) double tab[250] table obtainaed by calcSpectrum;
   output:
         dN/dx where N is the number spectrum.
*/
extern void spectrInfo(double Xmin,double*tab, double * Ntot,double*Etot);
/* input parameters:
  a)    Xmin = Emin/mLSP - characterizes minimal energy under considerstion
  b)    double tab[250]  - table for spectrum distribution.
  output:
  a)    Ntot - total number of particles with energy E> Xmin*mLsp
  b)    Everage energy of particle  divided on mLsp
*/
                                                                                
extern int spectrTable(double*tab, char*fname,char*mess,double Xmin,int N);
/* writes into  the file fname a table of  dN/d(log_10(E)) distribution.
   input parameters:
   a) tab - a table for distrubution
   b)  fname - a file name
   c) mess - a title
   d) Emin/mLsp
   f) N<=300 -a number of points to write
                                                                                
   The file can be displayed  by
     ./sources/CalcHEP_src/bin/tab_view <fname
*/

extern double HaloFactor(double fi,double (*rhoQ)(double));
/*
  Intergates halo squred density along the ling of slight.
  fi - angle in radians
  rhoQ  presents squred density of Dark Matter in [GeV/cm^3]^2 units as 
  a function of cerner galactic distance in kpc units.
  
  Return value is done in  GeV^2/cm^5   
*/ 

extern double rhoQisotermic(double x);
/* 
   presents  an example of rhoQ for HaloFactor.
   It corresponds to modified isotermic density with absence of clumbs.
*/ 
                                                                                
extern char * outNames[6];

extern void mInterp(double Nmass,  int  CHin,int  CHout, double*tab);

#ifdef __cplusplus
}
#endif 

#endif

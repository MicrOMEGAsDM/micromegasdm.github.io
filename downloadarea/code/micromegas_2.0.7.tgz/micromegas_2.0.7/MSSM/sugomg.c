/*=== default RGE is SuSpect === 
   To use another package change 'define' setting and 
   define path to the corresponding package via lib/Makefile
================================*/ 
#define SUGRA suspectSUGRA   
/*#define SUGRA  isajetSUGRA   */     /*=====for ISAJET   ======*/
/*#define SUGRA  softSusySUGRA */   /*=====for SOFTSUSY ======*/
/*#define SUGRA  sphenoSUGRA   */   /*=====for SPHENO   ======*/

#include"../sources/micromegas.h"
#include"lib/pmodel.h"


int main(int argc,char** argv)
{
  int fast=1;
  double Beps=1.E-5, cut=0.01;
  double Omega,Xf;   
  int err; 
  char mess[10]; 
  double m0,mhf,a0,tb;
  double gMG1, gMG2, gMG3,  gAl, gAt, gAb,  sgn, gMHu,  gMHd,
         gMl2, gMl3, gMr2, gMr3, gMq2, gMq3, gMu2, gMu3, gMd2, gMd3;

int k;
/* to save RGE input/output files uncomment the next line */
/* delFiles(0);  */

  if(argc<5) 
  { 
    printf(" This program needs 4 parameters:\n"
           "   m0      common scalar mass at GUT scale\n"
           "   mhf     common gaugino mass at GUT scale\n"
           "   a0      trilinear soft breaking parameter at GUT scale\n"
           "   tb      tan(beta) \n");
    printf(" Auxiliary parameters are:\n"
           "   sgn     +/-1,  sign of Higgsino mass term (default 1)\n"    
           "   Mtp     top quark pole mass\n"
           "   MbMb    Mb(Mb) scale independent b-quark mass\n"
           "   alfSMZ  strong coupling at MZ\n");                        
      exit(1); 
  } else  
  {  double Mtp,MbMb,alfSMZ;
     sscanf(argv[1],"%lf",&m0);
     sscanf(argv[2],"%lf",&mhf);
     sscanf(argv[3],"%lf",&a0);
     sscanf(argv[4],"%lf",&tb);
     if(argc>5)sscanf(argv[5],"%lf",&sgn); else sgn=1;
     if(argc>6){ sscanf(argv[6],"%lf",&Mtp);    assignValW("Mtp",Mtp);      }
     if(argc>7){ sscanf(argv[7],"%lf",&MbMb);   assignValW("MbMb",MbMb);    }
     if(argc>8){ sscanf(argv[8],"%lf",&alfSMZ); assignValW("alfSMZ",alfSMZ);}
  }

/*==== simulation of mSUGRA =====*/
  gMG1=mhf, gMG2=mhf,gMG3=mhf;
  gAl=a0,   gAt=a0,  gAb=a0;  gMHu=m0,  gMHd=m0;
  gMl2=m0,  gMl3=m0, gMr2=m0, gMr3=m0;
  gMq2=m0,  gMq3=m0, gMu2=m0, gMd2=m0, gMu3=m0, gMd3=m0;

  err=SUGRA(tb,  
    gMG1, gMG2, gMG3,  gAl,  gAt, gAb,  sgn, gMHu, gMHd,
    gMl2, gMl3, gMr2, gMr3, gMq2,  gMq3, gMu2, gMu3, gMd2, gMd3);

  if(err<0){ printf(" No RGE solution \n");  return err;} 
  if(err>0){ printf(" non fatal problems in RGE\n");}
  

  err=sortOddParticles(mess);
  
  if(err) { printf("Can't calculate %s\n",mess); return 1;}

/* to print input parameters uncomment */
/* 
  printVar(stdout);  
*/
/* to print model in SLHA format uncomment */
/*  
   writeLesH("slha.out"); 
*/

  HiggsMasses(stdout);
  printMasses(stdout,1);
  
  if(strcmp(mess,"~o1")) { printf(" ~o1 is not LSP\n"); return 2; }

  o1Contents(stdout);

  Omega=darkOmega(&Xf,fast,Beps);
  printf("Xf=%.2e Omega=%.2e\n",Xf,Omega);

  printChannels(Xf,cut,Beps,1,stdout);

  printf("deltarho=%.2E\n",deltarho_());
  printf("gmuon=%.2E\n", gmuon_());
  printf("bsgnlo=%.2E\n", bsgnlo_());
  printf("bsmumu=%.2E\n", bsmumu_());
  if(masslimits_()==0) printf("MassLimits OK\n");

  return 0;
}

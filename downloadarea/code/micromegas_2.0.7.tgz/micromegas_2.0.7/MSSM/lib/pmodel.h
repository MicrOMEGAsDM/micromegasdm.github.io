#ifndef  __MSSM__
#define  __MSSM__

#ifdef __cplusplus
extern "C" {
#endif 

#include"../../CalcHEP_src/c_source/num/include/alpha_s.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<unistd.h>


/*=====================================================
   MSSM Parameters input at low scale
=======================================================*/

extern int  suspectEwsbMSSM(void);
extern int  isajetEwsbMSSM(void);

/*=============================================
  MSSM Parameters motivated by SUGRA scenario
  =============================================*/
extern int  suspectSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                        );
extern int isajetSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                      );


extern int  softSusySUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl, double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                         );

extern int sphenoSUGRA(
 double tb, double gMG1,double gMG2,double gMG3,
 double gAl,double gAt, double gAb, double sgn, double gMHu, double gMHd,
 double gMl1,double gMl3,double gMr1,double gMr3,
 double gMq1,double gMq3,double gMu1,double gMu3,double gMd1,double gMd3
                      );

/*=============================================
  MSSM Parameters motivated by other  scenarios
  =============================================*/

extern int suspectAMSB(double am0,double m32,double stgbeta,double ssgnmu0);
extern int isajetAMSB(double am0,double m32,double tb,double sgn);
extern int softSusyAMSB(double am0,double m32,double tb,double sgn);
extern int sphenoAMSB(double am0,double m32,double tb,double sgn);

extern int isajetGMSB(double Lambda, double Mmess,double tb, double SGNMU,double N5, double cGrav,
double Rsl, double dmH_d2, double dmH_u2, double d_Y, double n5_1, double n5_2, double n5_3);

/*===============================================
     Les Houches interface
 ================================================*/
extern int  readLesH(char*fname, int SM );
extern int writeLesH(char*fname);     

extern void delFiles(int x); 


/*================================================
  Experimental constrains  on the  MSSM parameters  
  ===============================================*/
extern double deltarho_(void);
extern double gmuon_(void);
extern double gmuonold_(void);
extern int    masslimits_(void);
extern double bsgnlo_(void);
extern double bsmumu_(void);
extern double deltaMb(void);

/*======================
  printMasses + 
=========================*/
extern void HiggsMasses(FILE *f);
extern void o1Contents(FILE * f);
      
#endif

#ifdef __cplusplus
}
#endif 

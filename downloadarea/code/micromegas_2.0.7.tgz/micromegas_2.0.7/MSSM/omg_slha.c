
#include"../sources/micromegas.h"
#include"lib/pmodel.h"

int main(int argc,char** argv)
{
  int    fast=1; 
  double Beps=1E-6;
  
  double cut=0.01;
  double Omega,Xf;
  char mess[20]; 
  int i,err;  
  

  if(argc==1) 
  { 
     printf(" The program needs parameters, \n"
            "names of SLHA files \n");
     exit(1);
  }

  for(i=1;i<argc;i++)
  { 
     printf("Initial file  \"%s\"\n",argv[i]);
     
      err=readLesH(argv[i],1);
          
     if(err==-1)     {printf("Can not open the file\n"); continue;}
     else if(err>0)  { printf("Wrong file contents at line %d\n",err);continue;}
               
     err=sortOddParticles(mess);
     if(err<0) {printf("Can't calculate %s\n",mess); continue;}

     HiggsMasses(stdout);     
     printMasses(stdout,1);

     if(strcmp(mess,"~o1")) {  printf("~o1 is not LSP\n"); continue; }
     o1Contents(stdout);     

     Omega=darkOmega(&Xf,fast,Beps);
     printf("Xf=%.2E Omega=%.2E  (file: %s)\n", Xf, Omega,  argv[i]);
     printChannels(Xf,cut,Beps,1,stdout);
     
     printf("bsmumu=%.2E\n", bsmumu_());   
  }
  return 0;
}

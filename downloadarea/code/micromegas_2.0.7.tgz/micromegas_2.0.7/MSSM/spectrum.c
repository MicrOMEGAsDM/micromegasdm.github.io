#include"../sources/micromegas.h"
#include"../sources/micromegas_aux.h" 
#include"lib/pmodel.h"

#define  SUGRA suspectSUGRA        /*=====for SuSpect======*/
/*#define SUGRA  isajetSUGRA    */  /*=====for ISAJET   ======*/
/*#define SUGRA  softSusySUGRA */   /*=====for SOFTSUSY ======*/
/*#define SUGRA  sphenoSUGRA   */   /*=====for SPHENO   ======*/

int main(int argc,char** argv)
{ 
  int err,outP;
  double M,Emin,Ntot,Etot,sigmaV,v=0.001,fi,tab[250];
  
  char mess[100];
  char txt[100];
  double m0,mhf,a0,tb;
  double gMG1, gMG2, gMG3,  gAl, gAt, gAb,  sgn, gMHu,  gMHd,
         gMl2, gMl3, gMr2, gMr3, gMq2, gMq3, gMu2, gMu3, gMd2, gMd3;

/* to save RGE input/output files uncomment the next line */
/* delFiles(0); */ 

  if(argc<5) 
  { 
    printf(" This program needs 4 parameters:\n"
           "   m0      common scalar mass at GUT scale\n"
           "   mhf     common gaugino mass at GUT scale\n"
           "   a0      trilinear soft breaking parameter at GUT scale\n"
           "   tb      tan(beta) \n");
    printf(" Auxiliary parameters are:\n"
           "   sgn     +/-1,  sign of Higgsino mass term (default 1)\n"    
           "   Mtp     top quark pole mass\n"
           "   MbMb    Mb(Mb) scale independent b-quark mass\n"
           "   alfSMZ  strong coupling at MZ\n");                        
      exit(1); 
  } else  
  {  double Mtp,MbMb,alfSMZ;
     sscanf(argv[1],"%lf",&m0);
     sscanf(argv[2],"%lf",&mhf);
     sscanf(argv[3],"%lf",&a0);
     sscanf(argv[4],"%lf",&tb);
     if(argc>5)sscanf(argv[5],"%lf",&sgn); else sgn=1;
     if(argc>6){ sscanf(argv[6],"%lf",&Mtp);    assignValW("Mtp",Mtp);      }
     if(argc>7){ sscanf(argv[7],"%lf",&MbMb);   assignValW("MbMb",MbMb);    }
     if(argc>8){ sscanf(argv[8],"%lf",&alfSMZ); assignValW("alfSMZ",alfSMZ);}
  }

/*==== simulation of mSUGRA =====*/
  gMG1=mhf, gMG2=mhf,gMG3=mhf;
  gAl=a0,   gAt=a0,  gAb=a0;  gMHu=m0,  gMHd=m0;
  gMl2=m0,  gMl3=m0, gMr2=m0, gMr3=m0;
  gMq2=m0,  gMq3=m0, gMu2=m0, gMd2=m0, gMu3=m0, gMd3=m0;

  err=SUGRA(tb,  
    gMG1, gMG2, gMG3,  gAl,  gAt, gAb,  sgn, gMHu, gMHd,
    gMl2, gMl3, gMr2, gMr3, gMq2,  gMq3, gMu2, gMu3, gMd2, gMd3);

  if(err<0){ printf(" No RGE solution \n");  return err;} 
  if(err>0){ printf(" non fatal problems in RGE\n");}
  

  outP=0;    /* for gamma rays  
                1-positron; 2-antiproton; 3,4,5 neutrinos 
                (electron, muon and tau correspondinly)
             */
  Emin=0.1;  /* Erergy cut     */
  fi=0;      /* angle of sight */                                                                                                                                                                         

  err=sortOddParticles(mess); 
   if(err) { printf("Can't calculate %s\n",mess); return 1;}  

  sigmaV=calcSpectrum(v,outP,tab,&err);  /* sigma*v in cm^3/sec */    
  
  M=lopmass_();

  spectrInfo(Emin/M,tab, &Ntot,&Etot); 
  sprintf(txt,"%s: N=%.2e,<E/2M>=%.2f,vsc=%.2e cm^3/sec,M(%s)=%.2e", 
  outNames[outP],Ntot,Etot,sigmaV,mess,M); 

  spectrTable(tab,"tab",txt, Emin/M ,300);

  system("../CalcHEP_src/bin/tab_view < tab&");

  printf("gamma flux for fi=%.2E rad is %.2E[ph/cm^2/s/sr]\n",
     fi, HaloFactor(fi,rhoQisotermic)*sigmaV*Ntot/M/M);
        
{ double e[6];
  int i;
  printf("Check of energy conservation:\n"); 
  for(i=0;i<6;i++)
  {    
     sigmaV=calcSpectrum(v,i,tab,&err);
     spectrInfo(Emin/M,tab, NULL,e+i);
  } 
  printf("1 = %.2f\n",e[0]+2*(e[1]+e[2]+e[3]+e[4]+e[5]) );
}     

  return 0;
}

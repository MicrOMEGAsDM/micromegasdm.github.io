#define EwsbMSSM suspectEwsbMSSM 
/*#define EwsbMSSM isajetEwsbMSSM   */
/*#define EwsbMSSM sphenoEwsbMSSM   */
/*#define EwsbMSSM softSusyEwsbMSSM */

#include"../sources/micromegas.h"
#include"lib/pmodel.h"

int main(int argc,char** argv)
{
  int    fast=1; 
  double Beps=1E-6;
  
  double cut=0.01;
  double Omega,Xf;
  char mess[20]; 
  int i,err;  
  
/* to save the SLHA  input/output file  uncomment */
/*  delFiles(0);*/

  if(argc==1) 
  { 
     printf(" The program needs parameters,\n"
            "names of files which contain MSSM parameters\n");
     exit(1);
  }

  for(i=1;i<argc;i++)
  { 
     printf("Initial file  \"%s\"\n",argv[i]);
     
     err=readVar(argv[i]);
          
     if(err==-1)     {printf("Can not open the file\n"); continue;}
     else if(err>0)  { printf("Wrong file contents at line %d\n",err);continue;}

     err=EwsbMSSM();
     if(err) 
     { printf("Problem with spectrum calculation\n");
       continue;
     }
               
     err=sortOddParticles(mess);
     if(err<0) {printf("Can't calculate %s\n",mess); continue;}

     HiggsMasses(stdout);     
     printMasses(stdout,1);

     if(strcmp(mess,"~o1")) {  printf("~o1 is not LSP\n"); continue; }
     o1Contents(stdout);     

     Omega=darkOmega(&Xf,fast,Beps);
     printf("Xf=%.2E Omega=%.2E  (file: %s)\n", Xf, Omega,  argv[i]);
     printChannels(Xf,cut,Beps,1,stdout); 
     printf("deltarho=%.2E\n",deltarho_());
     printf("gmuon=%.2E\n", gmuon_());
     printf("bsgnlo=%.2E\n", bsgnlo_());
     printf("bsmumu=%.2E\n", bsmumu_());
     if(masslimits_()==0) printf("MassLimits OK\n");
  }
  return 0;
}

#define AMSB suspectAMSB
/*#define AMSB isajetAMSB */
/*#define AMSB sphenoAMSB */
/*#define AMSB softSusyAMSB */

#include"../sources/micromegas.h"
#include"lib/pmodel.h"

int main(int argc,char** argv)
{
  int    fast=1; 
  double Beps=1.E-5;
  double cut=0.01;
  double Omega,Xf;
  char mess[20]; 
  double m0,m32,sgn,tb;
  int err;  
  
/* to save the SLHA  input/output file  uncomment */
  delFiles(0);

  if(argc<4) 
  { 
    printf(" This program needs 3 parameters:\n"
           "   m0      common scalar mass at GUT scale\n"
           "   m3/2    gravitino mass\n"
           "   tb      tan(beta) \n");
    printf(" Auxiliary parameters are:\n"
           "   sgn     +/-1,  sign of Higgsino mass term (default 1)\n"    
           "   Mtp     top quark pole mass\n"
           "   MbMb    Mb(Mb) scale independent b-quark mass\n"
           "   alfSMZ  strong coupling at MZ\n");                        
      exit(1); 
  } else  
  {  double Mtp,MbMb,alfSMZ;
     sscanf(argv[1],"%lf",&m0);
     sscanf(argv[2],"%lf",&m32);
     sscanf(argv[3],"%lf",&tb);
     if(argc>4)sscanf(argv[4],"%lf",&sgn); else sgn=1;
     if(argc>5){ sscanf(argv[5],"%lf",&Mtp);    assignValW("Mtp",Mtp);      }
     if(argc>6){ sscanf(argv[6],"%lf",&MbMb);   assignValW("MbMb",MbMb);    }
     if(argc>7){ sscanf(argv[7],"%lf",&alfSMZ); assignValW("alfSMZ",alfSMZ);}
  }

     err= AMSB(m0,m32,tb,sgn);
 
     if(err) 
     { printf("Problem with spectrum calculation\n");
       exit(0);
     }
               
     err=sortOddParticles(mess);
     if(err<0) {printf("Can't calculate %s\n",mess); exit(1);}

     HiggsMasses(stdout);     
     printMasses(stdout,1);

     if(strcmp(mess,"~o1")) {  printf("~o1 is not LSP\n"); exit(1); }
     o1Contents(stdout);     

     Omega=darkOmega(&Xf,fast,Beps);
     printf("Xf=%.2E Omega=%.2E  \n", Xf, Omega);
     printChannels(Xf,cut,Beps,1,stdout); 

  return 0;
}

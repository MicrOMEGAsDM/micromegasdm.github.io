/*
 Copyright (C) 1997, Alexander Pukhov 
*/
#include "chep_crt.h"
#include "plot.h"
#include "param.h"
#include "interface.h"
#include "err_code.h"

#include "num_serv.h"

void  paramdependence(r_func  ff, char*  procname, char*  resultname)
{
   int         nprm=0;
   double      minprm, maxprm;
   int         npoints;
   double      memprm, stepprm;
   unsigned    count;
   double f[201];
   int Esc=0;
   double prmval; 
   char txt[100];
   
   selectParam(&nprm,54,11,nin_int==2,1,0,"Choose parameter",NULL); 
   if(nprm < 0) return;
   memprm=va_int[nprm];
 
   minprm = memprm; 
   maxprm = minprm; 
    
label1:
   sprintf(txt,"'%s' min=",varName_int[nprm]); 
   if (!correctDouble(55,14,txt,&minprm,0))  return;

label2:
   sprintf(txt,"'%s' max=",varName_int[nprm]);    
   if (!correctDouble(55,15,txt,&maxprm,0)) 
   { 
      goto_xy(55,14);
      clr_eol(); 
      goto label1;
   } 
   if (maxprm <= minprm) 
   { 
      messanykey(55,17,"Range check error"); 
      goto_xy(55,15);
      clr_eol();
      goto label2;
   } 

label4: npoints = 101;
   if (correctInt(55,16,"Number of points= ",&npoints,0)) 
   { 
      if (npoints < 3) 
      { 
         messanykey(55,17,"Too few points!"); 
         goto label4;
      } 
      if (npoints > 201) 
      { 
          messanykey(55,17,"Too many points!"); 
          goto label4;
      } 
   } 
   else
   { 
      goto_xy(55,15);
      clr_eol(); 
      goto label2;
   }

   goto_xy(55,14); clr_eol();
   goto_xy(55,15); clr_eol();
   goto_xy(55,16); clr_eol();

   stepprm = (maxprm - minprm)/(npoints - 1); 

   informline(0,npoints);

   stepprm = (maxprm - minprm) / (npoints - 1); 
   prmval=minprm;
   err_code = 0; 

   for(count = 1; count <= npoints; count++)
   { 
      va_int[nprm]=prmval;
      err_code=checkParam();
      if(err_code>1) break; 

      f[count-1] = ff();
      if(err_code>1) break;
      
      Esc=informline(count,npoints);
      if(Esc) break;       
      prmval += stepprm;
   } 
 
   if(err_code) errormessage();
   strcpy(txt,varName_int[nprm]);
   if (err_code <=1 && Esc==0)  plot_0(minprm,maxprm ,npoints,f,NULL,procname,txt,resultname); 
   va_int[nprm]=memprm; 
   calcFunc_int();
} 

/*
 Copyright (C) 2000, Alexander Pukhov, e-mail pukhov@theory.npi.msu.su
*/

#include"chep_crt.h"
#include"interface.h"
#include"plot.h"
#include"param.h"

/* ************************************************* */
/* Physics model parameters menu                     */
/* ************************************************* */

int checkParam(void)
{ int err=calcFunc_int();
  if(err>0)
  {  char mess[100];
     sprintf(mess,"Can not evaluate constraned parameter '%s' ", 
             varName_int[err]);
    
     if(blind) { printf("%s\n",mess); sortie(122);} 
     else     messanykey(10,10, mess);
     return err; 
  }
  return 0;
}

static void param_menu(int sqtrS_on, int vars_on, int func_on, char ** strmen)
{
  int k,pos,npos;
  
  if(sqtrS_on)  sqtrS_on=1;    
  npos=sqtrS_on;
  if(vars_on) npos += nvar_int;
  if(func_on) { for(k=0;k<nfunc_int;k++) if(!hiddenf[k])npos++;}    
 
  
  if(npos==0) {*strmen=NULL; return;}
  *strmen=malloc(24*npos+2);
  (*strmen)[0]=24;


  pos=1;    
  for (k = !sqtrS_on; k <= nvar_int + nfunc_int; ++k)
  { 
     if(k==0 || (vars_on && k<=nvar_int) || (func_on && k>nvar_int &&!hiddenf[k-nvar_int-1]))
     { char c=' '; 
       if(k>nvar_int && vars_on  ) c='*';
       sprintf((*strmen)+pos,"%c%7s= %-14.5lg",c,varName_int[k],va_int[k]); 
       pos+=24;
     }
  }
  (*strmen)[pos]=0;    
}


void selectParam(int * position, int x, int y, int sqtrS_on, int vars_on, int func_on, 
                char * mess, void ** pscrPtr)
{
    char* strmen;
    void * pscr;

    if(pscrPtr) pscr=*pscrPtr; else pscr=NULL; 

    param_menu( sqtrS_on,vars_on,func_on,&strmen);
    if(strmen)
    { int i;
      menu1(x,y,mess,strmen,"",&pscr,position);
      free(strmen);

      if (*position == 0){ if(pscrPtr) *pscrPtr=NULL; *position=-1; return ;}
      if(pscrPtr)   *pscrPtr=pscr; else  put_text(&pscr);
      if(sqtrS_on) (*position)--;
      if(!vars_on)  *position+=nvar_int;
      for(i=0; i< (*position)-nvar_int ; i++) if(hiddenf[i])(*position)++;  
    } else *position= -1;
} 

int change_parameter(int x,int y)
{ 
  double val;
  char name[20];
  int i,m,err;
  int returnCode=0; 
  void * pscr=NULL;
  double *va_mem=(double*)malloc(sizeof(double)*(nvar_int+1));

  for(i=1;i<=nvar_int;i++) va_mem[i]=va_int[i];
  
  for(err=1; err;)
  {
    for(m=0;m>=0;)
    {  selectParam(&m, x,y,0,1,0,"Change parameter",&pscr);
       if(m>=0) 
       {  
          sprintf(name,"%s = ",varName_int[m]);
          val=va_int[m];
          if(correctDouble(x,y+4,name,&val,1)) { va_int[m]=val; returnCode=1;}
       }   
    }

    if(returnCode)
    { 
      void * pscr;
      get_text(x,y+1,x+25, y+3,&pscr);
      scrcolor(FGmain,BGmain);
      goto_xy(x+5,y+1); print("Be patient:");
      goto_xy(x,y+3); print("Calculation of constraints");
      escpressed();
      err=checkParam();
      put_text(&pscr);
    } else  err=0;
    if(err&& mess_y_n(10,10, "Restore the previous set of parameters?")) 
        for(i=1;i<=nvar_int;i++) va_int[i]=va_mem[i];

  }
  free(va_mem);
  return returnCode;
}

void show_depend(int x, int y)
{ void *pscr1=NULL;
  int i; 
  double*allfunc=(double*) malloc(sizeof(double)*nfunc_int);
  for(i=0;i<nfunc_int;i++) allfunc[i]=va_int[1+nvar_int+i];

  for(;;) 
  { void *pscr2=NULL;
    char name1[20];
    int k1=0;
    selectParam(&k1,x,y+1,0,0,1,"Display dependence",&pscr1);

    if(k1<0) return;
    strcpy(name1,varName_int[k1]);
    for(;;)
    { char name2[20];
      double val2;
      void *pscr3=NULL;
      double xMin, xMax;
      int  nPoints=100;
      int k3;

      int k2=0;
      selectParam(&k2,x,y+5,0,1,0,"on parameter",&pscr2);
      if(k2<0) break;
      strcpy(name2,varName_int[k2]); val2=va_int[k2]; 
      xMin=val2 - fabs(val2)/10;
      xMax=val2 + fabs(val2)/10; 
      
      for(;;)
      {   
         char strmen[]="\030 "
            " x-Min = XXX            "
            " x-Max = YYY            "
            " Npoints = NNN          "
            " Display                ";
     
         improveStr(strmen,"XXX","%G",xMin);
         improveStr(strmen,"YYY","%G",xMax);
         improveStr(strmen,"NNN","%d",nPoints);

         
         menu1(x,y+9,"Plot",strmen,"",&pscr3,&k3);
         if(!k3) break;
         switch(k3)
         {  case 1: correctDouble(x,y+12,"xMin = ",&xMin,1); break;
            case 2: correctDouble(x,y+12,"xMax = ",&xMax,1); break;
            case 3: correctInt(x,y+12,"nPoints = ",&nPoints,1); break;
            case 4:
            if( xMax>xMin && nPoints>=3 && nPoints<=150)
            {  double dx=(xMax-xMin)/(nPoints-1);
               double f[150];
               int i, NaN=0,Esc=0;
         
               informline(0,nPoints);               
               for(i=0;i<nPoints;i++)
               {  double x=xMin+i*dx;
                  va_int[k2]=x;
                  NaN=checkParam();
                  if(NaN) 
                  {  char mess[100];
                     sprintf(mess,"Can not evaluate constraints for %s=%G",name2, x);
                     messanykey(16,5,mess);        
                     break;
                  }
                  f[i]=va_int[k1];
                  Esc=informline(i,nPoints);
                  if(Esc) break;  
               }
                  
               va_int[k2]=val2; 
               for(i=0;i<nfunc_int;i++) va_int[1+nvar_int+i]=allfunc[i];

               if(!(NaN||Esc)) plot_0(xMin,xMax,nPoints,f,NULL,"Plot",
                               name2,name1);
                               
            } else messanykey(16,5," Correct input is \n"
                                   "  xMin<xMax,\n"
                                   " 3<=nPoints<=150");
            break;
         }
       }
     }
  }
  free(allfunc);
}

/*
 Copyright (C) 1997, Alexander Pukhov, e-mail: pukhov@theory.npi.msu.su
*/
#include"syst.h"
#include"histogram.h"
#include"crt_util.h"
#include"edittab.h"
#include"syst.h"
#include"read_func.h"
#include"rd_num.h"
#include"interface.h"
#include"plot.h"
#include"subproc.h" 
#include"phys_val.h"


table histTab={"*** Table ***","Distributions",
                   "  Parameter  |> Min bound <|> Max bound <|",NULL};
                   
typedef  struct  histRec 
{   struct histRec * next;
    linelist  mother;
    long  nPoints;
    char key;               
    char plist[10];
    double hMin,hMax;
    double f[300];
    double ff[300];   
} histRec;

static histRec * histPtr=NULL;

int clearHists(void)
{ histRec * hists=histPtr;
  int i;
  if(histPtr==NULL) return 0;
  while(hists)
  { 
    for(i=0;i<300;i++){hists->f[i]=0;hists->ff[i]=0;}
    hists->nPoints=0; 
    hists=hists->next;
  }
  return 1;
}



void  fillHists(double w)
{ histRec * hists=histPtr;
  int i;
  double z;   
  while(hists)
  { 
    z=calcPhysVal(hists->key,hists->plist);
           
    if( z>hists->hMin && z<hists->hMax) 
    {     
      i=300*(z-hists->hMin)/(hists->hMax-hists->hMin);    
      hists->f[i]+=w;
      hists->ff[i]+=w*w;    
    }
    hists->nPoints++; 
    hists=hists->next;
  }
}


int correctHistList(void)
{ 
   linelist ln=histTab.strings;
   int lineNum=0;
   int i;
   char keyChar;
   double rMin, rMax;
   char  histStr[STRSIZ], minStr[STRSIZ], maxStr[STRSIZ];
   char fieldName[50];    
   histRec * hptr = histPtr;

   for( ;hptr;hptr=hptr->next) hptr->mother=NULL;

   while(ln)
   {
      char lv[10]={0,0,0,0,0,0,0,0,0,0};
      histStr[0]=0;
      minStr[0]=0;
      histStr[0]=0;
      sscanf(ln->line,"%[^|]%*c%[^|]%*c%[^\n]%*c",histStr,minStr,maxStr);            
      lineNum++;
      trim(minStr);
      trim(histStr);
      trim(maxStr);
/*================ MIN bound ============*/
      strcpy(fieldName,"Wrong field 'Min. bound'");
      if (!minStr[0]|| calcExpression(minStr,rd_num,&rMin ))  goto errorExit;
/*================== MAX bound ==========*/
      strcpy(fieldName,"Wrong field 'Max bound'");
      if(!maxStr[0] ||calcExpression(maxStr,rd_num,&rMax ))  goto errorExit;
      if(rMax<rMin){ double tmp=rMax; rMax=rMin; rMin=tmp;}
/*============ Parameter ===========*/
      strcpy(fieldName,"Wrong field 'Parameter'");
      if(! checkPhysVal(histStr, &keyChar,lv)) goto errorExit;

      hptr = histPtr;
      while(hptr != NULL)
      { if ( (hptr->key==keyChar)&&(hptr->hMin==rMin)&&(hptr->hMax==rMax)
           &&(!strcmp(lv,hptr->plist) ) ) 
         {  if(hptr->mother) 
            {    strcpy(fieldName," Duplicate record");
                 goto errorExit;
            } else 
            {  hptr->mother=ln;
               goto cont;
            }
         } else hptr=hptr->next;
      }
      hptr=malloc(sizeof(histRec));
      hptr->next=histPtr;
      hptr->mother=ln;
      histPtr=hptr;
      hptr->key=keyChar;
      strcpy(hptr->plist,lv);
      hptr->hMin=rMin; 
      hptr->hMax=rMax;
      for(i=0;i<300;i++) {hptr->f[i]=0;hptr->ff[i]=0;}
      hptr->nPoints=0;
      cont: 
      ln=ln->next;
   }
      
   hptr = histPtr; 
   histPtr=NULL;  
   while(hptr) 
   { histRec *  hptr_=hptr;
     hptr=hptr->next;
     if(!hptr_->mother) free(hptr_); else {hptr_->next=histPtr; histPtr=hptr_;}                 
   }
   return 0;
   errorExit:
      sprintf(errorText," Error in  line %d .\n"
                         "%s.",lineNum,fieldName);
      messanykey(2,10,errorText);
      return 1;
}

static void writeDistributions(FILE*iprt)
{
  histRec * hists=histPtr;
  int i;
  linelist rec;
  
  for(rec=histTab.strings;rec;rec=rec->next)
  {
     for(hists=histPtr;hists;hists=hists->next) if(hists->mother == rec) 
     {
        fprintf(iprt, " nPoints=%d key=%c",hists->nPoints,hists->key);
        for(i=0;i<10 && hists->plist[i];i++) fprintf(iprt, "%d",hists->plist[i]); 
        fprintf(iprt," hMin=%-12E hMax=%-12E",hists->hMin,hists->hMax); 
        fprintf(iprt,"\n  f: "); 
        for(i=0;i<300;i++) fprintf(iprt," %-12E", hists->f[i]); 
        fprintf(iprt,"\n ff: ");
        for(i=0;i<300;i++) fprintf(iprt," %-12E",hists->ff[i]); 
     }
     fprintf(iprt,"\n");
  } 
}


static void readDistributions(FILE*iprt)
{
  int i;
  linelist rec;
  for(rec=histTab.strings;rec;rec=rec->next)
  {
     histRec * hist=malloc(sizeof(histRec));

     hist->next=histPtr;
     hist->mother=rec;
     histPtr=hist;

     fscanf(iprt, " nPoints=%ld key=%c",&(hist->nPoints),&(hist->key));
     for(i=0;i<10 ;i++) 
     { 
       fscanf(iprt, "%c",hist->plist+i);
       if(hist->plist[i]==' ') { hist->plist[i]=0; break;} else
       hist->plist[i] -= '0';
     }  
     fscanf(iprt,"hMin=%lf hMax=%lf\n",&(hist->hMin),&(hist->hMax)); 
     fscanf(iprt,"  f: ");
     for(i=0;i<300;i++) fscanf(iprt," %lf",hist->f+i); 
     fscanf(iprt," ff: ");
     for(i=0;i<300;i++) fscanf(iprt," %lf",hist->ff+i); 
  } 
}


int wrt_hist(FILE *nchan)
{  fprintf(nchan,"\n"); 
   writetable0(&histTab,nchan); 
   writeDistributions(nchan);
   return 0;
}

int rdr_hist(FILE *nchan)
{  fscanf(nchan,"\n"); 
   readtable0(&histTab,nchan);   
   readDistributions(nchan);
   return 0;
}


int wrt_hist2(FILE *nchan, char * comment)
{  if(comment) fprintf(nchan,"%s\n",comment); else  fprintf(nchan,"\n"); 
   writetable0(&histTab,nchan); 
   writeDistributions(nchan);
   return 0;
}


int rdr_hist2(FILE *nchan, char *comment)
{  if(comment) fscanf(nchan,"%[^\n]\n",comment); else fscanf(nchan,"%*[^\n]\n"); 
   if(readtable0(&histTab,nchan)) return 1;
   readDistributions(nchan);
   return 0;
}


static int strcmp2(char*c1,char*c2)
{ 
  for(;;) if(*c1==' ') c1++;
  else    if(*c2==' ') c2++;
  else    if(*c1==*c2){if(*c1) { c1++; c2++;} else return 0;}
  else    return *c1-*c2; 
}


int add_hist(FILE *f, char *procname)
{  
  table histTab2=histTab;
  histRec * histPtr2=histPtr;
  histRec *r,*r2;
  char procname2[100], *out,*out2;
  int err=0; 
  histPtr=NULL;
  histTab.strings=NULL;

  err=rdr_hist2(f,procname2);


  if(err) return err;

  if(!histPtr2){ strcpy(procname,procname2); return 0; }
    
  out=strstr(procname,"->"); out2=strstr(procname2,"->");
  if(out==NULL || out2==NULL) err=4; 
  else if(strcmp2(out,out2))  err=3;
  else 
  {  char instr[100],instr2[100],*c,*c2;
     int l=out-procname;  
     strncpy(instr,procname,l); instr[l]=0;
     l=out2-procname2;
     strncpy(instr2,procname2,l); instr2[l]=0;

     c=strchr(instr,','); if(c) {c[0]=0; c++;}
     c2=strchr(instr2,','); if(c2){ c2[0]=0; c2++;}
     if((!c)&&(!c2)){ if(strcmp2(instr,instr2)) sprintf(procname,"pX1%s",out);}
     else if(c&&c2) 
     { char *n1="pX1";
       char *n2="pX2";

       if(strcmp2(instr,instr2)==0) n1=instr; 
       if(strcmp2(c,c2)==0) n2=c;

       sprintf(procname,"%s,%s%s",n1,n2,out2);
     } else err=3;   
  }


  if(err==0)
  {
     for(r2=histPtr2;r2;r2=r2->next) for(r=histPtr;r;r=r->next)
     if(strcmp2(r->mother->line,r2->mother->line)==0) 
     { int i;
       double n1=r->nPoints;
       double n2=r2->nPoints;
       double n=n1+n2;
       
       for(i=0;i<300;i++) 
       {   
           r2->ff[i]=(n/n1)*(n/n1)*(r->ff[i]  - r->f[i]*r->f[i]/n1 )+
                     (n/n2)*(n/n2)*(r2->ff[i] - r2->f[i]*r2->f[i]/n2);
           r2->f[i]=(n/n1)*r->f[i]+(n/n2)*r2->f[i];
           r2->ff[i]+=(r2->f[i])*(r2->f[i])/n;
        }
       r2->nPoints+=r->nPoints;;
  
     }
  }

  cleartab(&histTab);
  histTab=histTab2;

  while(histPtr){r=histPtr->next; free(histPtr); histPtr=r;}
  histPtr=histPtr2;
  
  return err;
}


static int nBinMenu(int X, int Y)
{                   

static int kBinMenu=3;
char   strmen[] =
   "\015"
   " 300         "
   " 150         "
   " 100         "
   "  75         "
   "  60         "
   "  50         "
   "  30         " 
   "  25         "
   "  20         "
   "  15         "
   "  12         "
   "  10         "
   "  6          "
   "  5          "
   "  4          "
   "  3          "
   "  2          ";

   void * pscr=NULL;
   
   int n;
   if(!kBinMenu) kBinMenu=3;
   for(;;)
   {                
      menu1(X,Y,"number of bins",strmen,"",&pscr,&kBinMenu);
      if (kBinMenu)
      {
        sscanf(strmen+1+strmen[0]*(kBinMenu-1),"%d",&n);
        put_text(&pscr);
        return n;
      }
      return 0;
   }
}


void showHist(int X, int Y)
{
   char  histStr[STRSIZ];
   linelist ln=histTab.strings;
   char * menutxt;
   void * pscr=NULL;
   int mode =0;
   
   int npos=0;
   int width;

   while(ln)
   {  npos++;
      ln=ln->next;     
   }
   if(!npos) return; 

   sscanf(histTab.format,"%[^|]",histStr);
   width=strlen(histStr);
   menutxt=malloc(2+width*npos);
   menutxt[0]=width;
   menutxt[1]=0;
   
   ln=histTab.strings;
   while(ln)
   {  
      sscanf(ln->line,"%[^|]",histStr);
      strcat(menutxt,histStr);
      ln=ln->next;
   }
   
   for(;;)
   {  
      menu1(X,Y,"Distributions",menutxt,"",&pscr,&mode);

      switch(mode)
      {
      case 0: free(menutxt);return;
      default: 
      {  histRec * hist=histPtr;
         int nBin;
         ln=histTab.strings;
         for(npos=1;npos<mode;npos++) ln=ln->next; 
         for( ;hist && hist->mother!= ln;hist=hist->next){;}
         if(hist)
         {  
            char xname[80],yname[80],units[80];                                    
                                                                                   
            if( hist->nPoints == 0) messanykey(10,10,"Distibution is empty");     
            else
            while(nBin=nBinMenu(X,Y+4))                                                                   
            {  double f[300],df[300],coeff;                                        
               int i;                                                              
               coeff=nBin/(hist->nPoints*(hist->hMax - hist->hMin));               
               for(i=0;i<nBin;i++)                                                 
               {  int k;                                                           
                  f[i]=0;                                                          
                  df[i]=0;                                                         
                  for(k=0;k<300/nBin;k++)                                          
                  {  f[i] += coeff*hist->f[i*300/nBin+k];                          
                    df[i] += coeff*coeff*hist->ff[i*300/nBin+k];                   
                  }                                                                
                  df[i]=sqrt(df[i] - f[i]*f[i]/hist->nPoints);                      
               }                                                                   
                                                                                   
               if(nin_int==2) strcpy(yname,"Diff. cross section [pb");                 
               else       strcpy(yname,"Diff. width [GeV");                        
               xName(hist->key,hist->plist,xname,units);                           
               if(units[0]) { strcat(yname,"/");strcat(yname,units);}              
               strcat(yname,"]");                                                  
                                                                                   
               plot_0(hist->hMin,hist->hMax,nBin,f,df,proces_1.proces,xname,yname);       
            }                                                                      
         }
      }       
      }
   }
}

void editHist(void) {do  edittable(1,4,&histTab,1,"n_distrib",0); while(correctHistList());} 



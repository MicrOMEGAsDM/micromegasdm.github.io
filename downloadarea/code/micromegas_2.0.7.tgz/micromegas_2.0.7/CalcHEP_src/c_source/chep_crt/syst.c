/*
 Copyright (C) 1997, Alexander Pukhov 
*/

#include <unistd.h>
#include <signal.h>
#include"syst.h"


static char * lockFileName=NULL;

void  (*diskerror)(void) = NULL;

int f_printf(FILE *fp,char * format, ... )
{ va_list args;
  char dump[STRSIZ];
  int  r;
  va_start(args, format);

        vsprintf(dump,format,args);
	va_end(args);
	r = fputs(dump,fp);
	if (r == EOF)
	{ if(diskerror)(*diskerror)(); else sortie(65); }
	return r;
}


size_t f_write(void* ptr,  size_t size,  size_t n,  FILE * fp)
{ size_t nn;
   if ((size == 0)||(n == 0)) return 0;
   nn= fwrite(ptr,size,n,fp);
   if (nn != n) {if(diskerror) (*diskerror)() ; else sortie(65);}
   return nn;
}


char *  trim(char* p)
{  int n1=0, n2, k=-1;
   n2=(int)strlen(p)-1;
   while(!isgraph(p[n1]) && n1 <= n2) n1++;
   while(!isgraph(p[n2]) && n1 <  n2) n2--;
   while(++k < n2-n1+1)  p[k] = p[k+n1];
   p[k] = '\0';
   return p;
}


static void signalhandler(int n) { sortie(n); }

void writeLockFile(char * fname)
{  FILE *f;
  
  if(lockFileName) return;
  f=fopen(fname,"r");
  if(f)
  { printf("The program was launched here but not terminated!\n"
           "See information about the process in %s file\n"
           " Close the process or delete the file.\n",fname);
    fclose(f);
    exit(100);
  }
  f=fopen(fname,"w");
  if(f)
  { char hName[200];
    int i;
    
    gethostname(hName,200);

    fprintf(f,"The program was launched here but not terminated yet!\n"
              "Process %d; host %s\n",getpid(), hName);
     fclose(f);
     lockFileName=malloc(strlen(fname)+1);
     strcpy(lockFileName,fname);
     for(i=2;i<=16;i++) signal(i,signalhandler);
  }          
}

void sortie(int code) 
{ 
  switch(code)
  {
    case   1 : printf("Hangup detected on controlling terminal\n"); break;
    case   2 : printf("Interrupt from keyboard\n");                 break;
    case   3 : printf("Quit from keyboard\n");                      break;
    case   4 : printf("Illegal Instruction\n");                     break;
    case   6 : printf("Abort signal from abort(3)\n");              break;
    case   8 : printf("Floating point exception\n");                break;
    case   9 : printf("Kill signal\n");                             break;
    case  11 : printf("Invalid memory reference\n");                break;
    case  13 : printf("Broken pipe\n");                             break;
    case  14 : printf("Timer signal from alarm(2)\n");              break;
    case  15 : printf("Termination signal\n");                      break;
  }

  if(lockFileName) unlink(lockFileName);  exit(code);

}

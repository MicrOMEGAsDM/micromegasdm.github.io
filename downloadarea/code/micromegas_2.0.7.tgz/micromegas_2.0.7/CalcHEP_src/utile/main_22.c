#include<math.h>
#include<stdio.h>
#include"num_out.h"
#include"num_in.h"

static int assignVal(char * name, double val)
{
  int i;
  for(i=1;i<=nvar_ext+nfunc_ext;i++)
  { 
    if(strcmp(name,varName_ext[i])) continue;
    if(i<=nvar_ext) {va_ext[i]=val; return 0;} else return 1; 
  }
    return 2;
}
                      
                      

int main(void)
{ int err;

  double pvec[16];
  double *p1=pvec, *p2=pvec+4, *p3=pvec+8, *p4=pvec+12;

  double m1,m2,m3,m4;

  double Pin,Pout;
  double totcoef, sqrt_S, S, lambda12, lambda34,ms,md;
  double cos_fi, cos_step;
  double sigmaTot=0;
  int i;

/*an example how to change parametgers; if name of parameter is wrong, err=1 */ 
/*  err=assignVal("SW", 0.483);  */

  err=calcFunc_ext();
  if(err>0) 
  { printf("Can not calculate constraints '%s'\n",varName_ext[err]);
    exit(1);
  }      
/* find masses */ 
  pinf_ext(1,1,&m1,NULL);pinf_ext(1,2,&m2,NULL);  
  pinf_ext(1,3,&m3,NULL);pinf_ext(1,4,&m4,NULL);

/* Initial cms  momentum */

  Pin=100;

/* 2-2 kinematics */

  sqrt_S=sqrt(m1*m1+Pin*Pin) +sqrt(m2*m2+Pin*Pin);
  S=sqrt_S*sqrt_S;  
  lambda12=2*sqrt_S*Pin;
  ms = m3+m4; if (ms >= sqrt_S) return 1;
  md = m3 -m4;
  lambda34 = sqrt((S - ms*ms) * (S - md*md));
  totcoef = 3.8937966E8 * lambda34 /(32.0 * M_PI * lambda12 * S);        
  Pout=lambda34/(2*sqrt_S);

/* fill momenta of particles */
  
  for(i=0;i<16;i++) pvec[i]=0;
  
  p1[0]=  sqrt(Pin*Pin + m1*m1);
  p1[3]=  Pin;
  p2[0]=  sqrt(Pin*Pin + m2*m2);
  p2[3]= -Pin;
  p3[0]=  sqrt(Pout*Pout + m3*m3);
  p4[0]=  sqrt(Pout*Pout + m4*m4);
  
  cos_step=0.1; /* step to calculate dsigma/dcos */
  sigmaTot=0.;  /* total cross section */
/* cycle */
  for(cos_fi=1-cos_step/2; cos_fi>-1; cos_fi -= cos_step)
  { double  DsigmaDcos;
    double  sin_fi=sqrt((1-cos_fi)*(1+cos_fi));
    int err=0;
    p3[3]=Pout*cos_fi; p4[3]=-p3[3];
    p3[2]=Pout*sin_fi; p4[2]=-p3[2];
    DsigmaDcos=totcoef*sqme_ext(1,pvec,&err); 
 
    sigmaTot += DsigmaDcos*cos_step;
    
    printf("DsigmaDcos=%E\n",DsigmaDcos);
  }
  printf("sigmaTot=%E\n",sigmaTot);

  return 0;
}


#include<stdio.h>
#include<string.h>
#include<math.h>

extern double id2mass_(int*);

static FILE* F;
static double Mass[10];
static int Pid[10];
static int Nin=0, Nout=0;

#define MAXNUP 500
extern struct  hepeup_
{    int     NUP,IDPRUP;
     double  XWGTUP,SCALUP,AQEDUP,AQCDUP;
     int     IDUP[MAXNUP],ISTUP[MAXNUP],MOTHUP[MAXNUP][2],ICOLUP[MAXNUP][2];
     double  PUP[MAXNUP][5], VTIMUP[MAXNUP],SPINUP[MAXNUP];
} hepeup_;

#define MAXPUP 100
extern struct heprup_
{  int IDBMUP[2];
   double  EBMUP[2];
   int PDFGUP[2],PDFSUP[2];
   int  IDWTUP,NPRUP;
   double XSECUP[MAXPUP],XERRUP[MAXPUP],XMAXUP[MAXPUP];
   int LPRUP[MAXPUP];
} heprup_;                

void fName2c(char*f_name,char*c_name,int len)
{ int i; for(i=len-1;i>=0 &&f_name[i]==' ';i--);
  c_name[i+1]=0;
  for(;i>=0;i--) c_name[i]=f_name[i];
}

int initevents_(char* fname,int len)
{
   char cname[200];
   char buff[200];
   double p[2]={0,0};
   int nEvents=0;
   double Sigma=0;
   double cross_section;
   double *cs=&cross_section;
   
   int i,n;
   fName2c(fname,cname,len);
   F=fopen(cname,"r");
   if(F==NULL) return -1;
      
   for(fscanf(F,"%s",buff);!feof(F); )
   {
      if(strcmp(buff,"#Type")==0) 
      { fscanf(F,"%d -> %d", &Nin, &Nout);
        if(Nin!=2) {fclose(F); return -2;}        
      } else if(strcmp(buff,"#Initial_state")==0)
      {
        for(i=0;i<2;i++) heprup_.IDBMUP[i]= 0;
        for(i=0;i<2;i++){fscanf(F," P%d_3=",&n); fscanf(F,"%lf",p+n-1);}
        for(i=0;i<2;i++) 
        { fscanf(F," StrFun%d=",&n); fscanf(F,"\"%*[^\"]\" %d",heprup_.IDBMUP+n-1);}
      }
      else if(strcmp(buff,"#PROCESS")==0)
      {  int np;
         for(np=0;np<Nin+Nout;np++)
         { fscanf(F,"%d",Pid+np);
           fscanf(F,"%*s");
           if(np==Nin-1)fscanf(F," -> ");
         }  
      }  else if(strcmp(buff,"#MASSES")==0)
      { int i;
         for(i=0;i<Nin+Nout;i++) fscanf(F," %lf",Mass+i);
      } else if(strcmp(buff,"#Cross_section(Width)")==0)
      {  if( fscanf(F," %lf",cs)==0) *cs=0;       
      } else if(strcmp(buff,"#Number_of_events")==0)
      {  fscanf(F," %d",&nEvents);      
      } else if(strcmp(buff,"#Events")==0)
      {  fscanf(F,"%*[^\n]%*c");
         
         for(i=0;i<2;i++)
         { double m=Mass[i];
           if(heprup_.IDBMUP[i]==0) heprup_.IDBMUP[i]=Pid[i];
           if(heprup_.IDBMUP[i]!=Pid[i]) m=id2mass_(heprup_.IDBMUP+i);
           heprup_.EBMUP[i]=sqrt(m*m+p[i]*p[i]);           
         }         
         heprup_.IDWTUP = 3;
         heprup_.XSECUP[0] = *cs;
         heprup_.XERRUP[0] = 0.;
         heprup_.XMAXUP[0] = 1.;
         
         return nEvents;
      }
      fscanf(F,"%s",buff);
   }
   return 0; 
}

void upevnt_(void)
{
   int i,j;
   int n;
   
   hepeup_.IDPRUP=1;
   hepeup_.XWGTUP=1.;
   hepeup_.NUP=Nin+Nout;

   for(i=0;i<2;i++)for(j=0;j<2;j++) hepeup_.PUP[i][j]=0;
   n=fscanf(F,"%*d %lf %lf",&(hepeup_.PUP[0][2]),&(hepeup_.PUP[1][2])); 
   if(n!=2) {hepeup_.NUP=0; return;} 

   for(i=2;;i++) 
   { double q[3];
     if(3==fscanf(F,"%lf %lf %lf",q,q+1,q+2)) 
         for(j=0;j<3;j++) hepeup_.PUP[i][j]=q[j];
     else break;
   }

   fscanf(F,"| %lf",&hepeup_.SCALUP);  

   for(i=0;i<Nin+Nout;i++) for(j=0;j<2;j++) hepeup_.ICOLUP[i][j]=0;
   for(i=0,j=500; ;i++,j++)
   { int k1,k2; 
     int n=fscanf(F," (%d %d)", &k1,&k2);
     if(n!=2) break;
     if(k1<=2) hepeup_.ICOLUP[k1-1][0]=j; else hepeup_.ICOLUP[k1-1][1]=j;
     if(k2<=2) hepeup_.ICOLUP[k2-1][1]=j; else hepeup_.ICOLUP[k2-1][0]=j;
   }           

   for(i=0;i<hepeup_.NUP;i++)
   {  double q1= hepeup_.PUP[i][0],q2=hepeup_.PUP[i][1],q3= hepeup_.PUP[i][2];
      double m=Mass[i];
      hepeup_.MOTHUP[i][0]=0;
      hepeup_.MOTHUP[i][1]=0;
      hepeup_. SPINUP[i]=9;
      hepeup_.VTIMUP[i]=0;
      hepeup_.PUP[i][3]=sqrt(q1*q1 + q2*q2 + q3*q3 + m*fabs(m));
      hepeup_.PUP[i][4]=m; 
      hepeup_.ISTUP[i]=1;
      hepeup_.IDUP[i] =Pid[i];
   }
   hepeup_.ISTUP[0]=-1; hepeup_.ISTUP[1]=-1;
}

void closeevents_(void){ fclose(F);}

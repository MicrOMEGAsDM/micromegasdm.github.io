      IMPLICIT NONE 

      INTEGER IMSS
      REAL*8 RMSS
      COMMON/PYMSSM/IMSS(0:99),RMSS(0:99)
      SAVE /PYMSSM/
      INTEGER NUP,IDPRUP
      COMMON/HEPEUP/NUP,IDPRUP
       
      integer initEvents 
      INTEGER N,NEV,NEVMAX
      real*8 cs
      CHARACTER eventFile*200, slhaFile*200 

*   number of events
      NEV=100
*   file with events
      eventFile='events_1.txt'
*  SUSY input if it needs, or empty string
      slhaFile='slha_1.txt'
      slhaFile=' '
      if(slhaFile.ne.' ') then
        IMSS(1)=11
        IMSS(21)=21
        OPEN(21,FILE=slhaFile,STATUS='OLD',ERR=100)
      else 
        IMSS(1)=1
      endif

      NEVMAX= initEvents(eventFile)
      if(NEVMAX.LT.0) THEN
        write(*,*) eventFile, ': file is absent'
        stop 
      endif

      IF(NEV.GT.NEVMAX) THEN
        write(*,*) 'Only ', NEVMAX, ' events available'
      ENDIF

      CALL PYINIT('USER',' ',' ',0d0)
      DO 200 N=1,NEV
         CALL PYEVNT
         IF(NUP.EQ.0) THEN
           write(*,*) 'Only ',N-1,' events are generated' 
           GOTO 201
         ENDIF
*...<<<<<<< USER's routines for analysis should be call here >>>>>> 
c      call pylist(5)
      call pylist(7)    ! This is an example of user's routine:
      call pylist(1)    ! This is an example of user's routine:
c        call PYHEPC(1)      ! Convert PYJETS event to HEPEVT format.
*...<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
200   CONTINUE 
201   CALL closeEvents
      CLOSE(21)
      CALL PYSTAT(1)
100   continue
      END
C ============= Auxilary routins ========== 
      REAL *8 FUNCTION ID2MASS(ID)
      IMPLICIT NONE
      INTEGER PYCOMP,ID,KCHG
      REAL*8 PMAS,PARF,VCKM
      COMMON/PYDAT2/KCHG(500,4),PMAS(500,4),PARF(2000),VCKM(4,4)
      ID2MASS=PMAS(PYCOMP(ID),1)      
c      ID2MASS=0
      END

      SUBROUTINE UPINIT
      IMPLICIT NONE
      INTEGER MAXNUP
      PARAMETER (MAXNUP=500)
      INTEGER NUP,IDPRUP,IDUP,ISTUP,MOTHUP,ICOLUP
      DOUBLE PRECISION XWGTUP,SCALUP,AQEDUP,AQCDUP,PUP,VTIMUP,SPINUP
      COMMON/HEPEUP/NUP,IDPRUP,XWGTUP,SCALUP,AQEDUP,AQCDUP,IDUP(MAXNUP),
     &ISTUP(MAXNUP),MOTHUP(2,MAXNUP),ICOLUP(2,MAXNUP),PUP(5,MAXNUP),
     &VTIMUP(MAXNUP),SPINUP(MAXNUP)

      INTEGER MAXPUP
      PARAMETER (MAXPUP=100)
      INTEGER IDBMUP,PDFGUP,PDFSUP,IDWTUP,NPRUP,LPRUP
      DOUBLE PRECISION EBMUP,XSECUP,XERRUP,XMAXUP
      COMMON/HEPRUP/IDBMUP(2),EBMUP(2),PDFGUP(2),PDFSUP(2),
     &IDWTUP,NPRUP,XSECUP(MAXPUP),XERRUP(MAXPUP),XMAXUP(MAXPUP),
     &LPRUP(MAXPUP)
      INTEGER I
      SAVE
* Only one subprocess is supported
      NPRUP= 1
      LPRUP(1)=1

c SHG defaults are used 
      DO 100 I=1,2
      PDFSUP(I)=-1
100   PDFGUP(I)=-1

      AQEDUP=-1
      AQCDUP=-1

      RETURN
      END

/*====== Modules ===============
   Keys to switch on 
   various modules of micrOMEGAs  
================================*/
    
#define OMEGA       /*  Calculate Freeze out relic density and display contribution of  individual channels */
#define FREEZEIN    /*  Calculate relic density in Freeze-in scenario  */
#define CDM_NUCLEON /* Calculate amplitudes and cross-sections for  CDM-mucleon collisions */


/*===== end of Modules  ======*/

/*===== End of DEFINE  settings ===== */


#include"../include/micromegas.h"
#include"../include/micromegas_aux.h"
#include"lib/pmodel.h"

int main(int argc,char** argv)
{  int err;
   char cdmName[10];
   int spin2, charge3,cdim;

  ForceUG=1;  /* to Force Unitary Gauge assign 1 */
  VZdecay=1; VWdecay=1;  

//================================//
//...Play with parameter values...//
//================================//
  assignValW("mss",  10.);
  assignValW("lamssh", 0.15);

  err=sortOddParticles(cdmName);
  qNumbers(CDM1, &spin2, &charge3, &cdim);

//===============================================//
//...Freeze-out scenario dark matter abundance...//
//===============================================//
#ifdef OMEGA
{ int fast=1;
  double Beps=1.E-4, cut=0.01;
  double Xf;
  double Omega;  
  int i,err; 
  printf("\n==== Calculation of relic density in thermal freeze-out scenario =====\n");   

  Omega=darkOmega(&Xf,fast,Beps,&err);
  printf("Omega freeze-out=%.2e\n", Omega);
  printChannels(Xf,cut,Beps,1,stdout);
}
#endif

//============================================//
//...WIMP-nucleon scattering cross-sections...//
//============================================//
#ifdef CDM_NUCLEON
{ double pA0[2],pA5[2],nA0[2],nA5[2];
  double Nmass=0.939; /*nucleon mass*/
  double SCcoeff;        
  double csSIp1,csSIn1,csSDp1,csSDn1, csSIp1_,csSIn1_,csSDp1_,csSDn1_;   

  nucleonAmplitudes(CDM1, pA0,pA5,nA0,nA5);

  SCcoeff=4/M_PI*3.8937966E8*pow(Nmass*Mcdm1/(Nmass+ Mcdm1),2.);
  csSIp1=  SCcoeff*pA0[0]*pA0[0];
  csSDp1=3*SCcoeff*pA5[0]*pA5[0];
  csSIn1=  SCcoeff*nA0[0]*nA0[0];
  csSDn1=3*SCcoeff*nA5[0]*nA5[0];
                  
  printf("\n==== Calculation of %s-nucleon cross sections[pb]: ====\n",CDM1);
  printf(" proton  SI %.3E SD %.3E \n", csSIp1,csSDp1);
  printf(" neutron SI %.3E SD %.3E \n", csSIn1,csSDn1);     
}
#endif





//====================================================//
//...Redefine coupling, more suitable for freeze-in...//
//====================================================//
//  assignValW("lamssh", 1.995e-12);
//  
//  err=sortOddParticles(cdmName);
//  qNumbers(cdmName, &spin2, &charge3, &cdim);

//==============================================//
//...Freeze-in scenario dark matter abundance...//
//==============================================//
//#ifdef FREEZEIN
//{
//  double TR=1E10;
//  double omegaFi, omegaFIdec;  
//  toFeebleList(CDM1);
//  VWdecay=0; VZdecay=0;
//  
////...Full-blown calculation
//  omegaFi=darkOmegaFi(TR,&err);
////...Calculation based on Higgs decays only  
//  omegaFIdec = darkOmegaFiDecay(TR, "H", 1, 0);
//  printf("\n==== Calculation of relic density in freeze-in scenario =====\n");   
//  printf("omega freeze-in=%.3E\n", omegaFi);
//  printf("omega freeze-in from Higgs decays=%.3E\n", omegaFIdec);
//  printChannelsFi(0,0,stdout);
//}
//#endif

  return 0;
}
